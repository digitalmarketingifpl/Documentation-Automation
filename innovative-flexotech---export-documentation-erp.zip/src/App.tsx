import React, { useState, useEffect } from 'react';
import {
  ShipmentDocument,
  CompanyProfile,
  ShipmentStatus,
  DocumentTab,
  ExportDocumentMode,
} from './types/trade';
import {
  DEFAULT_COMPANY_PROFILE,
  INITIAL_SHIPMENTS,
} from './utils/mockData';
import { Header } from './components/Header';
import { DocumentToolbar } from './components/DocumentToolbar';
import { CommercialInvoiceView } from './components/CommercialInvoiceView';
import { TaxInvoiceView } from './components/TaxInvoiceView';
import { PackingListView } from './components/PackingListView';
import { DocumentEditor } from './components/DocumentEditor';
import { ShipmentArchive } from './components/ShipmentArchive';
import { CompanyProfileSettings } from './components/CompanyProfileSettings';
import { NewDocumentModal } from './components/NewDocumentModal';
import { AiAuditModal } from './components/AiAuditModal';
import { PoExtractorModal } from './components/PoExtractorModal';

const LOCAL_STORAGE_SHIPMENTS_KEY = 'innovative_flexotech_shipments_v2';
const LOCAL_STORAGE_PROFILE_KEY = 'innovative_flexotech_profile_v2';

export default function App() {
  // Load master profile from localStorage or default
  const [masterProfile, setMasterProfile] = useState<CompanyProfile>(() => {
    try {
      const stored = localStorage.getItem(LOCAL_STORAGE_PROFILE_KEY);
      if (stored) return JSON.parse(stored);
    } catch (e) {
      console.warn('Could not load profile from localStorage:', e);
    }
    return DEFAULT_COMPANY_PROFILE;
  });

  // Load shipments from localStorage or seed shipments
  const [shipments, setShipments] = useState<ShipmentDocument[]>(() => {
    try {
      const stored = localStorage.getItem(LOCAL_STORAGE_SHIPMENTS_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.warn('Could not load shipments from localStorage:', e);
    }
    return INITIAL_SHIPMENTS;
  });

  const [activeShipmentId, setActiveShipmentId] = useState<string>(() => {
    return shipments[0]?.id || 'shipment-ger-001';
  });

  // Views & Tabs state
  const [activeView, setActiveView] = useState<'active-doc' | 'archive' | 'company-profile'>('active-doc');
  const [activeDocTab, setActiveDocTab] = useState<DocumentTab>('lc_export_invoice');
  const [documentMode, setDocumentMode] = useState<ExportDocumentMode>('all');
  const [printMode, setPrintMode] = useState<'digital' | 'preprinted'>('digital');
  const [stationeryTopMarginMm, setStationeryTopMarginMm] = useState<number>(55);
  const [stationeryBottomMarginMm, setStationeryBottomMarginMm] = useState<number>(25);

  // Modals state
  const [isNewDocModalOpen, setIsNewDocModalOpen] = useState(false);
  const [isAiAuditModalOpen, setIsAiAuditModalOpen] = useState(false);
  const [isPoExtractorModalOpen, setIsPoExtractorModalOpen] = useState(false);

  // Active shipment instance
  const activeShipment = shipments.find((s) => s.id === activeShipmentId) || shipments[0];

  // Initial server data hydration
  useEffect(() => {
    fetch('/api/company-profile')
      .then((res) => res.json())
      .then((data) => {
        if (data.profile && data.profile.companyName) {
          setMasterProfile(data.profile);
        }
      })
      .catch(() => {});

    fetch('/api/shipments')
      .then((res) => res.json())
      .then((data) => {
        if (data.shipments && Array.isArray(data.shipments) && data.shipments.length > 0) {
          // Only overwrite if localStorage was empty
          const stored = localStorage.getItem(LOCAL_STORAGE_SHIPMENTS_KEY);
          if (!stored) {
            setShipments(data.shipments);
            if (data.shipments[0]?.id) {
              setActiveShipmentId(data.shipments[0].id);
            }
          }
        }
      })
      .catch(() => {});
  }, []);

  // Persistent auto-save sync
  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_SHIPMENTS_KEY, JSON.stringify(shipments));
      // Optional background sync to server REST API
      fetch('/api/shipments/bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ shipments }),
      }).catch(() => {});
    } catch (err) {
      console.error('Storage sync error:', err);
    }
  }, [shipments]);

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_PROFILE_KEY, JSON.stringify(masterProfile));
      fetch('/api/company-profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(masterProfile),
      }).catch(() => {});
    } catch (err) {
      console.error('Profile sync error:', err);
    }
  }, [masterProfile]);

  // Handle uploaded Header image (applies uniformly to every invoice & document)
  const handleUploadHeaderImage = (dataUrl: string) => {
    const updatedProfile: CompanyProfile = {
      ...masterProfile,
      customHeaderImage: dataUrl,
    };
    setMasterProfile(updatedProfile);

    setShipments((prev) =>
      prev.map((s) => ({
        ...s,
        exporter: {
          ...s.exporter,
          customHeaderImage: dataUrl,
        },
        updatedAt: new Date().toISOString(),
      }))
    );
  };

  // Handle uploaded Footer image (applies uniformly to every invoice & document)
  const handleUploadFooterImage = (dataUrl: string) => {
    const updatedProfile: CompanyProfile = {
      ...masterProfile,
      customFooterImage: dataUrl,
    };
    setMasterProfile(updatedProfile);

    setShipments((prev) =>
      prev.map((s) => ({
        ...s,
        exporter: {
          ...s.exporter,
          customFooterImage: dataUrl,
        },
        updatedAt: new Date().toISOString(),
      }))
    );
  };

  // Reset header & footer to pristine vector letterhead
  const handleResetHeaderImage = () => {
    const updatedProfile: CompanyProfile = {
      ...masterProfile,
      customHeaderImage: undefined,
      customFooterImage: undefined,
    };
    setMasterProfile(updatedProfile);

    setShipments((prev) =>
      prev.map((s) => ({
        ...s,
        exporter: {
          ...s.exporter,
          customHeaderImage: undefined,
          customFooterImage: undefined,
        },
        updatedAt: new Date().toISOString(),
      }))
    );
  };

  // Update active shipment
  const handleUpdateActiveShipment = (updated: ShipmentDocument) => {
    setShipments((prev) =>
      prev.map((s) => (s.id === updated.id ? updated : s))
    );
  };

  const handleUpdateStatus = (status: ShipmentStatus) => {
    if (!activeShipment) return;
    const updated: ShipmentDocument = {
      ...activeShipment,
      status,
      updatedAt: new Date().toISOString(),
    };
    handleUpdateActiveShipment(updated);
  };

  // Add Document Engine with 3 Provisioning Modes
  const handleCreateShipment = (
    mode: 'retain-exporter' | 'clone-active' | 'clean-base',
    customInvoiceNo?: string
  ) => {
    const newId = `shipment-${Date.now()}`;
    const invoiceNo = customInvoiceNo || `EXP/2026-27/${(shipments.length + 1).toString().padStart(3, '0')}`;
    const today = new Date().toISOString().split('T')[0];

    let newShipment: ShipmentDocument;

    if (mode === 'clone-active' && activeShipment) {
      // Clone active document and update invoice numbers
      newShipment = {
        ...JSON.parse(JSON.stringify(activeShipment)),
        id: newId,
        documentNumber: invoiceNo,
        invoiceDate: today,
        taxInvoiceNumber: `TAX/${invoiceNo.replace(/^EXP\//, '')}`,
        taxInvoiceDate: today,
        status: 'Draft',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
    } else if (mode === 'retain-exporter') {
      // Retain Exporter Master Profile while starting fresh dataset for buyer & items
      newShipment = {
        id: newId,
        documentNumber: invoiceNo,
        invoiceDate: today,
        taxInvoiceNumber: `TAX/${invoiceNo.replace(/^EXP\//, '')}`,
        taxInvoiceDate: today,
        status: 'Draft',
        currency: 'USD',
        exchangeRateInr: 86.50,
        incoterm: 'FOB',
        namedPortOrPlace: 'Nhava Sheva (JNPT), Mumbai',
        paymentTerms: '100% Irrevocable LC at Sight',
        customerPoNumber: '',
        customerPoDate: today,
        exporter: masterProfile,
        buyer: {
          name: '',
          address: '',
          country: '',
          contactPerson: '',
          email: '',
          phone: '',
          taxIdOrVat: '',
        },
        consignee: {
          isSameAsBuyer: true,
          name: '',
          address: '',
          country: '',
          contactPerson: '',
          taxIdOrVat: '',
        },
        notifyParty: {
          name: '',
          address: '',
          country: '',
          contactPerson: '',
          email: '',
          phone: '',
        },
        carriage: {
          preCarriageBy: 'By Road (Container Truck)',
          placeOfReceipt: masterProfile.registeredOffice.split(',')[1]?.trim() || 'Factory ICD',
          vesselFlightNo: '',
          portOfLoading: 'Nhava Sheva (JNPT), Mumbai [INNSA1]',
          portOfDischarge: '',
          finalDestination: '',
          countryOfOrigin: 'India',
          countryOfFinalDestination: '',
        },
        gstAndCustoms: {
          supplyType: 'LUT_WITHOUT_TAX',
          lutNumber: masterProfile.lutNumber || 'AD270326008492X',
          lutDate: masterProfile.lutDate || '2026-04-01',
          igstRatePercent: 0,
          shippingBillNo: 'PROVISIONAL',
          shippingBillDate: today,
          adCode: masterProfile.adCode,
          schemeCode: '19 - Duty Drawback',
          rodtepClaimDeclaration: true,
          dbkClaimDeclaration: true,
          rbiCautionListDeclaration: true,
          fema1999Declaration: true,
          edpmsBrcref: '',
        },
        lcDetails: {
          hasLc: false,
          documentaryCreditNumber: '',
          issuingDate: '',
          expiryDate: '',
          issuingBank: '',
          issuingBankAddress: '',
          advisingBankRef: '',
          latestShipmentDate: '',
          specialClauses47A: '',
          documentsRequired46A: '',
          endUseCode: '',
        },
        lineItems: [
          {
            id: `li-init-1`,
            itemNo: 1,
            marksAndNos: 'EXP/01',
            description: 'Manufactured Engineered Export Components',
            hsnCode: '84819090',
            quantity: 100,
            unit: 'PCS',
            unitPrice: 50.0,
            amount: 5000.0,
            netWeightKg: 500,
            grossWeightKg: 550,
            cbm: 0.8,
            rodtepClaimed: true,
          },
        ],
        packageDetails: [
          {
            id: `pkg-init-1`,
            packageNoRange: 'BOX 01',
            marksAndNumbers: 'EXP/01',
            packageType: 'ISPM-15 Wooden Pallet Box',
            packageCount: 1,
            lengthCm: 100,
            widthCm: 80,
            heightCm: 70,
            unitCbm: 0.56,
            totalCbm: 0.56,
            netWeightKg: 500,
            grossWeightKg: 550,
            contentsDescription: '100 PCS Manufactured Components',
          },
        ],
        freightCharge: 0,
        insuranceCharge: 0,
        handlingOrMisc: 0,
        discountAmount: 0,
        containerSummary: "1 × 20' Dry Van Container",
        specialRemarks: 'Supply meant for export under LUT without payment of IGST.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
    } else {
      // Clean Base Reference
      newShipment = {
        ...JSON.parse(JSON.stringify(INITIAL_SHIPMENTS[0])),
        id: newId,
        documentNumber: invoiceNo,
        invoiceDate: today,
        taxInvoiceNumber: `TAX/${invoiceNo.replace(/^EXP\//, '')}`,
        taxInvoiceDate: today,
        status: 'Draft',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
    }

    setShipments((prev) => [newShipment, ...prev]);
    setActiveShipmentId(newId);
    setActiveView('active-doc');
    setActiveDocTab('editor');
  };

  // Duplicate an existing shipment by ID
  const handleDuplicateShipment = (id: string) => {
    const target = shipments.find((s) => s.id === id);
    if (!target) return;
    const newId = `shipment-${Date.now()}`;
    const nextInvoiceNo = `${target.documentNumber}-COPY`;
    const today = new Date().toISOString().split('T')[0];

    const copy: ShipmentDocument = {
      ...JSON.parse(JSON.stringify(target)),
      id: newId,
      documentNumber: nextInvoiceNo,
      invoiceDate: today,
      taxInvoiceNumber: `TAX/${nextInvoiceNo.replace(/^EXP\//, '')}`,
      taxInvoiceDate: today,
      status: 'Draft',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setShipments((prev) => [copy, ...prev]);
    setActiveShipmentId(newId);
    setActiveView('active-doc');
  };

  // Delete a shipment
  const handleDeleteShipment = (id: string) => {
    if (shipments.length <= 1) return;
    setShipments((prev) => prev.filter((s) => s.id !== id));
    if (activeShipmentId === id) {
      const remaining = shipments.filter((s) => s.id !== id);
      setActiveShipmentId(remaining[0]?.id || '');
    }
  };

  // AI Audit 1-Click Auto-Fix Handler
  const handleApplyFix = (field: string, value: any) => {
    if (!activeShipment) return;
    const copy = JSON.parse(JSON.stringify(activeShipment));
    const parts = field.split('.');
    let curr = copy;
    for (let i = 0; i < parts.length - 1; i++) {
      if (!curr[parts[i]]) curr[parts[i]] = {};
      curr = curr[parts[i]];
    }
    curr[parts[parts.length - 1]] = value;
    copy.updatedAt = new Date().toISOString();
    handleUpdateActiveShipment(copy);
  };

  // Apply PO Extracted Data
  const handleApplyPoExtractedData = (data: any, createNew: boolean) => {
    if (createNew) {
      const newId = `shipment-${Date.now()}`;
      const invNo = `EXP/2026-27/${(shipments.length + 1).toString().padStart(3, '0')}`;
      const today = new Date().toISOString().split('T')[0];

      const newShipment: ShipmentDocument = {
        ...JSON.parse(JSON.stringify(INITIAL_SHIPMENTS[0])),
        id: newId,
        documentNumber: invNo,
        invoiceDate: today,
        taxInvoiceNumber: `TAX/${invNo.replace(/^EXP\//, '')}`,
        taxInvoiceDate: today,
        status: 'Draft',
        currency: (data.currency as any) || 'USD',
        incoterm: (data.incoterm as any) || 'CIF',
        namedPortOrPlace: data.namedPortOrPlace || 'Destination Port',
        paymentTerms: data.paymentTerms || '30 Days DA',
        customerPoNumber: data.poNumber || 'PO-EXTRACTED',
        customerPoDate: data.poDate || today,
        buyer: {
          name: data.buyerName || 'Global Importer',
          address: data.buyerAddress || '',
          country: data.buyerCountry || '',
          contactPerson: data.buyerEmail || '',
          email: data.buyerEmail || '',
          phone: data.buyerPhone || '',
          taxIdOrVat: data.buyerTaxId || '',
        },
        consignee: {
          isSameAsBuyer: true,
          name: data.buyerName || '',
          address: data.buyerAddress || '',
          country: data.buyerCountry || '',
          contactPerson: '',
          taxIdOrVat: data.buyerTaxId || '',
        },
        carriage: {
          ...INITIAL_SHIPMENTS[0].carriage,
          portOfDischarge: data.portOfDischarge || 'Destination Port',
          finalDestination: data.finalDestination || '',
          countryOfFinalDestination: data.buyerCountry || '',
        },
        lineItems: (data.lineItems || []).map((item: any, idx: number) => ({
          id: `li-ext-${idx}`,
          itemNo: idx + 1,
          marksAndNos: `EXP/${idx + 1}`,
          description: item.description || 'Export Merchandise',
          hsnCode: item.hsnCode || '84819090',
          quantity: item.quantity || 100,
          unit: item.unit || 'PCS',
          unitPrice: item.unitPrice || 50,
          amount: (item.quantity || 100) * (item.unitPrice || 50),
          netWeightKg: item.netWeightKg || 500,
          grossWeightKg: item.grossWeightKg || 550,
          cbm: 0.8,
          rodtepClaimed: true,
        })),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      setShipments((prev) => [newShipment, ...prev]);
      setActiveShipmentId(newId);
      setActiveView('active-doc');
      setActiveDocTab('commercial');
    } else if (activeShipment) {
      // Merge into active shipment
      const copy: ShipmentDocument = {
        ...JSON.parse(JSON.stringify(activeShipment)),
        customerPoNumber: data.poNumber || activeShipment.customerPoNumber,
        customerPoDate: data.poDate || activeShipment.customerPoDate,
        currency: (data.currency as any) || activeShipment.currency,
        incoterm: (data.incoterm as any) || activeShipment.incoterm,
        namedPortOrPlace: data.namedPortOrPlace || activeShipment.namedPortOrPlace,
        paymentTerms: data.paymentTerms || activeShipment.paymentTerms,
        buyer: {
          ...activeShipment.buyer,
          name: data.buyerName || activeShipment.buyer.name,
          address: data.buyerAddress || activeShipment.buyer.address,
          country: data.buyerCountry || activeShipment.buyer.country,
          taxIdOrVat: data.buyerTaxId || activeShipment.buyer.taxIdOrVat,
        },
        lineItems: data.lineItems?.length
          ? data.lineItems.map((item: any, idx: number) => ({
              id: `li-ext-${idx}`,
              itemNo: idx + 1,
              marksAndNos: `EXP/${idx + 1}`,
              description: item.description,
              hsnCode: item.hsnCode || '84819090',
              quantity: item.quantity || 1,
              unit: item.unit || 'PCS',
              unitPrice: item.unitPrice || 1,
              amount: (item.quantity || 1) * (item.unitPrice || 1),
              netWeightKg: item.netWeightKg || 100,
              grossWeightKg: item.grossWeightKg || 120,
              cbm: 0.5,
              rodtepClaimed: true,
            }))
          : activeShipment.lineItems,
        updatedAt: new Date().toISOString(),
      };
      handleUpdateActiveShipment(copy);
      setActiveView('active-doc');
      setActiveDocTab('commercial');
    }
  };

  // Master company profile save
  const handleSaveCompanyProfile = (updatedProfile: CompanyProfile) => {
    setMasterProfile(updatedProfile);
    // Propagate updated exporter details uniformly to all shipments
    setShipments((prev) =>
      prev.map((s) => ({
        ...s,
        exporter: {
          ...updatedProfile,
          stationeryTopMarginMm: s.exporter.stationeryTopMarginMm ?? updatedProfile.stationeryTopMarginMm,
          stationeryBottomMarginMm: s.exporter.stationeryBottomMarginMm ?? updatedProfile.stationeryBottomMarginMm,
        },
        updatedAt: new Date().toISOString(),
      }))
    );
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans">
      {/* 1. Header Navigation Bar */}
      <Header
        activeView={activeView}
        setActiveView={setActiveView}
        shipments={shipments}
        activeShipmentId={activeShipmentId}
        onSelectShipment={setActiveShipmentId}
        onOpenNewDocumentModal={() => setIsNewDocModalOpen(true)}
        onOpenAiAudit={() => setIsAiAuditModalOpen(true)}
        onOpenPoExtractor={() => setIsPoExtractorModalOpen(true)}
      />

      {/* 2. Main Content Viewport */}
      <main className="flex-1">
        {/* VIEW A: Active Document View */}
        {activeView === 'active-doc' && activeShipment && (
          <div className="space-y-6 pb-16">
            {/* Document Sub-Toolbar */}
            <DocumentToolbar
              shipment={activeShipment}
              activeDocTab={activeDocTab}
              setActiveDocTab={setActiveDocTab}
              documentMode={documentMode}
              setDocumentMode={setDocumentMode}
              printMode={printMode}
              setPrintMode={setPrintMode}
              stationeryTopMarginMm={stationeryTopMarginMm}
              setStationeryTopMarginMm={setStationeryTopMarginMm}
              stationeryBottomMarginMm={stationeryBottomMarginMm}
              setStationeryBottomMarginMm={setStationeryBottomMarginMm}
              onUpdateStatus={handleUpdateStatus}
              onOpenAiAudit={() => setIsAiAuditModalOpen(true)}
              onUploadHeaderImage={handleUploadHeaderImage}
              onUploadFooterImage={handleUploadFooterImage}
              onResetHeaderImage={handleResetHeaderImage}
            />

            {/* Document Container */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              {(() => {
                const docShipment = {
                  ...activeShipment,
                  exporter: {
                    ...activeShipment.exporter,
                    customHeaderImage:
                      activeShipment.exporter.customHeaderImage ||
                      masterProfile.customHeaderImage,
                    customFooterImage:
                      activeShipment.exporter.customFooterImage ||
                      masterProfile.customFooterImage,
                  },
                };

                return (
                  <>
                    {/* Document 1: Normal Export Invoice */}
                    {(activeDocTab === 'export_invoice' || (activeDocTab === 'commercial' && !docShipment.lcDetails?.hasLc)) && (
                      <div className="print-document-container">
                        <CommercialInvoiceView
                          shipment={docShipment}
                          printMode={printMode}
                          isLcFormat={false}
                          stationeryTopMarginMm={stationeryTopMarginMm}
                          stationeryBottomMarginMm={stationeryBottomMarginMm}
                        />
                      </div>
                    )}

                    {/* Document 2: Normal Packing List */}
                    {(activeDocTab === 'packing_list' || (activeDocTab === 'packing' && !docShipment.lcDetails?.hasLc)) && (
                      <div className="print-document-container">
                        <PackingListView
                          shipment={docShipment}
                          printMode={printMode}
                          isLcFormat={false}
                          stationeryTopMarginMm={stationeryTopMarginMm}
                          stationeryBottomMarginMm={stationeryBottomMarginMm}
                        />
                      </div>
                    )}

                    {/* Document 3: Normal Tax Invoice */}
                    {(activeDocTab === 'tax_invoice' || (activeDocTab === 'tax' && !docShipment.lcDetails?.hasLc)) && (
                      <div className="print-document-container">
                        <TaxInvoiceView
                          shipment={docShipment}
                          printMode={printMode}
                          isLcFormat={false}
                          stationeryTopMarginMm={stationeryTopMarginMm}
                          stationeryBottomMarginMm={stationeryBottomMarginMm}
                        />
                      </div>
                    )}

                    {/* Document 4: LC Export Invoice */}
                    {(activeDocTab === 'lc_export_invoice' || (activeDocTab === 'commercial' && docShipment.lcDetails?.hasLc)) && (
                      <div className="print-document-container">
                        <CommercialInvoiceView
                          shipment={docShipment}
                          printMode={printMode}
                          isLcFormat={true}
                          stationeryTopMarginMm={stationeryTopMarginMm}
                          stationeryBottomMarginMm={stationeryBottomMarginMm}
                        />
                      </div>
                    )}

                    {/* Document 5: LC Packing List */}
                    {(activeDocTab === 'lc_packing_list' || (activeDocTab === 'packing' && docShipment.lcDetails?.hasLc)) && (
                      <div className="print-document-container">
                        <PackingListView
                          shipment={docShipment}
                          printMode={printMode}
                          isLcFormat={true}
                          stationeryTopMarginMm={stationeryTopMarginMm}
                          stationeryBottomMarginMm={stationeryBottomMarginMm}
                        />
                      </div>
                    )}

                    {/* Document 6: LC Tax Invoice */}
                    {(activeDocTab === 'lc_tax_invoice' || (activeDocTab === 'tax' && docShipment.lcDetails?.hasLc)) && (
                      <div className="print-document-container">
                        <TaxInvoiceView
                          shipment={docShipment}
                          printMode={printMode}
                          isLcFormat={true}
                          stationeryTopMarginMm={stationeryTopMarginMm}
                          stationeryBottomMarginMm={stationeryBottomMarginMm}
                        />
                      </div>
                    )}

                    {/* Document Editor */}
                    {activeDocTab === 'editor' && (
                      <DocumentEditor
                        shipment={activeShipment}
                        onUpdateShipment={handleUpdateActiveShipment}
                        onOpenAiAudit={() => setIsAiAuditModalOpen(true)}
                      />
                    )}
                  </>
                );
              })()}
            </div>
          </div>
        )}

        {/* VIEW B: Shipments Archive */}
        {activeView === 'archive' && (
          <ShipmentArchive
            shipments={shipments}
            activeShipmentId={activeShipmentId}
            onSelectShipment={(id) => {
              setActiveShipmentId(id);
              setActiveView('active-doc');
            }}
            onDuplicateShipment={handleDuplicateShipment}
            onDeleteShipment={handleDeleteShipment}
            onOpenNewDocumentModal={() => setIsNewDocModalOpen(true)}
          />
        )}

        {/* VIEW C: Master Exporter Profile Settings */}
        {activeView === 'company-profile' && (
          <CompanyProfileSettings
            profile={masterProfile}
            onSaveProfile={handleSaveCompanyProfile}
          />
        )}
      </main>

      {/* 3. Modals */}
      <NewDocumentModal
        isOpen={isNewDocModalOpen}
        onClose={() => setIsNewDocModalOpen(false)}
        activeShipment={activeShipment}
        masterProfile={masterProfile}
        onCreateShipment={handleCreateShipment}
      />

      <AiAuditModal
        isOpen={isAiAuditModalOpen}
        onClose={() => setIsAiAuditModalOpen(false)}
        shipment={activeShipment}
        onApplyFix={handleApplyFix}
      />

      <PoExtractorModal
        isOpen={isPoExtractorModalOpen}
        onClose={() => setIsPoExtractorModalOpen(false)}
        onApplyExtractedData={handleApplyPoExtractedData}
      />
    </div>
  );
}
