export type Currency = 'USD' | 'EUR' | 'GBP' | 'AED' | 'INR' | 'JPY' | 'CAD' | 'AUD';

export type Incoterm = 'FOB' | 'CIF' | 'CFR' | 'EXW' | 'FCA' | 'CIP' | 'CPT' | 'DDP' | 'DAP';

export type ShipmentStatus = 'Draft' | 'Generated' | 'Customs Cleared' | 'Dispatched';

export type SupplyType = 'LUT_WITHOUT_TAX' | 'WITH_IGST';

export type ExportDocumentMode = 'all' | 'normal' | 'lc';

export type DocumentTab =
  | 'export_invoice'      // Normal Export Invoice
  | 'packing_list'        // Normal Packing List
  | 'tax_invoice'         // Normal Tax Invoice
  | 'lc_export_invoice'   // LC Export Invoice
  | 'lc_packing_list'     // LC Packing List
  | 'lc_tax_invoice'      // LC Tax Invoice
  | 'commercial'          // Legacy / fallback alias
  | 'packing'             // Legacy / fallback alias
  | 'tax'                 // Legacy / fallback alias
  | 'editor';

export interface CompanyProfile {
  companyName: string;
  tradingName?: string;
  registeredOffice: string;
  factoryAddress: string;
  contactPerson: string;
  phone: string;
  email: string;
  website: string;
  iecCode: string; // 10-digit
  gstin: string; // 15-digit
  panNumber: string; // 10-digit
  stateName: string;
  stateCode: string; // 2-digit e.g. 27
  adCode: string; // Authorized Dealer Code (e.g. 0510002-4820194 or 14 digits)
  bankName: string;
  bankBranch: string;
  bankBranchAddress: string;
  accountNumber: string;
  accountType: string;
  swiftCode: string;
  ifscCode: string;
  lutNumber: string;
  lutDate: string;
  signatoryName: string;
  signatoryDesignation: string;
  signatureImage?: string; // base64 / data URL
  stampImage?: string; // base64 / data URL
  logoImage?: string; // base64 / data URL
  customHeaderImage?: string; // base64 / data URL for uploaded header image
  customFooterImage?: string; // base64 / data URL for uploaded footer image
  isoCertification: string; // e.g. "ISO 9001:2015 & IATF 16949 Certified"
  aeoStatus: string; // e.g. "AEO-T1 Certified Exporter"
  // Stationery print offsets
  stationeryTopMarginMm: number; // default 55mm
  stationeryBottomMarginMm: number; // default 25mm
  stationeryLeftMarginMm: number; // default 12mm
  stationeryRightMarginMm: number; // default 12mm
}

export interface LineItem {
  id: string;
  itemNo: number;
  marksAndNos: string;
  description: string;
  hsnCode: string; // 6 or 8 digits
  quantity: number;
  unit: string; // PCS, KGS, MTR, SETS, BOX, NOS
  unitPrice: number;
  amount: number;
  netWeightKg: number;
  grossWeightKg: number;
  cbm: number;
  dbkSerialNo?: string; // Duty Drawback Serial Number
  rodtepClaimed?: boolean;
}

export interface PackageDetail {
  id: string;
  packageNoRange: string; // e.g. "PKG 01 - 04" or "BOX 1 TO 10"
  marksAndNumbers: string; // e.g. "EXP/DE/01 TO 10, HAMBURG"
  packageType: string; // "Wooden Case", "Corrugated Carton", "Euro Pallet", "Steel Drum"
  packageCount: number;
  lengthCm: number;
  widthCm: number;
  heightCm: number;
  unitCbm: number; // (L * W * H) / 1,000,000
  totalCbm: number; // unitCbm * packageCount
  netWeightKg: number;
  grossWeightKg: number;
  contentsDescription: string;
}

export interface BuyerParty {
  name: string;
  address: string;
  country: string;
  contactPerson: string;
  email: string;
  phone: string;
  taxIdOrVat: string;
}

export interface ConsigneeParty {
  isSameAsBuyer: boolean;
  name: string;
  address: string;
  country: string;
  contactPerson: string;
  taxIdOrVat: string;
}

export interface NotifyParty {
  name: string;
  address: string;
  country: string;
  contactPerson: string;
  email: string;
  phone: string;
}

export interface CarriageDetails {
  preCarriageBy: string; // e.g. "By Road Container Truck"
  placeOfReceipt: string; // e.g. "ICD Tughlakabad, New Delhi"
  vesselFlightNo: string; // e.g. "MSC LAURA / V.241E"
  portOfLoading: string; // e.g. "Nhava Sheva (JNPT), Mumbai [INNSA1]"
  portOfDischarge: string; // e.g. "Port of Hamburg, Germany [DEHAM]"
  finalDestination: string; // e.g. "Stuttgart, Germany"
  countryOfOrigin: string; // e.g. "India"
  countryOfFinalDestination: string; // e.g. "Germany"
}

export interface GstAndCustomsDetails {
  supplyType: SupplyType;
  lutNumber: string;
  lutDate: string;
  igstRatePercent: number; // 0 for LUT, or 18 / 12 / 5
  shippingBillNo: string;
  shippingBillDate: string;
  adCode: string;
  schemeCode: string; // e.g. "19 - Duty Drawback", "60 - RoDTEP", "00 - Free Shipping Bill"
  rodtepClaimDeclaration: boolean;
  dbkClaimDeclaration: boolean;
  rbiCautionListDeclaration: boolean;
  fema1999Declaration: boolean;
  edpmsBrcref: string;
}

export interface LetterOfCreditDetails {
  hasLc: boolean;
  documentaryCreditNumber: string; // LC No.
  issuingDate: string;
  expiryDate: string;
  issuingBank: string;
  issuingBankAddress: string;
  advisingBankRef: string;
  latestShipmentDate: string;
  specialClauses47A: string;
  documentsRequired46A: string;
  endUseCode: string;
}

export interface ShipmentDocument {
  id: string;
  documentNumber: string; // e.g. "EXP/2026-27/001"
  invoiceDate: string;
  taxInvoiceNumber: string; // e.g. "TAX/26-27/001"
  taxInvoiceDate: string;
  status: ShipmentStatus;
  currency: Currency;
  exchangeRateInr: number; // e.g. 86.50
  incoterm: Incoterm;
  namedPortOrPlace: string;
  paymentTerms: string;
  customerPoNumber: string;
  customerPoDate: string;
  exporter: CompanyProfile;
  buyer: BuyerParty;
  consignee: ConsigneeParty;
  notifyParty: NotifyParty;
  carriage: CarriageDetails;
  gstAndCustoms: GstAndCustomsDetails;
  lcDetails: LetterOfCreditDetails;
  lineItems: LineItem[];
  packageDetails: PackageDetail[];
  freightCharge: number;
  insuranceCharge: number;
  handlingOrMisc: number;
  discountAmount: number;
  containerSummary: string; // e.g. "1 × 20' FCL (Container No: MSCU 928374-1 / Seal: INDE 83921)"
  specialRemarks: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuditIssue {
  id: string;
  category: 'Math' | 'GST_Customs' | 'Carriage_Ports' | 'LC_Regulatory' | 'HSN';
  severity: 'critical' | 'warning' | 'info';
  field: string;
  title: string;
  description: string;
  recommendation: string;
  autoFixable?: boolean;
  suggestedFixValue?: any;
}

export interface ComplianceAuditResult {
  overallScore: number;
  status: 'PASS' | 'NEEDS_ATTENTION' | 'CRITICAL_ISSUES';
  summary: string;
  mathAudit: {
    isMathAccurate: boolean;
    calculatedTotal: number;
    statedTotal: number;
    calculatedNetWeight: number;
    statedNetWeight: number;
    calculatedGrossWeight: number;
    statedGrossWeight: number;
    weightDiscrepancyNotes: string;
  };
  issues: AuditIssue[];
  customsAdvice: string[];
}
