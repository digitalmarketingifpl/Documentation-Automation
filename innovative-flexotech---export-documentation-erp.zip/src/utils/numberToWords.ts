const ONES = [
  '',
  'One',
  'Two',
  'Three',
  'Four',
  'Five',
  'Six',
  'Seven',
  'Eight',
  'Nine',
  'Ten',
  'Eleven',
  'Twelve',
  'Thirteen',
  'Fourteen',
  'Fifteen',
  'Sixteen',
  'Seventeen',
  'Eighteen',
  'Nineteen',
];

const TENS = [
  '',
  '',
  'Twenty',
  'Thirty',
  'Forty',
  'Fifty',
  'Sixty',
  'Seventy',
  'Eighty',
  'Ninety',
];

function convertThreeDigitGroup(num: number): string {
  let str = '';
  const hundreds = Math.floor(num / 100);
  const remainder = num % 100;

  if (hundreds > 0) {
    str += `${ONES[hundreds]} Hundred`;
    if (remainder > 0) {
      str += ' ';
    }
  }

  if (remainder > 0) {
    if (remainder < 20) {
      str += ONES[remainder];
    } else {
      const ten = Math.floor(remainder / 10);
      const unit = remainder % 10;
      str += TENS[ten];
      if (unit > 0) {
        str += ` ${ONES[unit]}`;
      }
    }
  }

  return str;
}

/**
 * Converts a number to International English Words (Thousands, Millions, Billions)
 * e.g., 45250.50 with USD -> "US Dollars Forty-Five Thousand Two Hundred Fifty and Cents Fifty Only"
 */
export function convertToInternationalWords(
  amount: number,
  currencyCode: string = 'USD'
): string {
  if (isNaN(amount) || amount === 0) {
    return `${getCurrencyPrefix(currencyCode)} Zero Only`;
  }

  const absoluteAmount = Math.abs(amount);
  const integerPart = Math.floor(absoluteAmount);
  const decimalPart = Math.round((absoluteAmount - integerPart) * 100);

  if (integerPart === 0 && decimalPart === 0) {
    return `${getCurrencyPrefix(currencyCode)} Zero Only`;
  }

  const parts: string[] = [];
  const billions = Math.floor(integerPart / 1_000_000_000);
  const millions = Math.floor((integerPart % 1_000_000_000) / 1_000_000);
  const thousands = Math.floor((integerPart % 1_000_000) / 1_000);
  const remainder = integerPart % 1_000;

  if (billions > 0) {
    parts.push(`${convertThreeDigitGroup(billions)} Billion`);
  }
  if (millions > 0) {
    parts.push(`${convertThreeDigitGroup(millions)} Million`);
  }
  if (thousands > 0) {
    parts.push(`${convertThreeDigitGroup(thousands)} Thousand`);
  }
  if (remainder > 0) {
    parts.push(convertThreeDigitGroup(remainder));
  }

  let result = parts.join(' ').trim();
  const currencyPrefix = getCurrencyPrefix(currencyCode);
  const fractionName = getFractionUnit(currencyCode);

  if (decimalPart > 0) {
    const decimalWords = convertThreeDigitGroup(decimalPart);
    return `${currencyPrefix} ${result} and ${fractionName} ${decimalWords} Only`;
  }

  return `${currencyPrefix} ${result} Only`;
}

/**
 * Converts a number to Indian Numbering System words (Crores, Lakhs, Thousands, Hundreds)
 * e.g., 3963430.50 -> "INR Thirty-Nine Lakhs Sixty-Three Thousand Four Hundred Thirty and Paise Fifty Only"
 */
export function convertToIndianWords(
  amount: number,
  currencyCode: string = 'INR'
): string {
  if (isNaN(amount) || amount === 0) {
    return `${currencyCode === 'INR' ? 'INR' : currencyCode} Zero Only`;
  }

  const absoluteAmount = Math.abs(amount);
  const integerPart = Math.floor(absoluteAmount);
  const decimalPart = Math.round((absoluteAmount - integerPart) * 100);

  if (integerPart === 0 && decimalPart === 0) {
    return `${currencyCode === 'INR' ? 'INR' : currencyCode} Zero Only`;
  }

  const parts: string[] = [];

  const crores = Math.floor(integerPart / 10_000_000);
  const afterCrores = integerPart % 10_000_000;

  const lakhs = Math.floor(afterCrores / 100_000);
  const afterLakhs = afterCrores % 100_000;

  const thousands = Math.floor(afterLakhs / 1_000);
  const remainder = afterLakhs % 1_000;

  if (crores > 0) {
    parts.push(`${convertTwoDigitGroup(crores)} Crore${crores > 1 ? 's' : ''}`);
  }
  if (lakhs > 0) {
    parts.push(`${convertTwoDigitGroup(lakhs)} Lakh${lakhs > 1 ? 's' : ''}`);
  }
  if (thousands > 0) {
    parts.push(`${convertTwoDigitGroup(thousands)} Thousand`);
  }
  if (remainder > 0) {
    parts.push(convertThreeDigitGroup(remainder));
  }

  const result = parts.join(' ').trim();
  const prefix = currencyCode === 'INR' ? 'INR' : currencyCode;
  const fractionName = currencyCode === 'INR' ? 'Paise' : 'Cents';

  if (decimalPart > 0) {
    const decimalWords = convertTwoDigitGroup(decimalPart);
    return `${prefix} ${result} and ${fractionName} ${decimalWords} Only`;
  }

  return `${prefix} ${result} Only`;
}

function convertTwoDigitGroup(num: number): string {
  if (num < 20) {
    return ONES[num];
  }
  const ten = Math.floor(num / 10);
  const unit = num % 10;
  return unit > 0 ? `${TENS[ten]} ${ONES[unit]}` : TENS[ten];
}

function getCurrencyPrefix(code: string): string {
  switch (code) {
    case 'USD':
      return 'US Dollars';
    case 'EUR':
      return 'Euros';
    case 'GBP':
      return 'Pounds Sterling';
    case 'AED':
      return 'UAE Dirhams';
    case 'INR':
      return 'Indian Rupees';
    case 'JPY':
      return 'Japanese Yen';
    case 'CAD':
      return 'Canadian Dollars';
    case 'AUD':
      return 'Australian Dollars';
    default:
      return code;
  }
}

function getFractionUnit(code: string): string {
  switch (code) {
    case 'USD':
    case 'CAD':
    case 'AUD':
    case 'EUR':
      return 'Cents';
    case 'GBP':
      return 'Pence';
    case 'AED':
      return 'Fils';
    case 'INR':
      return 'Paise';
    case 'JPY':
      return 'Sen';
    default:
      return 'Cents';
  }
}
