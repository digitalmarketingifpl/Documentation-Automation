import { INNOVATIVE_HEADER_IMAGE_BASE64 } from "./brandingAssets";
import { jsPDF } from 'jspdf';
import { ShipmentDocument } from '../types/trade';
import { calculateShipmentSummary } from './calculations';
import { convertToInternationalWords, convertToIndianWords } from './numberToWords';

export type PdfExportDocType =
  | 'export_invoice'
  | 'packing_list'
  | 'tax_invoice'
  | 'lc_export_invoice'
  | 'lc_packing_list'
  | 'lc_tax_invoice'
  | 'all_6'
  | 'normal_pack'
  | 'lc_pack'
  | 'commercial'
  | 'packing'
  | 'tax'
  | 'all';

export function exportDocumentVectorPdf(
  shipment: ShipmentDocument,
  docType: PdfExportDocType,
  mode: 'digital' | 'preprinted' = 'digital'
): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const summary = calculateShipmentSummary(shipment);
  const isPreprinted = mode === 'preprinted';

  if (docType === 'all_6') {
    // All 6 Documents
    renderCommercialInvoicePage(doc, shipment, summary, isPreprinted, false);
    doc.addPage();
    renderPackingListPage(doc, shipment, summary, isPreprinted, false);
    doc.addPage();
    renderTaxInvoicePage(doc, shipment, summary, isPreprinted, false);
    doc.addPage();
    renderCommercialInvoicePage(doc, shipment, summary, isPreprinted, true);
    doc.addPage();
    renderPackingListPage(doc, shipment, summary, isPreprinted, true);
    doc.addPage();
    renderTaxInvoicePage(doc, shipment, summary, isPreprinted, true);
  } else if (docType === 'normal_pack') {
    // 3 Normal Documents
    renderCommercialInvoicePage(doc, shipment, summary, isPreprinted, false);
    doc.addPage();
    renderPackingListPage(doc, shipment, summary, isPreprinted, false);
    doc.addPage();
    renderTaxInvoicePage(doc, shipment, summary, isPreprinted, false);
  } else if (docType === 'lc_pack' || docType === 'all') {
    // 3 LC Documents
    renderCommercialInvoicePage(doc, shipment, summary, isPreprinted, true);
    doc.addPage();
    renderPackingListPage(doc, shipment, summary, isPreprinted, true);
    doc.addPage();
    renderTaxInvoicePage(doc, shipment, summary, isPreprinted, true);
  } else if (docType === 'export_invoice') {
    renderCommercialInvoicePage(doc, shipment, summary, isPreprinted, false);
  } else if (docType === 'lc_export_invoice' || docType === 'commercial') {
    renderCommercialInvoicePage(doc, shipment, summary, isPreprinted, docType === 'commercial' ? (shipment.lcDetails?.hasLc ?? true) : true);
  } else if (docType === 'packing_list') {
    renderPackingListPage(doc, shipment, summary, isPreprinted, false);
  } else if (docType === 'lc_packing_list' || docType === 'packing') {
    renderPackingListPage(doc, shipment, summary, isPreprinted, docType === 'packing' ? (shipment.lcDetails?.hasLc ?? true) : true);
  } else if (docType === 'tax_invoice') {
    renderTaxInvoicePage(doc, shipment, summary, isPreprinted, false);
  } else if (docType === 'lc_tax_invoice' || docType === 'tax') {
    renderTaxInvoicePage(doc, shipment, summary, isPreprinted, docType === 'tax' ? (shipment.lcDetails?.hasLc ?? true) : true);
  }

  const totalPages = doc.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFont('times', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(120, 120, 120);
    doc.text(
      `Innovative Flexotech Pvt Ltd  |  Doc: ${shipment.documentNumber}  |  Page ${i} of ${totalPages}`,
      105,
      292,
      { align: 'center' }
    );
  }

  const prefix =
    docType === 'all_6'
      ? 'All_6_Documents_Binder'
      : docType === 'normal_pack'
      ? 'Normal_Export_Pack'
      : docType === 'lc_pack' || docType === 'all'
      ? 'LC_Export_Pack'
      : docType.toUpperCase();
  const filename = `Innovative_Flexotech_${shipment.documentNumber.replace(/[^a-zA-Z0-9_-]/g, '_')}_${prefix}.pdf`;
  doc.save(filename);
}

// -------------------------------------------------------------
// REUSABLE PDF HEADER & FOOTER
// -------------------------------------------------------------
function drawPdfHeader(
  doc: jsPDF,
  shipment: ShipmentDocument,
  isPreprinted: boolean,
  startX: number,
  y: number,
  tableW: number
): number {
  if (isPreprinted) {
    return shipment.exporter.stationeryTopMarginMm || 55;
  }

  // If custom header image or default image is available, embed exact header
  const headerImg = shipment.exporter.customHeaderImage || INNOVATIVE_HEADER_IMAGE_BASE64;
  if (headerImg) {
    try {
      doc.addImage(headerImg, 'JPEG', startX, y, tableW, 20);
      return y + 22;
    } catch {
      // fallback to vector
    }
  }

  // 1:1 Vector Branding for Innovative Flexotech
  doc.setFillColor(200, 30, 30);
  doc.rect(startX, y, 12, 12, 'F');
  doc.setFont('times', 'italic');
  doc.setFontSize(22);
  doc.setTextColor(255, 255, 255);
  doc.text('i', startX + 4, y + 9.5);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(15, 23, 42);
  doc.text('COMPLETE FLEXO SOLUTION', startX + 14, y + 3);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(200, 30, 30);
  doc.text('INNOVATIVE', startX + 14, y + 7.5);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(15, 23, 42);
  doc.text('FLEXOTECH PVT LTD', startX + 14, y + 10.5);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.5);
  doc.text('AN ISO 9001:2015 CERTIFIED COMPANY  |  www.flexo.co.in', startX + 14, y + 13.5);

  // Right bullets
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7);
  doc.setTextColor(15, 23, 42);
  doc.text('Manufacturer of', startX + tableW, y + 3, { align: 'right' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.5);
  doc.text('Photopolymer Plate Making Equipment', startX + tableW, y + 6.5, { align: 'right' });
  doc.text('Solvent Recovery', startX + tableW, y + 9.5, { align: 'right' });
  doc.text('Flexo Printing Press', startX + tableW, y + 12.5, { align: 'right' });

  // Red line
  doc.setDrawColor(200, 30, 30);
  doc.setLineWidth(0.6);
  doc.line(startX, y + 15, startX + tableW, y + 15);

  return y + 18;
}

function drawPdfFooter(
  doc: jsPDF,
  shipment: ShipmentDocument,
  isPreprinted: boolean,
  startX: number,
  y: number,
  tableW: number
) {
  if (isPreprinted) return;

  if (shipment.exporter.customFooterImage) {
    try {
      doc.addImage(shipment.exporter.customFooterImage, 'JPEG', startX, y, tableW, 14);
      return;
    } catch {
      // fallback
    }
  }

  doc.setDrawColor(185, 28, 28);
  doc.setLineWidth(0.4);
  doc.line(startX, y, startX + tableW, y);
  doc.setFont('times', 'normal');
  doc.setFontSize(6);
  doc.setTextColor(50, 50, 50);
  y += 3.5;
  doc.text('Office : 436, Patel Avenue, Nr. Gurudwara, Thaltej, Ahmedabad-380059. Gujarat (INDIA) | Tel: +91 98240 96180 | Email: info@flexo.co.in', startX, y);
  y += 3;
  doc.text('Plant I : Plot No. 33, Hansalpur, GIDC, Viramgam, Dist. Ahmedabad–382150. Gujarat.', startX, y);
  y += 3;
  doc.text('Plant II : Plot B/8, Shyam Ujjwal Estate, Gate No. 3, Opp. SBI Bank, Bombay Conductor Road, Vatva GIDC Phase-I, Ahmedabad-382445, Gujarat.', startX, y);
}

// -------------------------------------------------------------
// COMMERCIAL INVOICE PDF
// -------------------------------------------------------------
function renderCommercialInvoicePage(
  doc: jsPDF,
  shipment: ShipmentDocument,
  summary: ReturnType<typeof calculateShipmentSummary>,
  isPreprinted: boolean,
  isLc?: boolean
) {
  const tableW = 182;
  const startX = 14;
  let y = isPreprinted ? (shipment.exporter.stationeryTopMarginMm || 55) : 8;
  const hasLc = isLc !== undefined ? isLc : (shipment.lcDetails?.hasLc ?? true);

  y = drawPdfHeader(doc, shipment, isPreprinted, startX, y, tableW);

  // Black Frame Grid
  doc.setDrawColor(0, 0, 0);
  doc.setLineWidth(0.3);

  // Title Row
  doc.rect(startX, y, tableW, 6);
  doc.setFont('times', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(0, 0, 0);
  doc.text(hasLc ? 'LC EXPORT INVOICE' : 'EXPORT INVOICE', 105, y + 4.2, { align: 'center' });

  y += 6;

  // Row 1: Exporter | Invoice No & Date | Exporter's Ref
  const r1H = 26;
  doc.rect(startX, y, tableW, r1H);
  doc.line(startX + 78, y, startX + 78, y + r1H);
  doc.line(startX + 138, y, startX + 138, y + r1H);

  // Col 1: Exporter
  doc.setFont('times', 'bold');
  doc.setFontSize(6.5);
  doc.text('Manufacturer/Producer/Exporter', startX + 1.5, y + 3.5);
  doc.text(`GSTIN : ${shipment.exporter.gstin || '24AABCI7261H1ZO'}`, startX + 1.5, y + 7);
  doc.text(shipment.exporter.tradingName || 'Innovative Flexotech Pvt Ltd.', startX + 1.5, y + 10.5);
  doc.setFont('times', 'normal');
  doc.setFontSize(6);
  doc.text('FF/4,Rameshwar Residency,', startX + 1.5, y + 14);
  doc.text('BS Kalash-3,Ghuma Village, Ahmedabad, Gujarat-380058', startX + 1.5, y + 17.5);
  doc.text(`Mo. ${shipment.exporter.phone || '98240 96180'}`, startX + 1.5, y + 21);

  // Col 2: Invoice No & Date
  doc.setFont('times', 'bold');
  doc.setFontSize(6.5);
  doc.text('Invoice No. & Date', startX + 79.5, y + 3.5);
  doc.text(`Invoice No. : ${shipment.documentNumber}`, startX + 79.5, y + 7.5);
  doc.text(`Date : ${shipment.invoiceDate}`, startX + 79.5, y + 11.5);
  if (hasLc) {
    doc.setFontSize(6);
    doc.text(`LC NO. : ${shipment.lcDetails?.documentaryCreditNumber || 'LC/2026/SL/00492'}`, startX + 79.5, y + 16);
    doc.text(`Advising Ref : ${shipment.lcDetails?.advisingBankRef || '26ELF08102489095'}`, startX + 79.5, y + 19.5);
  } else if (shipment.customerPoNumber) {
    doc.setFontSize(6);
    doc.text(`Order No. : ${shipment.customerPoNumber}`, startX + 79.5, y + 16);
    doc.text(`Order Date : ${shipment.customerPoDate || shipment.invoiceDate}`, startX + 79.5, y + 19.5);
  }

  // Col 3: Exporter's Ref
  doc.setFont('times', 'bold');
  doc.setFontSize(6.5);
  doc.text("Exporter's Ref.", startX + 139.5, y + 3.5);
  doc.setFont('times', 'normal');
  doc.text(`IEC No. : ${shipment.exporter.iecCode || '807016772'}`, startX + 139.5, y + 7.5);
  doc.text('BIN No. :', startX + 139.5, y + 11.5);

  y += r1H;

  // Row 2: Consignee & Buyer
  const r2H = 22;
  doc.rect(startX, y, tableW, r2H);
  doc.line(startX + 91, y, startX + 91, y + r2H);

  doc.setFont('times', 'bold');
  doc.setFontSize(7);
  doc.text(hasLc ? 'Applicant' : 'Consignee', startX + 1.5, y + 3.5);
  doc.setFont('times', 'normal');
  doc.setFontSize(6.5);
  const leftBuyer = hasLc ? shipment.buyer : (shipment.consignee.isSameAsBuyer ? shipment.buyer : shipment.consignee);
  doc.text(leftBuyer.name.slice(0, 50), startX + 1.5, y + 7.5);
  doc.text(leftBuyer.address.slice(0, 55), startX + 1.5, y + 11);
  doc.text(leftBuyer.address.slice(55, 110), startX + 1.5, y + 14.5);
  doc.text(leftBuyer.address.slice(110, 160), startX + 1.5, y + 18);

  // Right: Buyer's Name & Address
  doc.setFont('times', 'bold');
  doc.setFontSize(7);
  doc.text(hasLc ? 'Consignee' : "Buyer's Name & Address", startX + 92.5, y + 3.5);
  doc.setFont('times', 'normal');
  doc.setFontSize(6.5);
  const rightBuyer = hasLc ? shipment.consignee : shipment.buyer;
  doc.text(rightBuyer.name.slice(0, 50), startX + 92.5, y + 7.5);
  doc.text(rightBuyer.address.slice(0, 55), startX + 92.5, y + 11);
  doc.text(rightBuyer.address.slice(55, 110), startX + 92.5, y + 14.5);
  doc.text(rightBuyer.address.slice(110, 160), startX + 92.5, y + 18);

  y += r2H;

  // Row 3: Carriage Details
  const r3H = 8;
  doc.rect(startX, y, tableW, r3H);
  doc.line(startX + 45, y, startX + 45, y + r3H);
  doc.line(startX + 91, y, startX + 91, y + r3H);
  doc.line(startX + 136, y, startX + 136, y + r3H);

  doc.setFont('times', 'bold');
  doc.setFontSize(6);
  doc.text('Pre-Carriage by', startX + 1.5, y + 2.5);
  doc.text('Place of receipt by Pre-carrier', startX + 46.5, y + 2.5);
  doc.text('Country of Origin of Goods', startX + 92.5, y + 2.5);
  doc.text('Country of Final Destination', startX + 137.5, y + 2.5);

  doc.setFont('times', 'normal');
  doc.setFontSize(6.5);
  doc.text(shipment.carriage.preCarriageBy || '—', startX + 1.5, y + 6);
  doc.text(shipment.carriage.placeOfReceipt || '—', startX + 46.5, y + 6);
  doc.text('India', startX + 92.5, y + 6);
  doc.text(shipment.carriage.countryOfFinalDestination || shipment.buyer.country, startX + 137.5, y + 6);

  y += r3H;

  // Row 4: Carriage Unified (Vessel, Port of Loading, Port of Discharge, Final Destination, Terms)
  const r4H = 16;
  doc.rect(startX, y, tableW, r4H);
  doc.line(startX + 120, y, startX + 120, y + r4H);
  doc.line(startX, y + 8, startX + 120, y + 8);
  doc.line(startX + 60, y, startX + 60, y + 8);
  doc.line(startX + 60, y + 8, startX + 60, y + r4H);

  doc.setFont('times', 'bold');
  doc.setFontSize(6);
  doc.text('Vessel / Mode', startX + 1.5, y + 2.5);
  doc.text('Port of Loading', startX + 61.5, y + 2.5);
  doc.text('Terms', startX + 121.5, y + 2.5);

  doc.setFont('times', 'normal');
  doc.setFontSize(6.5);
  doc.text(shipment.carriage.vesselFlightNo || 'By Sea', startX + 1.5, y + 6);
  doc.text(shipment.carriage.portOfLoading, startX + 61.5, y + 6);
  doc.text(`-${shipment.incoterm}`, startX + 121.5, y + 6);

  // Sub-row: Port of Discharge & Final Destination
  doc.setFont('times', 'bold');
  doc.setFontSize(6);
  doc.text('Port of Discharge', startX + 1.5, y + 10.5);
  doc.text('Final Destination', startX + 61.5, y + 10.5);

  doc.setFont('times', 'normal');
  doc.setFontSize(6.5);
  doc.text(shipment.carriage.portOfDischarge, startX + 1.5, y + 14);
  doc.text(shipment.carriage.finalDestination, startX + 61.5, y + 14);

  y += r4H;

  // Row 5: LUT Banner
  const lutH = 6;
  doc.rect(startX, y, tableW, lutH);
  doc.setFont('times', 'bold');
  doc.setFontSize(6.5);
  doc.text(
    `Export under LUT with / without payment of IGST – Zero Rated Supply under Section 16 of IGST Act, 2017 ARN ${shipment.gstAndCustoms.lutNumber || 'AD2402260127874'}`,
    105,
    y + 4,
    { align: 'center' }
  );

  y += lutH;

  // Line items
  const colW = [14, 14, 78, 20, 16, 20, 20]; // sum = 182
  const headers = ['Marks', 'Pkgs', 'Description of Goods', 'H S Code', 'Qty Nos.', `Rate ${shipment.currency}`, `Amount ${shipment.currency}`];

  doc.rect(startX, y, tableW, 5.5);
  doc.setFont('times', 'bold');
  doc.setFontSize(6);

  let curX = startX;
  headers.forEach((h, idx) => {
    const align = idx >= 4 ? 'right' : 'left';
    const textX = align === 'right' ? curX + colW[idx] - 1.5 : curX + 1.5;
    doc.text(h, textX, y + 3.8, { align });
    if (idx < headers.length - 1) {
      doc.line(curX + colW[idx], y, curX + colW[idx], y + 5.5);
    }
    curX += colW[idx];
  });

  y += 5.5;

  doc.setFont('times', 'normal');
  doc.setFontSize(6);

  shipment.lineItems.forEach((item, idx) => {
    const rowH = 5;
    doc.rect(startX, y, tableW, rowH);

    let x = startX;
    doc.text(item.marksAndNos || '1', x + 1.5, y + 3.5);
    doc.line(x + colW[0], y, x + colW[0], y + rowH);
    x += colW[0];

    doc.text(idx === 0 ? `${summary.totalPackagesCount}` : '', x + 1.5, y + 3.5);
    doc.line(x + colW[1], y, x + colW[1], y + rowH);
    x += colW[1];

    doc.text(item.description.slice(0, 52), x + 1.5, y + 3.5);
    doc.line(x + colW[2], y, x + colW[2], y + rowH);
    x += colW[2];

    doc.text(item.hsnCode, x + 1.5, y + 3.5);
    doc.line(x + colW[3], y, x + colW[3], y + rowH);
    x += colW[3];

    doc.text(`${item.quantity}`, x + colW[4] - 1.5, y + 3.5, { align: 'right' });
    doc.line(x + colW[4], y, x + colW[4], y + rowH);
    x += colW[4];

    doc.text(Number(item.unitPrice).toFixed(2), x + colW[5] - 1.5, y + 3.5, { align: 'right' });
    doc.line(x + colW[5], y, x + colW[5], y + rowH);
    x += colW[5];

    const amt = item.quantity * item.unitPrice;
    doc.text(amt.toFixed(2), x + colW[6] - 1.5, y + 3.5, { align: 'right' });

    y += rowH;
  });

  // Totals Box
  const totalH = 15;
  doc.rect(startX, y, tableW, totalH);
  doc.line(startX + 120, y, startX + 120, y + totalH);

  doc.setFont('times', 'normal');
  doc.setFontSize(6.5);
  doc.text(
    `Amount : ${shipment.currency} ${convertToInternationalWords(summary.grandTotalFobOrCif, shipment.currency).replace(/^US Dollars /, '').replace(/^Euros /, '')}(in words)`,
    startX + 2,
    y + 5
  );

  doc.text('Basic Amount', startX + 122, y + 4);
  doc.text(`${summary.subtotalAmount.toFixed(2)}`, startX + tableW - 2, y + 4, { align: 'right' });

  doc.text('Sub Total', startX + 122, y + 8);
  doc.text(`${summary.subtotalAmount.toFixed(2)}`, startX + tableW - 2, y + 8, { align: 'right' });

  doc.setFont('times', 'bold');
  doc.text('Grand Total', startX + 122, y + 12);
  doc.text(`${summary.grandTotalFobOrCif.toFixed(2)}`, startX + tableW - 2, y + 12, { align: 'right' });

  y += totalH;

  // Declaration & Signatory
  const decH = 26;
  doc.rect(startX, y, tableW, decH);
  doc.line(startX + 115, y, startX + 115, y + decH);

  doc.setFont('times', 'bold');
  doc.setFontSize(6);
  doc.text('Declaration', startX + 2, y + 3.5);
  doc.setFont('times', 'normal');
  doc.text('END USE Code: - GNX200', startX + 2, y + 7);
  doc.text(`-GST REGISTRAION NO: ${shipment.exporter.gstin || '24AABCI7261H1ZO'}`, startX + 2, y + 10.5);
  doc.text(`-PAN NUMBER: - ${shipment.exporter.panNumber || 'AABCI7261H'}`, startX + 2, y + 14);
  doc.text('-IGST PAYMENT STATUS:', startX + 2, y + 17.5);
  doc.text('The Goods are shipped under draw back scheme. The Goods are shipped under RoDTEP scheme.', startX + 2, y + 21);
  doc.text('We declare that this Invoice shows the actual price of the goods described and that all particulars are true and correct.', startX + 2, y + 24.5);

  doc.setFont('times', 'bold');
  doc.text('For, Innovative Flexotech Pvt. Ltd.', startX + 117, y + 4);
  doc.text('Authorized Signatory.', startX + 117, y + 24);

  // Bottom Plant & Office Footer
  y += decH + 4;
  drawPdfFooter(doc, shipment, isPreprinted, startX, y, tableW);
}

// -------------------------------------------------------------
// TAX INVOICE PDF
// -------------------------------------------------------------
function renderTaxInvoicePage(
  doc: jsPDF,
  shipment: ShipmentDocument,
  summary: ReturnType<typeof calculateShipmentSummary>,
  isPreprinted: boolean,
  isLc?: boolean
) {
  const tableW = 182;
  const startX = 14;
  let y = isPreprinted ? (shipment.exporter.stationeryTopMarginMm || 55) : 8;
  const hasLc = isLc !== undefined ? isLc : (shipment.lcDetails?.hasLc ?? true);

  y = drawPdfHeader(doc, shipment, isPreprinted, startX, y, tableW);

  // Black Frame Grid
  doc.setDrawColor(0, 0, 0);
  doc.setLineWidth(0.3);

  // Title Row
  doc.rect(startX, y, tableW, 6);
  doc.setFont('times', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(0, 0, 0);
  doc.text(hasLc ? 'LC TAX INVOICE' : 'TAX INVOICE', 105, y + 4.2, { align: 'center' });

  y += 6;

  // Row 1: Exporter | Invoice No & Date | Exporter's Ref
  const r1H = 26;
  doc.rect(startX, y, tableW, r1H);
  doc.line(startX + 78, y, startX + 78, y + r1H);
  doc.line(startX + 138, y, startX + 138, y + r1H);

  doc.setFont('times', 'bold');
  doc.setFontSize(6.5);
  doc.text('Manufacturer/Producer/Exporter', startX + 1.5, y + 3.5);
  doc.text(`GSTIN : ${shipment.exporter.gstin || '24AABCI7261H1ZO'}`, startX + 1.5, y + 7);
  doc.text(shipment.exporter.tradingName || 'Innovative Flexotech Pvt Ltd.', startX + 1.5, y + 10.5);
  doc.setFont('times', 'normal');
  doc.setFontSize(6);
  doc.text('FF/4,Rameshwar Residency,', startX + 1.5, y + 14);
  doc.text('BS Kalash-3,Ghuma Village, Ahmedabad, Gujarat-380058', startX + 1.5, y + 17.5);
  doc.text(`Mo. ${shipment.exporter.phone || '98240 96180'}`, startX + 1.5, y + 21);

  doc.setFont('times', 'bold');
  doc.setFontSize(6.5);
  doc.text('Invoice No. & Date', startX + 79.5, y + 3.5);
  doc.text(`Invoice No. : ${shipment.taxInvoiceNumber || shipment.documentNumber}`, startX + 79.5, y + 7.5);
  doc.text(`Date : ${shipment.taxInvoiceDate || shipment.invoiceDate}`, startX + 79.5, y + 11.5);
  if (hasLc) {
    doc.setFontSize(6);
    doc.text(`LC NO. : ${shipment.lcDetails?.documentaryCreditNumber || 'LC/2026/SL/00492'}`, startX + 79.5, y + 16);
    doc.text(`Advising Ref : ${shipment.lcDetails?.advisingBankRef || '26ELF08102489095'}`, startX + 79.5, y + 19.5);
  }

  doc.setFont('times', 'bold');
  doc.setFontSize(6.5);
  doc.text("Exporter's Ref.", startX + 139.5, y + 3.5);
  doc.setFont('times', 'normal');
  doc.text(`IEC : ${shipment.exporter.iecCode || '0807016772'}`, startX + 139.5, y + 7.5);

  y += r1H;

  // Consignee & Buyer
  const r2H = 22;
  doc.rect(startX, y, tableW, r2H);
  doc.line(startX + 91, y, startX + 91, y + r2H);

  doc.setFont('times', 'bold');
  doc.setFontSize(7);
  doc.text(hasLc ? 'Applicant' : 'Consignee', startX + 1.5, y + 3.5);
  doc.setFont('times', 'normal');
  doc.setFontSize(6.5);
  const leftBuyerTax = hasLc ? shipment.buyer : (shipment.consignee.isSameAsBuyer ? shipment.buyer : shipment.consignee);
  doc.text(leftBuyerTax.name.slice(0, 50), startX + 1.5, y + 7.5);
  doc.text(leftBuyerTax.address.slice(0, 55), startX + 1.5, y + 11);
  doc.text(leftBuyerTax.address.slice(55, 110), startX + 1.5, y + 14.5);

  doc.setFont('times', 'bold');
  doc.setFontSize(7);
  doc.text(hasLc ? 'Consignee' : "Buyer's Name & Address", startX + 92.5, y + 3.5);
  doc.setFont('times', 'normal');
  doc.setFontSize(6.5);
  const rightBuyerTax = hasLc ? shipment.consignee : shipment.buyer;
  doc.text(rightBuyerTax.name.slice(0, 50), startX + 92.5, y + 7.5);
  doc.text(rightBuyerTax.address.slice(0, 55), startX + 92.5, y + 11);
  doc.text(rightBuyerTax.address.slice(55, 110), startX + 92.5, y + 14.5);

  y += r2H;

  // Carriage
  const r3H = 8;
  doc.rect(startX, y, tableW, r3H);
  doc.line(startX + 45, y, startX + 45, y + r3H);
  doc.line(startX + 91, y, startX + 91, y + r3H);
  doc.line(startX + 136, y, startX + 136, y + r3H);

  doc.setFont('times', 'bold');
  doc.setFontSize(6);
  doc.text('Carriage by', startX + 1.5, y + 2.5);
  doc.text('Place of receipt by Pre-carrier', startX + 46.5, y + 2.5);
  doc.text('Country of Origin of Goods', startX + 92.5, y + 2.5);
  doc.text('Country of Final Destination', startX + 137.5, y + 2.5);

  doc.setFont('times', 'normal');
  doc.setFontSize(6.5);
  doc.text(shipment.carriage.preCarriageBy || '—', startX + 1.5, y + 6);
  doc.text(shipment.carriage.placeOfReceipt || '—', startX + 46.5, y + 6);
  doc.text('India', startX + 92.5, y + 6);
  doc.text(shipment.carriage.countryOfFinalDestination || shipment.buyer.country, startX + 137.5, y + 6);

  y += r3H;

  // Row 4: Carriage Unified (Vessel, Port of Loading, Port of Discharge, Final Destination, Terms)
  const r4H = 16;
  doc.rect(startX, y, tableW, r4H);
  doc.line(startX + 120, y, startX + 120, y + r4H);
  doc.line(startX, y + 8, startX + 120, y + 8);
  doc.line(startX + 60, y, startX + 60, y + 8);
  doc.line(startX + 60, y + 8, startX + 60, y + r4H);

  doc.setFont('times', 'bold');
  doc.setFontSize(6);
  doc.text('Vessel', startX + 1.5, y + 2.5);
  doc.text('Port of Loading', startX + 61.5, y + 2.5);
  doc.text('Terms', startX + 121.5, y + 2.5);

  doc.setFont('times', 'normal');
  doc.setFontSize(6.5);
  doc.text(shipment.carriage.vesselFlightNo || 'By Sea', startX + 1.5, y + 6);
  doc.text(shipment.carriage.portOfLoading, startX + 61.5, y + 6);
  doc.text(`-${shipment.incoterm}`, startX + 121.5, y + 6);

  // Sub-row: Port of Discharge & Final Destination
  doc.setFont('times', 'bold');
  doc.setFontSize(6);
  doc.text('Port of Discharge', startX + 1.5, y + 10.5);
  doc.text('Final Destination', startX + 61.5, y + 10.5);

  doc.setFont('times', 'normal');
  doc.setFontSize(6.5);
  doc.text(shipment.carriage.portOfDischarge, startX + 1.5, y + 14);
  doc.text(shipment.carriage.finalDestination, startX + 61.5, y + 14);

  y += r4H;

  // LUT Bar
  const lutH = 6;
  doc.rect(startX, y, tableW, lutH);
  doc.setFont('times', 'bold');
  doc.setFontSize(6.5);
  doc.text(
    `Export under LUT with / without payment of IGST – Zero Rated Supply under Section 16 of IGST Act, 2017 ARN ${shipment.gstAndCustoms.lutNumber || 'AD2402260127874'}`,
    105,
    y + 4,
    { align: 'center' }
  );

  y += lutH;

  // Columns for Tax Invoice: No. | Item Details | HSN/SAC | UOM | Quantity | Rate USD | Amount INR
  const colW = [10, 80, 22, 14, 18, 18, 20]; // sum = 182
  const headers = ['No.', 'Item Details', 'HSN/SAC', 'UOM', 'Quantity', `Rate ${shipment.currency}`, 'Amount INR'];

  doc.rect(startX, y, tableW, 5.5);
  doc.setFont('times', 'bold');
  doc.setFontSize(6);

  let curX = startX;
  headers.forEach((h, idx) => {
    const align = idx >= 4 ? 'right' : idx === 0 || idx === 3 ? 'center' : 'left';
    const textX = align === 'right' ? curX + colW[idx] - 1.5 : align === 'center' ? curX + colW[idx] / 2 : curX + 1.5;
    doc.text(h, textX, y + 3.8, { align });
    if (idx < headers.length - 1) {
      doc.line(curX + colW[idx], y, curX + colW[idx], y + 5.5);
    }
    curX += colW[idx];
  });

  y += 5.5;

  doc.setFont('times', 'normal');
  doc.setFontSize(6);

  shipment.lineItems.forEach((item, idx) => {
    const rowH = 5;
    doc.rect(startX, y, tableW, rowH);

    let x = startX;
    doc.text(`${idx + 1}`, x + colW[0] / 2, y + 3.5, { align: 'center' });
    doc.line(x + colW[0], y, x + colW[0], y + rowH);
    x += colW[0];

    doc.text(item.description.slice(0, 52), x + 1.5, y + 3.5);
    doc.line(x + colW[1], y, x + colW[1], y + rowH);
    x += colW[1];

    doc.text(item.hsnCode, x + 1.5, y + 3.5);
    doc.line(x + colW[2], y, x + colW[2], y + rowH);
    x += colW[2];

    doc.text(item.unit || 'Nos.', x + colW[3] / 2, y + 3.5, { align: 'center' });
    doc.line(x + colW[3], y, x + colW[3], y + rowH);
    x += colW[3];

    doc.text(`${item.quantity}`, x + colW[4] - 1.5, y + 3.5, { align: 'right' });
    doc.line(x + colW[4], y, x + colW[4], y + rowH);
    x += colW[4];

    doc.text(Number(item.unitPrice).toFixed(2), x + colW[5] - 1.5, y + 3.5, { align: 'right' });
    doc.line(x + colW[5], y, x + colW[5], y + rowH);
    x += colW[5];

    const inrAmt = item.quantity * item.unitPrice * summary.exchangeRateInr;
    doc.text(inrAmt.toFixed(2), x + colW[6] - 1.5, y + 3.5, { align: 'right' });

    y += rowH;
  });

  // Totals
  const totalH = 15;
  doc.rect(startX, y, tableW, totalH);
  doc.line(startX + 120, y, startX + 120, y + totalH);

  doc.setFont('times', 'normal');
  doc.setFontSize(6.5);
  doc.text(
    `Amount in Words: ${convertToIndianWords(summary.grandTotalInr, 'INR')}`,
    startX + 2,
    y + 5
  );

  doc.text('Basic Amount INR', startX + 122, y + 4);
  doc.text(`${summary.grandTotalInr.toFixed(2)}`, startX + tableW - 2, y + 4, { align: 'right' });

  doc.text('Sub Total INR', startX + 122, y + 8);
  doc.text(`${summary.grandTotalInr.toFixed(2)}`, startX + tableW - 2, y + 8, { align: 'right' });

  doc.setFont('times', 'bold');
  doc.text('Grand Total INR', startX + 122, y + 12);
  doc.text(`${summary.grandTotalInr.toFixed(2)}`, startX + tableW - 2, y + 12, { align: 'right' });

  y += totalH;

  // Declaration & Signatory
  const decH = 26;
  doc.rect(startX, y, tableW, decH);
  doc.line(startX + 115, y, startX + 115, y + decH);

  doc.setFont('times', 'bold');
  doc.setFontSize(6);
  doc.text('Declaration', startX + 2, y + 3.5);
  doc.setFont('times', 'normal');
  doc.text('Supply meant for export under Letter of Undertaking without payment of integrated tax.', startX + 2, y + 7);
  doc.text(`-GST REGISTRAION NO: ${shipment.exporter.gstin || '24AABCI7261H1ZO'}`, startX + 2, y + 10.5);
  doc.text(`-PAN NUMBER: - ${shipment.exporter.panNumber || 'AABCI7261H'}`, startX + 2, y + 14);
  doc.text('We declare that this invoice shows the actual price of the goods described.', startX + 2, y + 17.5);

  doc.setFont('times', 'bold');
  doc.text('For, Innovative Flexotech Pvt. Ltd.', startX + 117, y + 4);
  doc.text('Authorized Signatory.', startX + 117, y + 24);

  y += decH + 4;
  drawPdfFooter(doc, shipment, isPreprinted, startX, y, tableW);
}

// -------------------------------------------------------------
// PACKING LIST PDF
// -------------------------------------------------------------
function renderPackingListPage(
  doc: jsPDF,
  shipment: ShipmentDocument,
  summary: ReturnType<typeof calculateShipmentSummary>,
  isPreprinted: boolean,
  isLc?: boolean
) {
  const tableW = 182;
  const startX = 14;
  let y = isPreprinted ? (shipment.exporter.stationeryTopMarginMm || 55) : 8;
  const hasLc = isLc !== undefined ? isLc : (shipment.lcDetails?.hasLc ?? true);

  y = drawPdfHeader(doc, shipment, isPreprinted, startX, y, tableW);

  // Black Frame Grid
  doc.setDrawColor(0, 0, 0);
  doc.setLineWidth(0.3);

  // Title Row
  doc.rect(startX, y, tableW, 6);
  doc.setFont('times', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(0, 0, 0);
  doc.text(hasLc ? 'LC PACKING LIST' : 'PACKING LIST', 105, y + 4.2, { align: 'center' });

  y += 6;

  // Row 1: Exporter | Invoice No & Date | Exporter's Ref
  const r1H = 26;
  doc.rect(startX, y, tableW, r1H);
  doc.line(startX + 78, y, startX + 78, y + r1H);
  doc.line(startX + 138, y, startX + 138, y + r1H);

  doc.setFont('times', 'bold');
  doc.setFontSize(6.5);
  doc.text('Manufacturer/Producer/Exporter', startX + 1.5, y + 3.5);
  doc.text(`GSTIN : ${shipment.exporter.gstin || '24AABCI7261H1ZO'}`, startX + 1.5, y + 7);
  doc.text(shipment.exporter.tradingName || 'Innovative Flexotech Pvt Ltd.', startX + 1.5, y + 10.5);
  doc.setFont('times', 'normal');
  doc.setFontSize(6);
  doc.text('FF/4,Rameshwar Residency,', startX + 1.5, y + 14);
  doc.text('BS Kalash-3,Ghuma Village, Ahmedabad, Gujarat-380058', startX + 1.5, y + 17.5);
  doc.text(`Mo. ${shipment.exporter.phone || '98240 96180'}`, startX + 1.5, y + 21);

  doc.setFont('times', 'bold');
  doc.setFontSize(6.5);
  doc.text('Invoice No. & Date', startX + 79.5, y + 3.5);
  doc.text(`Invoice No. : ${shipment.documentNumber}`, startX + 79.5, y + 7.5);
  doc.text(`Date : ${shipment.invoiceDate}`, startX + 79.5, y + 11.5);
  if (hasLc) {
    doc.setFontSize(6);
    doc.text(`LC NO. : ${shipment.lcDetails?.documentaryCreditNumber || 'LC/2026/SL/00492'}`, startX + 79.5, y + 16);
    doc.text(`Advising Ref : ${shipment.lcDetails?.advisingBankRef || '26ELF08102489095'}`, startX + 79.5, y + 19.5);
  }

  doc.setFont('times', 'bold');
  doc.setFontSize(6.5);
  doc.text("Exporter's Ref.", startX + 139.5, y + 3.5);
  doc.setFont('times', 'normal');
  doc.text(`IEC No. : ${shipment.exporter.iecCode || '807016772'}`, startX + 139.5, y + 7.5);

  y += r1H;

  // Consignee & Buyer
  const r2H = 22;
  doc.rect(startX, y, tableW, r2H);
  doc.line(startX + 91, y, startX + 91, y + r2H);

  doc.setFont('times', 'bold');
  doc.setFontSize(7);
  doc.text(hasLc ? 'Applicant' : 'Consignee', startX + 1.5, y + 3.5);
  doc.setFont('times', 'normal');
  doc.setFontSize(6.5);
  const leftBuyerPack = hasLc ? shipment.buyer : shipment.consignee;
  doc.text(leftBuyerPack.name.slice(0, 50), startX + 1.5, y + 7.5);
  doc.text(leftBuyerPack.address.slice(0, 55), startX + 1.5, y + 11);
  doc.text(leftBuyerPack.address.slice(55, 110), startX + 1.5, y + 14.5);

  doc.setFont('times', 'bold');
  doc.setFontSize(7);
  doc.text(hasLc ? 'Consignee' : "Buyer's Name & Address", startX + 92.5, y + 3.5);
  doc.setFont('times', 'normal');
  doc.setFontSize(6.5);
  const rightBuyerPack = hasLc ? shipment.consignee : shipment.buyer;
  doc.text(rightBuyerPack.name.slice(0, 50), startX + 92.5, y + 7.5);
  doc.text(rightBuyerPack.address.slice(0, 55), startX + 92.5, y + 11);
  doc.text(rightBuyerPack.address.slice(55, 110), startX + 92.5, y + 14.5);

  y += r2H;

  // Carriage
  const r3H = 8;
  doc.rect(startX, y, tableW, r3H);
  doc.line(startX + 45, y, startX + 45, y + r3H);
  doc.line(startX + 91, y, startX + 91, y + r3H);
  doc.line(startX + 136, y, startX + 136, y + r3H);

  doc.setFont('times', 'bold');
  doc.setFontSize(6);
  doc.text('Pre-Carriage by', startX + 1.5, y + 2.5);
  doc.text('Place of receipt by Pre-carrier', startX + 46.5, y + 2.5);
  doc.text('Country of Origin of Goods', startX + 92.5, y + 2.5);
  doc.text('Country of Final Destination', startX + 137.5, y + 2.5);

  doc.setFont('times', 'normal');
  doc.setFontSize(6.5);
  doc.text(shipment.carriage.preCarriageBy || '—', startX + 1.5, y + 6);
  doc.text(shipment.carriage.placeOfReceipt || '—', startX + 46.5, y + 6);
  doc.text('India', startX + 92.5, y + 6);
  doc.text(shipment.carriage.countryOfFinalDestination || shipment.buyer.country, startX + 137.5, y + 6);

  y += r3H;

  // Row 4: Carriage Unified (Mode of Shipment, Port of Loading, Port of Discharge, Final Destination, Terms)
  const r4H = 16;
  doc.rect(startX, y, tableW, r4H);
  doc.line(startX + 120, y, startX + 120, y + r4H);
  doc.line(startX, y + 8, startX + 120, y + 8);
  doc.line(startX + 60, y, startX + 60, y + 8);
  doc.line(startX + 60, y + 8, startX + 60, y + r4H);

  doc.setFont('times', 'bold');
  doc.setFontSize(6);
  doc.text('Mode of Shipment', startX + 1.5, y + 2.5);
  doc.text('Port of Loading', startX + 61.5, y + 2.5);
  doc.text('Terms', startX + 121.5, y + 2.5);

  doc.setFont('times', 'normal');
  doc.setFontSize(6.5);
  doc.text(shipment.carriage.vesselFlightNo || 'By Sea', startX + 1.5, y + 6);
  doc.text(shipment.carriage.portOfLoading, startX + 61.5, y + 6);
  doc.text(`-${shipment.incoterm}`, startX + 121.5, y + 6);

  // Sub-row: Port of Discharge & Final Destination
  doc.setFont('times', 'bold');
  doc.setFontSize(6);
  doc.text('Port of Discharge', startX + 1.5, y + 10.5);
  doc.text('Final Destination', startX + 61.5, y + 10.5);

  doc.setFont('times', 'normal');
  doc.setFontSize(6.5);
  doc.text(shipment.carriage.portOfDischarge, startX + 1.5, y + 14);
  doc.text(shipment.carriage.finalDestination, startX + 61.5, y + 14);

  y += r4H;

  // LUT Bar
  const lutH = 6;
  doc.rect(startX, y, tableW, lutH);
  doc.setFont('times', 'bold');
  doc.setFontSize(6.5);
  doc.text(
    `Export under LUT with / without payment of IGST – Zero Rated Supply under Section 16 of IGST Act, 2017 ARN ${shipment.gstAndCustoms.lutNumber || 'AD2402260127874'}`,
    105,
    y + 4,
    { align: 'center' }
  );

  y += lutH;

  // Columns for Packing List: Marks & Nos. | Pkgs | Description of Goods | H S Code | Qty | Net Wt (Kg) | Gross Wt (Kg) | Case Size in CM
  const colW = [14, 14, 68, 20, 16, 16, 16, 18]; // sum = 182
  const headers = ['Marks', 'Pkgs', 'Description of Goods', 'H S Code', 'Qty Nos.', 'Net Wt.', 'Gross Wt.', 'Case Size CM'];

  doc.rect(startX, y, tableW, 5.5);
  doc.setFont('times', 'bold');
  doc.setFontSize(6);

  let curX = startX;
  headers.forEach((h, idx) => {
    const align = idx >= 4 ? 'right' : 'left';
    const textX = align === 'right' ? curX + colW[idx] - 1.5 : curX + 1.5;
    doc.text(h, textX, y + 3.8, { align });
    if (idx < headers.length - 1) {
      doc.line(curX + colW[idx], y, curX + colW[idx], y + 5.5);
    }
    curX += colW[idx];
  });

  y += 5.5;

  doc.setFont('times', 'normal');
  doc.setFontSize(6);

  const pkg = shipment.packageDetails?.[0];
  const defaultCase = pkg ? `${pkg.lengthCm}X${pkg.widthCm}X${pkg.heightCm}` : '132X102X89';

  shipment.lineItems.forEach((item, idx) => {
    const rowH = 5;
    doc.rect(startX, y, tableW, rowH);

    let x = startX;
    doc.text(item.marksAndNos || '1', x + 1.5, y + 3.5);
    doc.line(x + colW[0], y, x + colW[0], y + rowH);
    x += colW[0];

    doc.text(idx === 0 ? `${summary.totalPackagesCount}` : '', x + 1.5, y + 3.5);
    doc.line(x + colW[1], y, x + colW[1], y + rowH);
    x += colW[1];

    doc.text(item.description.slice(0, 46), x + 1.5, y + 3.5);
    doc.line(x + colW[2], y, x + colW[2], y + rowH);
    x += colW[2];

    doc.text(item.hsnCode, x + 1.5, y + 3.5);
    doc.line(x + colW[3], y, x + colW[3], y + rowH);
    x += colW[3];

    doc.text(`${item.quantity}`, x + colW[4] - 1.5, y + 3.5, { align: 'right' });
    doc.line(x + colW[4], y, x + colW[4], y + rowH);
    x += colW[4];

    doc.text(item.netWeightKg ? `${item.netWeightKg}` : '—', x + colW[5] - 1.5, y + 3.5, { align: 'right' });
    doc.line(x + colW[5], y, x + colW[5], y + rowH);
    x += colW[5];

    doc.text(item.grossWeightKg ? `${item.grossWeightKg}` : '—', x + colW[6] - 1.5, y + 3.5, { align: 'right' });
    doc.line(x + colW[6], y, x + colW[6], y + rowH);
    x += colW[6];

    doc.text(idx === 0 ? defaultCase : '', x + 1.5, y + 3.5);

    y += rowH;
  });

  // Totals Box
  const totalH = 14;
  doc.rect(startX, y, tableW, totalH);
  doc.line(startX + 115, y, startX + 115, y + totalH);

  doc.setFont('times', 'bold');
  doc.setFontSize(6.5);
  doc.text('Container & Package Summary:', startX + 2, y + 4.5);
  doc.setFont('times', 'normal');
  doc.text(
    `${shipment.containerSummary || `${summary.totalPackagesCount} Box (${defaultCase}/${summary.totalPackagesCount}Box)`}  |  Total CBM: ${summary.totalCbm.toFixed(3)} m³`,
    startX + 2,
    y + 9
  );

  doc.setFont('times', 'bold');
  doc.text(`Total Net Wt : ${summary.totalNetWeightKg.toFixed(2)} Kg`, startX + 117, y + 5);
  doc.text(`Total Gross Wt : ${summary.totalGrossWeightKg.toFixed(2)} Kg`, startX + 117, y + 10);

  y += totalH;

  // Declaration & Signatory
  const decH = 26;
  doc.rect(startX, y, tableW, decH);
  doc.line(startX + 115, y, startX + 115, y + decH);

  doc.setFont('times', 'bold');
  doc.setFontSize(6);
  doc.text('Declaration', startX + 2, y + 3.5);
  doc.setFont('times', 'normal');
  doc.text('We declare that this packing list shows the actual count, weight, and dimensions of goods packed.', startX + 2, y + 7);
  doc.text(`-GST REGISTRAION NO: ${shipment.exporter.gstin || '24AABCI7261H1ZO'}`, startX + 2, y + 10.5);
  doc.text(`-PAN NUMBER: - ${shipment.exporter.panNumber || 'AABCI7261H'}`, startX + 2, y + 14);

  doc.setFont('times', 'bold');
  doc.text('For, Innovative Flexotech Pvt. Ltd.', startX + 117, y + 4);
  doc.text('Authorized Signatory.', startX + 117, y + 24);

  y += decH + 4;
  drawPdfFooter(doc, shipment, isPreprinted, startX, y, tableW);
}

