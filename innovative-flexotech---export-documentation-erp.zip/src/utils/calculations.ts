import { ShipmentDocument } from '../types/trade';

export interface CalculatedSummary {
  totalItemsCount: number;
  totalQuantity: number;
  subtotalAmount: number;
  freightCharge: number;
  insuranceCharge: number;
  handlingOrMisc: number;
  discountAmount: number;
  grandTotalFobOrCif: number;
  exchangeRateInr: number;
  grandTotalInr: number;
  totalNetWeightKg: number;
  totalGrossWeightKg: number;
  totalPackagesCount: number;
  totalCbm: number;
  weightDiscrepancy: boolean;
  weightDiscrepancyMessage?: string;
  isLutMissing: boolean;
  isGstinInvalid: boolean;
}

export function calculateShipmentSummary(shipment: ShipmentDocument): CalculatedSummary {
  const lineItems = shipment.lineItems || [];
  const packageDetails = shipment.packageDetails || [];

  // Line items totals
  const totalItemsCount = lineItems.length;
  const totalQuantity = lineItems.reduce((acc, item) => acc + (Number(item.quantity) || 0), 0);
  const subtotalAmount = lineItems.reduce((acc, item) => {
    const qty = Number(item.quantity) || 0;
    const price = Number(item.unitPrice) || 0;
    return acc + (qty * price);
  }, 0);

  // Line item weight totals
  const lineItemNetWt = lineItems.reduce((acc, item) => acc + (Number(item.netWeightKg) || 0), 0);
  const lineItemGrossWt = lineItems.reduce((acc, item) => acc + (Number(item.grossWeightKg) || 0), 0);

  // Package details totals
  const pkgPackagesCount = packageDetails.reduce((acc, pkg) => acc + (Number(pkg.packageCount) || 0), 0);
  const pkgNetWt = packageDetails.reduce((acc, pkg) => acc + (Number(pkg.netWeightKg) || 0), 0);
  const pkgGrossWt = packageDetails.reduce((acc, pkg) => acc + (Number(pkg.grossWeightKg) || 0), 0);
  const pkgTotalCbm = packageDetails.reduce((acc, pkg) => {
    const cbm = Number(pkg.totalCbm) || 0;
    if (cbm > 0) return acc + cbm;
    // fallback calculate: (L * W * H / 1,000,000) * count
    const l = Number(pkg.lengthCm) || 0;
    const w = Number(pkg.widthCm) || 0;
    const h = Number(pkg.heightCm) || 0;
    const count = Number(pkg.packageCount) || 1;
    return acc + ((l * w * h) / 1_000_000 * count);
  }, 0);

  // Determine final weights (prefer package breakdown if populated, else line items)
  const totalNetWeightKg = pkgNetWt > 0 ? pkgNetWt : lineItemNetWt;
  const totalGrossWeightKg = pkgGrossWt > 0 ? pkgGrossWt : lineItemGrossWt;
  const totalPackagesCount = pkgPackagesCount > 0 ? pkgPackagesCount : totalQuantity;
  const totalCbm = Number(pkgTotalCbm.toFixed(3));

  // Weight check
  const weightDiscrepancy = totalGrossWeightKg > 0 && totalNetWeightKg > 0 && totalGrossWeightKg < totalNetWeightKg;
  const weightDiscrepancyMessage = weightDiscrepancy
    ? `Gross Weight (${totalGrossWeightKg} kg) cannot be less than Net Weight (${totalNetWeightKg} kg)`
    : undefined;

  // Financial charges
  const freight = Number(shipment.freightCharge) || 0;
  const insurance = Number(shipment.insuranceCharge) || 0;
  const handling = Number(shipment.handlingOrMisc) || 0;
  const discount = Number(shipment.discountAmount) || 0;

  const grandTotalFobOrCif = Number((subtotalAmount + freight + insurance + handling - discount).toFixed(2));
  const exchangeRateInr = Number(shipment.exchangeRateInr) || 86.50;
  const grandTotalInr = Number((grandTotalFobOrCif * exchangeRateInr).toFixed(2));

  // Compliance checks
  const isLutMissing =
    shipment.gstAndCustoms.supplyType === 'LUT_WITHOUT_TAX' &&
    (!shipment.gstAndCustoms.lutNumber || shipment.gstAndCustoms.lutNumber.trim().length === 0);

  const gstinClean = (shipment.exporter.gstin || '').trim();
  const isGstinInvalid = gstinClean.length > 0 && !/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/.test(gstinClean);

  return {
    totalItemsCount,
    totalQuantity,
    subtotalAmount: Number(subtotalAmount.toFixed(2)),
    freightCharge: freight,
    insuranceCharge: insurance,
    handlingOrMisc: handling,
    discountAmount: discount,
    grandTotalFobOrCif,
    exchangeRateInr,
    grandTotalInr,
    totalNetWeightKg: Number(totalNetWeightKg.toFixed(2)),
    totalGrossWeightKg: Number(totalGrossWeightKg.toFixed(2)),
    totalPackagesCount,
    totalCbm,
    weightDiscrepancy,
    weightDiscrepancyMessage,
    isLutMissing,
    isGstinInvalid,
  };
}
