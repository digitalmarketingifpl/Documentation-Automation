import * as XLSX from 'xlsx';
import { ShipmentDocument } from '../types/trade';
import { calculateShipmentSummary } from './calculations';
import { convertToInternationalWords, convertToIndianWords } from './numberToWords';

export function exportMultiTabTradeWorkbook(shipment: ShipmentDocument): void {
  const summary = calculateShipmentSummary(shipment);
  const wb = XLSX.utils.book_new();

  // ---------------------------------------------------------
  // SHEET 1: COMMERCIAL INVOICE
  // ---------------------------------------------------------
  const ciRows: (string | number)[][] = [
    ['INVOICE'],
    ['INNOVATIVE FLEXOTECH PVT LTD - COMPLETE FLEXO SOLUTION'],
    ['AN ISO 9001:2015 CERTIFIED COMPANY | www.flexo.co.in'],
    [''],
    ['Manufacturer/Producer/Exporter', '', 'Invoice No. & Date', 'Exporter\'s Ref.'],
    [
      `GSTIN : ${shipment.exporter.gstin || '24AABCI7261H1ZO'}`,
      '',
      `Invoice No.${shipment.documentNumber}`,
      `IEC No. ${shipment.exporter.iecCode || '807016772'}`,
    ],
    [
      shipment.exporter.tradingName || 'Innovative Flexotech Pvt Ltd.',
      '',
      `Date ${shipment.invoiceDate}`,
      'BIN No.',
    ],
    [
      'FF/4,Rameshwar Residency,',
      '',
      shipment.lcDetails?.hasLc ? `Issuing Date: ${shipment.lcDetails.issuingDate}` : '',
      '',
    ],
    [
      'BS Kalash-3,Ghuma Village,',
      '',
      shipment.lcDetails?.hasLc ? `LC NO.${shipment.lcDetails.documentaryCreditNumber}` : '',
      '',
    ],
    [
      'Ahmedabad,Gujarat, 380058',
      '',
      shipment.lcDetails?.hasLc ? `LC Advising Ref. NO.${shipment.lcDetails.advisingBankRef}` : '',
      '',
    ],
    [`Mo. ${shipment.exporter.phone || '98240 96180'}`, '', '', ''],
    [''],
    [
      shipment.lcDetails?.hasLc ? 'Applicant' : 'Consignee',
      '',
      shipment.lcDetails?.hasLc ? 'Consignee' : 'Buyer\'s Name & Address',
      '',
    ],
    [
      shipment.buyer.name,
      '',
      shipment.consignee.isSameAsBuyer ? shipment.buyer.name : shipment.consignee.name,
      '',
    ],
    [
      shipment.buyer.address,
      '',
      shipment.consignee.isSameAsBuyer ? shipment.buyer.address : shipment.consignee.address,
      '',
    ],
    [''],
    ['Pre-Carriage by', 'Place of receipt by Pre-carrier', 'Country of Origin of Goods', 'Country of Final Destination'],
    [
      shipment.carriage.preCarriageBy || '—',
      shipment.carriage.placeOfReceipt || '—',
      'India',
      shipment.carriage.countryOfFinalDestination || shipment.buyer.country,
    ],
    ['Vessel / Mode', 'Port of Loading', 'Terms', ''],
    [
      shipment.carriage.vesselFlightNo || 'By Sea',
      shipment.carriage.portOfLoading,
      `Terms: -${shipment.incoterm}`,
      '',
    ],
    ['Port of Discharge', 'Final Destination', '', ''],
    [
      shipment.carriage.portOfDischarge,
      shipment.carriage.finalDestination,
      '',
      '',
    ],
    [''],
    [
      'Export under LUT with / without payment of IGST – Zero Rated Supply under Section 16 of IGST Act, 2017 ARN',
      shipment.gstAndCustoms.lutNumber || 'AD2402260127874',
    ],
    [''],
    ['Marks & Nos./Container No.', 'No.& Kind of Pkgs.', 'Brand', 'Description of Goods', 'H S Code', 'Quantity Nos.', `Rate ${shipment.currency}`, `Amount ${shipment.currency}`],
  ];

  shipment.lineItems.forEach((item, idx) => {
    ciRows.push([
      item.marksAndNos || '1',
      idx === 0 ? summary.totalPackagesCount : '',
      'Innovative Flexotech Pvt Ltd.',
      item.description,
      item.hsnCode,
      Number(item.quantity),
      Number(item.unitPrice),
      Number((item.quantity * item.unitPrice).toFixed(2)),
    ]);
  });

  ciRows.push(['']);
  ciRows.push([
    `Amount : ${shipment.currency} ${convertToInternationalWords(summary.grandTotalFobOrCif, shipment.currency).replace(/^US Dollars /, '').replace(/^Euros /, '')}(in words)`,
    '',
    '',
    '',
    '',
    '',
    'Basic Amount',
    summary.subtotalAmount,
  ]);
  ciRows.push(['', '', '', '', '', '', 'Sub Total', summary.subtotalAmount]);
  ciRows.push(['', '', '', '', '', '', 'Grand Total', summary.grandTotalFobOrCif]);
  ciRows.push(['']);
  ciRows.push(['Declaration', '', '', '', 'For, Innovative Flexotech Pvt. Ltd.']);
  ciRows.push(['END USE Code: - GNX200']);
  ciRows.push([`-GST REGISTRAION NO: ${shipment.exporter.gstin || '24AABCI7261H1ZO'}`]);
  ciRows.push([`-PAN NUMBER: - ${shipment.exporter.panNumber || 'AABCI7261H'}`]);
  ciRows.push(['-IGST PAYMENT STATUS:']);
  ciRows.push(['-TAXABLE VALUE: IGST AMOUNT:']);
  ciRows.push(['The Goods are shipped under draw back scheme. The Goods are shipped under RoDTEP scheme.']);
  ciRows.push(['We declare that this Invoice shows the actual price of the goods described and that all particulars are true and correct.']);
  ciRows.push(['', '', '', '', 'Authorized Signatory.']);

  const ciSheet = XLSX.utils.aoa_to_sheet(ciRows);
  ciSheet['!cols'] = [
    { wch: 18 },
    { wch: 16 },
    { wch: 22 },
    { wch: 42 },
    { wch: 14 },
    { wch: 14 },
    { wch: 14 },
    { wch: 16 },
  ];
  XLSX.utils.book_append_sheet(wb, ciSheet, 'Commercial Invoice');

  // ---------------------------------------------------------
  // SHEET 2: TAX INVOICE
  // ---------------------------------------------------------
  const taxRows: (string | number)[][] = [
    ['TAX INVOICE'],
    ['INNOVATIVE FLEXOTECH PVT LTD'],
    [`GSTIN : ${shipment.exporter.gstin || '24AABCI7261H1ZO'} | PAN: ${shipment.exporter.panNumber || 'AABCI7261H'} | IEC: ${shipment.exporter.iecCode || '807016772'}`],
    [''],
    ['Invoice No.:', shipment.taxInvoiceNumber || shipment.documentNumber, 'Date:', shipment.taxInvoiceDate || shipment.invoiceDate],
    ['Export under LUT ARN:', shipment.gstAndCustoms.lutNumber || 'AD2402260127874'],
    [''],
    ['No.', 'Item Details', 'HSN/SAC', 'UOM', 'Quantity Nos.', `Rate ${shipment.currency}`, 'Amount INR'],
  ];

  shipment.lineItems.forEach((item, idx) => {
    const foreignAmt = item.quantity * item.unitPrice;
    const inrVal = Number((foreignAmt * summary.exchangeRateInr).toFixed(2));
    taxRows.push([
      idx + 1,
      item.description,
      item.hsnCode,
      item.unit,
      Number(item.quantity),
      Number(item.unitPrice),
      inrVal,
    ]);
  });

  taxRows.push(['']);
  taxRows.push([
    `Amount in Words: ${convertToIndianWords(summary.grandTotalInr, 'INR')}`,
    '',
    '',
    '',
    '',
    'Basic Amount',
    summary.grandTotalInr,
  ]);
  taxRows.push(['', '', '', '', '', 'Sub Total', summary.grandTotalInr]);
  taxRows.push(['', '', '', '', '', 'IGST Amount', 'NIL (Under LUT)']);
  taxRows.push(['', '', '', '', '', 'Grand Total', summary.grandTotalInr]);
  taxRows.push(['']);
  taxRows.push(['END USE Code: - GNX200']);
  taxRows.push(['For, Innovative Flexotech Pvt. Ltd. - Authorized Signatory']);

  const taxSheet = XLSX.utils.aoa_to_sheet(taxRows);
  taxSheet['!cols'] = [
    { wch: 8 },
    { wch: 42 },
    { wch: 14 },
    { wch: 10 },
    { wch: 14 },
    { wch: 14 },
    { wch: 18 },
  ];
  XLSX.utils.book_append_sheet(wb, taxSheet, 'Tax Invoice');

  // ---------------------------------------------------------
  // SHEET 3: PACKING LIST
  // ---------------------------------------------------------
  const plRows: (string | number)[][] = [
    ['PACKING LIST'],
    ['INNOVATIVE FLEXOTECH PVT LTD'],
    [''],
    ['Invoice No.:', shipment.documentNumber, 'Date:', shipment.invoiceDate],
    ['Marks & Nos./Container No.', 'No. & Kind of Pkgs.', 'Brand', 'Description of Goods', 'H S Code', 'Quantity Nos.', 'Net Wt. In', 'Gross Wt. In', 'Case Size in CM'],
  ];

  if (shipment.packageDetails && shipment.packageDetails.length > 0) {
    shipment.packageDetails.forEach((pkg, idx) => {
      plRows.push([
        pkg.marksAndNumbers || '1',
        idx === 0 ? summary.totalPackagesCount : '',
        'Innovative Flexotech Pvt Ltd.',
        pkg.contentsDescription,
        shipment.lineItems[idx]?.hsnCode || '84439990',
        shipment.lineItems[idx]?.quantity || 1,
        Number(pkg.netWeightKg),
        Number(pkg.grossWeightKg),
        `${pkg.lengthCm}×${pkg.widthCm}×${pkg.heightCm}`,
      ]);
    });
  } else {
    shipment.lineItems.forEach((item, idx) => {
      plRows.push([
        item.marksAndNos || '1',
        idx === 0 ? summary.totalPackagesCount : '',
        'Innovative Flexotech Pvt Ltd.',
        item.description,
        item.hsnCode,
        Number(item.quantity),
        item.netWeightKg,
        item.grossWeightKg,
        '132X102X89/3Box',
      ]);
    });
  }

  plRows.push(['']);
  plRows.push(['Net Weight in Kg', summary.totalNetWeightKg]);
  plRows.push(['Gross Weight in Kg', summary.totalGrossWeightKg]);
  plRows.push(['Total Cases', `${summary.totalPackagesCount} Box`]);
  plRows.push(['']);
  plRows.push(['END USE Code: - GNX200']);
  plRows.push(['For, Innovative Flexotech Pvt. Ltd. - Authorized Signatory']);

  const plSheet = XLSX.utils.aoa_to_sheet(plRows);
  plSheet['!cols'] = [
    { wch: 18 },
    { wch: 14 },
    { wch: 22 },
    { wch: 38 },
    { wch: 14 },
    { wch: 14 },
    { wch: 14 },
    { wch: 14 },
    { wch: 20 },
  ];
  XLSX.utils.book_append_sheet(wb, plSheet, 'Packing List');

  // ---------------------------------------------------------
  // SHEET 4: PROFORMA INVOICE
  // ---------------------------------------------------------
  const piRows: (string | number)[][] = [
    ['PROFORMA INVOICE'],
    ['INNOVATIVE FLEXOTECH PVT LTD - COMPLETE FLEXO SOLUTION'],
    ['AN ISO 9001:2015 CERTIFIED COMPANY | www.flexo.co.in'],
    [''],
    ['Manufacturer/Producer/Exporter', '', 'PI No. & Date', "Exporter's Ref."],
    [
      `GSTIN : ${shipment.exporter.gstin || '24AABCI7261H1ZO'}`,
      '',
      `PI No. PI/${shipment.documentNumber.replace(/^PI\//, '')}`,
      `IEC No. ${shipment.exporter.iecCode || '807016772'}`,
    ],
    [
      shipment.exporter.tradingName || 'Innovative Flexotech Pvt Ltd.',
      '',
      `Date: ${shipment.invoiceDate}`,
      `PAN No. ${shipment.exporter.panNumber || 'AABCI7261H'}`,
    ],
    ['FF/4,Rameshwar Residency, Ghuma, Ahmedabad-380058', '', 'Validity: 30 Days', 'State: Gujarat (24)'],
    [`Mo. ${shipment.exporter.phone || '98240 96180'}`, '', '', ''],
    [''],
    ['Consignee', '', "Buyer's Name & Address", ''],
    [shipment.consignee.name, '', shipment.buyer.name, ''],
    [shipment.consignee.address, '', shipment.buyer.address, ''],
    ['Country: ' + (shipment.consignee.country || shipment.buyer.country), '', 'PO Ref: ' + (shipment.customerPoNumber || 'N/A'), ''],
    [''],
    ['Pre-Carriage by', 'Place of receipt by Pre-carrier', 'Country of Origin of Goods', 'Country of Final Destination'],
    [
      shipment.carriage.preCarriageBy || 'By Road Truck',
      shipment.carriage.placeOfReceipt || 'Ahmedabad, India',
      shipment.carriage.countryOfOrigin || 'India',
      shipment.carriage.countryOfFinalDestination || shipment.buyer.country,
    ],
    ['Vessel / Flight No.', 'Port of Loading', 'Port of Discharge', 'Final Destination'],
    [
      shipment.carriage.vesselFlightNo || 'By Air / By Sea',
      shipment.carriage.portOfLoading || 'Ahmedabad Air Cargo',
      shipment.carriage.portOfDischarge || 'Destination Port',
      shipment.carriage.finalDestination || shipment.buyer.country,
    ],
    ['Terms of Delivery & Payment', `${shipment.incoterm} ${shipment.namedPortOrPlace}`, `Payment: ${shipment.paymentTerms || '100% Advance Wire Transfer against Proforma'}`],
    [''],
    ['Item No', 'Marks & Nos.', 'Description of Goods', 'HS Code', 'Quantity', `Unit Price (${shipment.currency})`, `Amount (${shipment.currency})`],
  ];

  shipment.lineItems.forEach((item, index) => {
    piRows.push([
      index + 1,
      item.marksAndNos || `BOX ${index + 1}`,
      item.description,
      item.hsnCode,
      Number(item.quantity),
      item.unitPrice,
      item.amount,
    ]);
  });

  piRows.push(['']);
  piRows.push(['', '', '', '', 'Total FOB / PI Value', '', summary.grandTotalFobOrCif]);
  piRows.push(['Amount in Words', convertToInternationalWords(summary.grandTotalFobOrCif, shipment.currency)]);
  piRows.push(['']);
  piRows.push(['Advance T/T Wire Transfer Banking Details:']);
  piRows.push([`Beneficiary: ${shipment.exporter.companyName || 'Innovative Flexotech Private Limited'}`]);
  piRows.push([`Bank: ${shipment.exporter.bankName || 'State Bank of India'}, Vatva GIDC Branch, Ahmedabad`]);
  piRows.push([`A/C No: ${shipment.exporter.accountNumber || '3920194820192'} | SWIFT: ${shipment.exporter.swiftCode || 'SBININBB481'} | IFSC: ${shipment.exporter.ifscCode || 'SBIN0001842'}`]);
  piRows.push([`AD Code: ${shipment.exporter.adCode || '0510002-4820194'}`]);
  piRows.push(['']);
  piRows.push(['For, Innovative Flexotech Pvt. Ltd. - Authorized Signatory']);

  const piSheet = XLSX.utils.aoa_to_sheet(piRows);
  XLSX.utils.book_append_sheet(wb, piSheet, 'Proforma Invoice');

  // ---------------------------------------------------------
  // SHEET 5: CERTIFICATE OF ORIGIN
  // ---------------------------------------------------------
  const cooRows: (string | number)[][] = [
    ['CERTIFICATE OF ORIGIN (NON-PREFERENTIAL)'],
    ['INNOVATIVE FLEXOTECH PVT LTD - COMPLETE FLEXO SOLUTION'],
    [''],
    ['1. Goods Consigned From (Exporter / Manufacturer):', '', 'Reference No. & Origin Details:'],
    [shipment.exporter.companyName || 'Innovative Flexotech Private Limited', '', `Certificate No.: COO/IFPL/${shipment.documentNumber}`],
    ['FF/4, Rameshwar Residency, Ghuma, Ahmedabad-380058, Gujarat, INDIA', '', `Date: ${shipment.invoiceDate}`],
    [`IEC: ${shipment.exporter.iecCode || '0807016772'} | GSTIN: ${shipment.exporter.gstin || '24AABCI7261H1ZO'}`, '', 'COUNTRY OF ORIGIN: INDIA'],
    [''],
    ['2. Goods Consigned To (Consignee):', '', '3. Transport Details:'],
    [shipment.consignee.name || shipment.buyer.name, '', `Mode: ${shipment.carriage.preCarriageBy || 'By Air'}`],
    [shipment.consignee.address || shipment.buyer.address, '', `Loading Port: ${shipment.carriage.portOfLoading || 'Ahmedabad Air Cargo'}`],
    [`Country: ${shipment.consignee.country || shipment.buyer.country}`, '', `Discharge Port: ${shipment.carriage.portOfDischarge || 'Destination Port'}`],
    [''],
    ['Item', 'Marks & Nos.', 'Description of Goods', 'HS Code', 'Quantity', 'Gross Weight (KG)'],
  ];

  shipment.lineItems.forEach((item, index) => {
    cooRows.push([
      index + 1,
      item.marksAndNos || `BOX ${index + 1}`,
      item.description,
      item.hsnCode,
      `${item.quantity} ${item.unit}`,
      item.grossWeightKg,
    ]);
  });

  cooRows.push(['']);
  cooRows.push(['Total Packages', `${summary.totalPackagesCount} Box`]);
  cooRows.push(['Total Net Weight (KG)', summary.totalNetWeightKg]);
  cooRows.push(['Total Gross Weight (KG)', summary.totalGrossWeightKg]);
  cooRows.push([`Commercial Invoice Reference: Invoice No. ${shipment.documentNumber} dated ${shipment.invoiceDate}`]);
  cooRows.push(['']);
  cooRows.push(['Declaration by Exporter: We declare that all goods were manufactured in INDIA by Innovative Flexotech Private Limited.']);
  cooRows.push(['For, Innovative Flexotech Pvt. Ltd. - Authorized Signatory']);

  const cooSheet = XLSX.utils.aoa_to_sheet(cooRows);
  XLSX.utils.book_append_sheet(wb, cooSheet, 'Certificate of Origin');

  // ---------------------------------------------------------
  // SHEET 6: STATUTORY EXPORT DECLARATION (UNDER LUT)
  // ---------------------------------------------------------
  const declRows: (string | number)[][] = [
    ['STATUTORY EXPORT DECLARATION & UNDERTAKING (UNDER LUT)'],
    ['Under Section 16 of the IGST Act, 2017 & Rule 96A of CGST Rules, 2017'],
    ['INNOVATIVE FLEXOTECH PRIVATE LIMITED'],
    [''],
    ['Exporter GSTIN:', shipment.exporter.gstin || '24AABCI7261H1ZO', 'Invoice No.:', shipment.documentNumber],
    ['Exporter IEC:', shipment.exporter.iecCode || '0807016772', 'Invoice Date:', shipment.invoiceDate],
    ['Exporter PAN:', shipment.exporter.panNumber || 'AABCI7261H', 'LUT ARN:', shipment.gstAndCustoms.lutNumber || 'AD2402260127874'],
    ['Authorized Dealer (AD) Code:', shipment.exporter.adCode || '0510002-4820194', 'Port of Loading:', shipment.carriage.portOfLoading || 'Ahmedabad Air Cargo'],
    [''],
    ['Consignment Particulars:'],
    ['Goods Description:', shipment.lineItems[0]?.description || 'Photopolymer Plate Making Equipment'],
    ['HS Code:', shipment.lineItems[0]?.hsnCode || '84425020'],
    ['Total Packages:', `${summary.totalPackagesCount} Box`],
    ['Total Net Weight:', `${summary.totalNetWeightKg} KG`],
    ['Total Gross Weight:', `${summary.totalGrossWeightKg} KG`],
    [`Invoiced Value (${shipment.currency}):`, summary.grandTotalFobOrCif],
    ['Equivalent Invoiced Value (INR):', summary.grandTotalInr],
    [''],
    ['Statutory Undertakings & Declarations:'],
    ['1. Zero-Rated Export under LUT ARN ' + (shipment.gstAndCustoms.lutNumber || 'AD2402260127874') + ' without payment of IGST under Sec 16 of IGST Act 2017.'],
    ['2. RoDTEP Scheme Claim Declaration under Para 4.54 of Foreign Trade Policy (2023-2028).'],
    ['3. Duty Drawback (DBK) Declaration under Customs Act, 1962.'],
    ['4. RBI Caution List & Foreign Exchange Realization Undertaking under FEMA, 1999.'],
    ['5. Commercial Value & Origin Undertaking (100% Manufactured in India).'],
    [''],
    ['Declared At: Ahmedabad, Gujarat, INDIA'],
    ['For, Innovative Flexotech Pvt. Ltd. - Authorized Signatory / Director'],
  ];

  const declSheet = XLSX.utils.aoa_to_sheet(declRows);
  XLSX.utils.book_append_sheet(wb, declSheet, 'Export Declaration');

  const safeFilename = `Innovative_Flexotech_${shipment.documentNumber.replace(/[^a-zA-Z0-9_-]/g, '_')}.xlsx`;
  XLSX.writeFile(wb, safeFilename);
}
