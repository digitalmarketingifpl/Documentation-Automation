import React, { useState } from 'react';
import {
  ShipmentDocument,
  LineItem,
  PackageDetail,
  Currency,
  Incoterm,
  SupplyType,
} from '../types/trade';
import { calculateShipmentSummary } from '../utils/calculations';
import {
  Plus,
  Trash2,
  Save,
  AlertTriangle,
  CheckCircle,
  HelpCircle,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

interface DocumentEditorProps {
  shipment: ShipmentDocument;
  onUpdateShipment: (updated: ShipmentDocument) => void;
  onOpenAiAudit: () => void;
}

export const DocumentEditor: React.FC<DocumentEditorProps> = ({
  shipment,
  onUpdateShipment,
  onOpenAiAudit,
}) => {
  const summary = calculateShipmentSummary(shipment);
  const [activeSection, setActiveSection] = useState<string>('items');

  const updateField = (path: string, value: any) => {
    const copy = JSON.parse(JSON.stringify(shipment));
    const parts = path.split('.');
    let curr = copy;
    for (let i = 0; i < parts.length - 1; i++) {
      if (!curr[parts[i]]) curr[parts[i]] = {};
      curr = curr[parts[i]];
    }
    curr[parts[parts.length - 1]] = value;
    copy.updatedAt = new Date().toISOString();
    onUpdateShipment(copy);
  };

  // Line item handlers
  const handleAddLineItem = () => {
    const newItem: LineItem = {
      id: `li-${Date.now()}`,
      itemNo: (shipment.lineItems?.length || 0) + 1,
      marksAndNos: `EXP/${(shipment.lineItems?.length || 0) + 1}`,
      description: 'Precision Machined Mechanical Components',
      hsnCode: '84819090',
      quantity: 100,
      unit: 'PCS',
      unitPrice: 50.0,
      amount: 5000.0,
      netWeightKg: 500,
      grossWeightKg: 540,
      cbm: 0.85,
      rodtepClaimed: true,
    };
    const updatedItems = [...(shipment.lineItems || []), newItem];
    updateField('lineItems', updatedItems);
  };

  const handleUpdateLineItem = (index: number, field: keyof LineItem, value: any) => {
    const items = [...shipment.lineItems];
    const item = { ...items[index], [field]: value };
    if (field === 'quantity' || field === 'unitPrice') {
      const q = field === 'quantity' ? Number(value) || 0 : Number(item.quantity) || 0;
      const p = field === 'unitPrice' ? Number(value) || 0 : Number(item.unitPrice) || 0;
      item.amount = Number((q * p).toFixed(2));
    }
    items[index] = item;
    updateField('lineItems', items);
  };

  const handleRemoveLineItem = (index: number) => {
    const items = shipment.lineItems.filter((_, idx) => idx !== index);
    updateField('lineItems', items);
  };

  // Package handlers
  const handleAddPackage = () => {
    const newPkg: PackageDetail = {
      id: `pkg-${Date.now()}`,
      packageNoRange: `BOX ${(shipment.packageDetails?.length || 0) + 1}`,
      marksAndNumbers: `EXP/${shipment.buyer.country.slice(0, 2).toUpperCase()}/${(shipment.packageDetails?.length || 0) + 1}`,
      packageType: 'ISPM-15 Wooden Pallet Box',
      packageCount: 1,
      lengthCm: 80,
      widthCm: 60,
      heightCm: 50,
      unitCbm: 0.24,
      totalCbm: 0.24,
      netWeightKg: 200,
      grossWeightKg: 220,
      contentsDescription: 'Precision Components as per Invoice',
    };
    const updated = [...(shipment.packageDetails || []), newPkg];
    updateField('packageDetails', updated);
  };

  const handleUpdatePackage = (index: number, field: keyof PackageDetail, value: any) => {
    const pkgs = [...shipment.packageDetails];
    const pkg = { ...pkgs[index], [field]: value };
    if (field === 'lengthCm' || field === 'widthCm' || field === 'heightCm' || field === 'packageCount') {
      const l = field === 'lengthCm' ? Number(value) || 0 : Number(pkg.lengthCm) || 0;
      const w = field === 'widthCm' ? Number(value) || 0 : Number(pkg.widthCm) || 0;
      const h = field === 'heightCm' ? Number(value) || 0 : Number(pkg.heightCm) || 0;
      const count = field === 'packageCount' ? Number(value) || 1 : Number(pkg.packageCount) || 1;
      const unitCbm = Number(((l * w * h) / 1_000_000).toFixed(4));
      pkg.unitCbm = unitCbm;
      pkg.totalCbm = Number((unitCbm * count).toFixed(3));
    }
    pkgs[index] = pkg;
    updateField('packageDetails', pkgs);
  };

  const handleRemovePackage = (index: number) => {
    const pkgs = shipment.packageDetails.filter((_, idx) => idx !== index);
    updateField('packageDetails', pkgs);
  };

  return (
    <div className="max-w-5xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Live Financial & Compliance Health Card */}
      <div className="bg-white rounded-xl p-4 sm:p-5 border border-slate-200 shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Live Trade Calculation Engine & Status
            </h2>
            <p className="text-xs text-slate-500">
              Real-time synchronization across Commercial Invoice, Tax Invoice (GST), and Packing List
            </p>
          </div>

          <button
            onClick={onOpenAiAudit}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-amber-900 bg-amber-50 hover:bg-amber-100 border border-amber-300 rounded-lg transition-colors cursor-pointer"
          >
            Run Compliance Audit
          </button>
        </div>

        {/* Real-time Metric Badges */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3 pt-4 text-xs">
          <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
            <span className="text-[10px] text-slate-500 uppercase font-semibold block">Total Items:</span>
            <span className="text-sm font-bold text-slate-900 font-mono-tabular">
              {summary.totalQuantity.toLocaleString()} {shipment.lineItems[0]?.unit || 'Units'}
            </span>
          </div>

          <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
            <span className="text-[10px] text-slate-500 uppercase font-semibold block">Grand Total ({shipment.currency}):</span>
            <span className="text-sm font-bold text-slate-900 font-mono-tabular">
              {shipment.currency} {summary.grandTotalFobOrCif.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </span>
          </div>

          <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
            <span className="text-[10px] text-slate-500 uppercase font-semibold block">CBIC Inr Value:</span>
            <span className="text-sm font-bold text-slate-900 font-mono-tabular">
              ₹ {summary.grandTotalInr.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </span>
          </div>

          <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
            <span className="text-[10px] text-slate-500 uppercase font-semibold block">Total Net Wt:</span>
            <span className="text-sm font-bold text-slate-900 font-mono-tabular">
              {summary.totalNetWeightKg.toLocaleString()} Kg
            </span>
          </div>

          <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
            <span className="text-[10px] text-slate-500 uppercase font-semibold block">Total Gross Wt:</span>
            <span className="text-sm font-bold text-slate-900 font-mono-tabular">
              {summary.totalGrossWeightKg.toLocaleString()} Kg
            </span>
          </div>

          <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
            <span className="text-[10px] text-slate-500 uppercase font-semibold block">Total Volume:</span>
            <span className="text-sm font-bold text-slate-900 font-mono-tabular">
              {summary.totalCbm} CBM
            </span>
          </div>
        </div>

        {/* Tare Weight Alert if Gross < Net */}
        {summary.weightDiscrepancy && (
          <div className="mt-3 p-2.5 bg-rose-50 border border-rose-300 rounded-lg text-xs text-rose-800 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>
              <strong>Weight Discrepancy Detected:</strong> Total Gross Weight ({summary.totalGrossWeightKg} kg) is less than Net Weight ({summary.totalNetWeightKg} kg). Indian customs will flag tare weight anomalies.
            </span>
          </div>
        )}

        {/* LUT Warning */}
        {summary.isLutMissing && (
          <div className="mt-2 p-2.5 bg-amber-50 border border-amber-300 rounded-lg text-xs text-amber-800 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
            <span>
              <strong>LUT ARN Reference Missing:</strong> Zero-rated export without payment of IGST requires a valid Letter of Undertaking (LUT) ARN for FY 2026-27.
            </span>
          </div>
        )}
      </div>

      {/* Editor Sections Navigation Tabs */}
      <div className="flex flex-wrap gap-1 p-1 bg-slate-200/60 rounded-lg border border-slate-300 text-xs font-semibold">
        {[
          { id: 'general', label: '1. Invoice & References' },
          { id: 'parties', label: '2. Buyer & Consignee' },
          { id: 'carriage', label: '3. Carriage & Routing' },
          { id: 'gst-customs', label: '4. GST, LUT & Schemes' },
          { id: 'lc', label: '5. Letter of Credit (LC)' },
          { id: 'items', label: '6. Line Items Grid' },
          { id: 'packing', label: '7. Packing & CBM Breakdown' },
          { id: 'charges', label: '8. Financial Charges' },
        ].map((sec) => (
          <button
            key={sec.id}
            onClick={() => setActiveSection(sec.id)}
            className={`px-3 py-1.5 rounded-md transition-all cursor-pointer ${
              activeSection === sec.id
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {sec.label}
          </button>
        ))}
      </div>

      {/* Section 1: General & References */}
      {activeSection === 'general' && (
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">
            Document Identifiers & Currency Rates
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Commercial Invoice No:</label>
              <input
                type="text"
                value={shipment.documentNumber}
                onChange={(e) => updateField('documentNumber', e.target.value)}
                className="w-full font-mono-tabular px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-slate-900"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Commercial Invoice Date:</label>
              <input
                type="date"
                value={shipment.invoiceDate}
                onChange={(e) => updateField('invoiceDate', e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-slate-900"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Tax Invoice No (GST):</label>
              <input
                type="text"
                value={shipment.taxInvoiceNumber}
                onChange={(e) => updateField('taxInvoiceNumber', e.target.value)}
                className="w-full font-mono-tabular px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-slate-900"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Tax Invoice Date:</label>
              <input
                type="date"
                value={shipment.taxInvoiceDate}
                onChange={(e) => updateField('taxInvoiceDate', e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-slate-900"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Currency Code:</label>
              <select
                value={shipment.currency}
                onChange={(e) => updateField('currency', e.target.value as Currency)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg font-semibold bg-white"
              >
                <option value="USD">USD - US Dollar</option>
                <option value="EUR">EUR - Euro</option>
                <option value="GBP">GBP - British Pound</option>
                <option value="AED">AED - UAE Dirham</option>
                <option value="INR">INR - Indian Rupee</option>
                <option value="JPY">JPY - Japanese Yen</option>
                <option value="CAD">CAD - Canadian Dollar</option>
                <option value="AUD">AUD - Australian Dollar</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                CBIC Exchange Rate (INR / Foreign):
              </label>
              <input
                type="number"
                step="0.01"
                value={shipment.exchangeRateInr}
                onChange={(e) => updateField('exchangeRateInr', parseFloat(e.target.value) || 1)}
                className="w-full font-mono-tabular px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Incoterms 2020:</label>
              <select
                value={shipment.incoterm}
                onChange={(e) => updateField('incoterm', e.target.value as Incoterm)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg font-semibold bg-white"
              >
                <option value="FOB">FOB - Free on Board</option>
                <option value="CIF">CIF - Cost, Insurance & Freight</option>
                <option value="CFR">CFR - Cost & Freight</option>
                <option value="EXW">EXW - Ex Works</option>
                <option value="FCA">FCA - Free Carrier</option>
                <option value="CIP">CIP - Carriage & Insurance Paid</option>
                <option value="CPT">CPT - Carriage Paid To</option>
                <option value="DDP">DDP - Delivered Duty Paid</option>
                <option value="DAP">DAP - Delivered at Place</option>
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">Named Port / Place of Delivery:</label>
              <input
                type="text"
                value={shipment.namedPortOrPlace}
                onChange={(e) => updateField('namedPortOrPlace', e.target.value)}
                placeholder="e.g. Nhava Sheva (JNPT) or Hamburg Port, Germany"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">Terms of Payment:</label>
              <input
                type="text"
                value={shipment.paymentTerms}
                onChange={(e) => updateField('paymentTerms', e.target.value)}
                placeholder="e.g. 100% Irrevocable LC at Sight or 30 Days DA"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Customer PO Number:</label>
              <input
                type="text"
                value={shipment.customerPoNumber}
                onChange={(e) => updateField('customerPoNumber', e.target.value)}
                className="w-full font-mono-tabular px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Customer PO Date:</label>
              <input
                type="date"
                value={shipment.customerPoDate}
                onChange={(e) => updateField('customerPoDate', e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>
          </div>
        </div>
      )}

      {/* Section 2: Buyer & Consignee */}
      {activeSection === 'parties' && (
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">
            Overseas Buyer, Consignee & Notify Party
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            {/* Buyer */}
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
              <span className="font-bold text-slate-900 block text-xs">Buyer / Applicant</span>
              <div>
                <label className="block font-semibold text-slate-600 mb-0.5">Buyer Legal Name:</label>
                <input
                  type="text"
                  value={shipment.buyer.name}
                  onChange={(e) => updateField('buyer.name', e.target.value)}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-md bg-white"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-600 mb-0.5">Address:</label>
                <textarea
                  rows={2}
                  value={shipment.buyer.address}
                  onChange={(e) => updateField('buyer.address', e.target.value)}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-md bg-white"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-600 mb-0.5">Country:</label>
                  <input
                    type="text"
                    value={shipment.buyer.country}
                    onChange={(e) => updateField('buyer.country', e.target.value)}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md bg-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-600 mb-0.5">VAT / Tax ID:</label>
                  <input
                    type="text"
                    value={shipment.buyer.taxIdOrVat}
                    onChange={(e) => updateField('buyer.taxIdOrVat', e.target.value)}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md bg-white font-mono-tabular"
                  />
                </div>
              </div>
            </div>

            {/* Consignee */}
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900 text-xs">Consignee</span>
                <label className="flex items-center gap-1.5 text-xs text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={shipment.consignee.isSameAsBuyer}
                    onChange={(e) => updateField('consignee.isSameAsBuyer', e.target.checked)}
                    className="rounded text-slate-900"
                  />
                  <span>Same as Buyer</span>
                </label>
              </div>

              {!shipment.consignee.isSameAsBuyer ? (
                <>
                  <div>
                    <label className="block font-semibold text-slate-600 mb-0.5">Consignee Name:</label>
                    <input
                      type="text"
                      value={shipment.consignee.name}
                      onChange={(e) => updateField('consignee.name', e.target.value)}
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-md bg-white"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-600 mb-0.5">Consignee Address:</label>
                    <textarea
                      rows={2}
                      value={shipment.consignee.address}
                      onChange={(e) => updateField('consignee.address', e.target.value)}
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-md bg-white"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-600 mb-0.5">Country:</label>
                    <input
                      type="text"
                      value={shipment.consignee.country}
                      onChange={(e) => updateField('consignee.country', e.target.value)}
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-md bg-white"
                    />
                  </div>
                </>
              ) : (
                <div className="p-4 bg-white rounded border border-slate-200 text-center text-slate-500 italic">
                  Consignee is marked as "Same as Buyer". Invoice and shipping documents will display "SAME AS BUYER".
                </div>
              )}
            </div>

            {/* Notify Party */}
            <div className="sm:col-span-2 p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
              <span className="font-bold text-slate-900 block text-xs">Notify Party / Clearing Agent</span>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <div>
                  <label className="block font-semibold text-slate-600 mb-0.5">Notify Party Name:</label>
                  <input
                    type="text"
                    value={shipment.notifyParty?.name || ''}
                    onChange={(e) => updateField('notifyParty.name', e.target.value)}
                    placeholder="e.g. Panalpina Logistics CFS Hamburg"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md bg-white"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block font-semibold text-slate-600 mb-0.5">Notify Address & Contact:</label>
                  <input
                    type="text"
                    value={shipment.notifyParty?.address || ''}
                    onChange={(e) => updateField('notifyParty.address', e.target.value)}
                    placeholder="Address, Phone, Email"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md bg-white"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Section 3: Carriage & Logistics */}
      {activeSection === 'carriage' && (
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">
            Carriage, Vessel & Indian Port of Loading Details
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Pre-Carriage By:</label>
              <input
                type="text"
                value={shipment.carriage.preCarriageBy}
                onChange={(e) => updateField('carriage.preCarriageBy', e.target.value)}
                placeholder="e.g. By Road Container Trailer"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Place of Receipt (Factory/ICD):</label>
              <input
                type="text"
                value={shipment.carriage.placeOfReceipt}
                onChange={(e) => updateField('carriage.placeOfReceipt', e.target.value)}
                placeholder="e.g. ICD Tughlakabad or Chakan Pune"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Port of Loading (POL):</label>
              <input
                type="text"
                value={shipment.carriage.portOfLoading}
                onChange={(e) => updateField('carriage.portOfLoading', e.target.value)}
                placeholder="e.g. Nhava Sheva (JNPT) [INNSA1]"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Port of Discharge (POD):</label>
              <input
                type="text"
                value={shipment.carriage.portOfDischarge}
                onChange={(e) => updateField('carriage.portOfDischarge', e.target.value)}
                placeholder="e.g. Port of Hamburg [DEHAM]"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Vessel / Flight No:</label>
              <input
                type="text"
                value={shipment.carriage.vesselFlightNo}
                onChange={(e) => updateField('carriage.vesselFlightNo', e.target.value)}
                placeholder="e.g. MSC GAIA / V.241W"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Final Destination Place:</label>
              <input
                type="text"
                value={shipment.carriage.finalDestination}
                onChange={(e) => updateField('carriage.finalDestination', e.target.value)}
                placeholder="e.g. Stuttgart, Germany"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Country of Origin:</label>
              <input
                type="text"
                value={shipment.carriage.countryOfOrigin}
                onChange={(e) => updateField('carriage.countryOfOrigin', e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Country of Final Destination:</label>
              <input
                type="text"
                value={shipment.carriage.countryOfFinalDestination}
                onChange={(e) => updateField('carriage.countryOfFinalDestination', e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>
          </div>
        </div>
      )}

      {/* Section 4: GST, LUT & Customs Schemes */}
      {activeSection === 'gst-customs' && (
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">
            Indian GST Act Section 16, Customs Schemes & RoDTEP Compliance
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Export Supply Type:</label>
              <select
                value={shipment.gstAndCustoms.supplyType}
                onChange={(e) => updateField('gstAndCustoms.supplyType', e.target.value as SupplyType)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg font-semibold bg-white"
              >
                <option value="LUT_WITHOUT_TAX">Supply under LUT without payment of IGST (Sec 16)</option>
                <option value="WITH_IGST">Supply on payment of Integrated Tax (IGST)</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Letter of Undertaking (LUT) ARN:</label>
              <input
                type="text"
                value={shipment.gstAndCustoms.lutNumber}
                onChange={(e) => updateField('gstAndCustoms.lutNumber', e.target.value)}
                placeholder="e.g. AD270326008492X"
                className="w-full font-mono-tabular px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">LUT Period / Date:</label>
              <input
                type="text"
                value={shipment.gstAndCustoms.lutDate}
                onChange={(e) => updateField('gstAndCustoms.lutDate', e.target.value)}
                placeholder="e.g. 2026-04-01"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Shipping Bill No (Allocated):</label>
              <input
                type="text"
                value={shipment.gstAndCustoms.shippingBillNo}
                onChange={(e) => updateField('gstAndCustoms.shippingBillNo', e.target.value)}
                placeholder="e.g. SB-8392019/2026"
                className="w-full font-mono-tabular px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Bank Authorized Dealer (AD) Code:</label>
              <input
                type="text"
                value={shipment.gstAndCustoms.adCode || shipment.exporter.adCode}
                onChange={(e) => updateField('gstAndCustoms.adCode', e.target.value)}
                placeholder="14-digit ICEGATE registered AD code"
                className="w-full font-mono-tabular px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Customs Scheme Code:</label>
              <select
                value={shipment.gstAndCustoms.schemeCode}
                onChange={(e) => updateField('gstAndCustoms.schemeCode', e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white"
              >
                <option value="19 - Duty Drawback">19 - Duty Drawback</option>
                <option value="60 - RoDTEP Scheme">60 - RoDTEP Scheme</option>
                <option value="00 - Free Shipping Bill">00 - Free Shipping Bill</option>
                <option value="01 - Advance Authorization">01 - Advance Authorization</option>
                <option value="02 - EPCG Scheme">02 - EPCG Scheme</option>
              </select>
            </div>

            <div className="sm:col-span-3 flex flex-wrap gap-6 p-3 bg-slate-50 rounded-lg border border-slate-200">
              <label className="flex items-center gap-2 cursor-pointer font-semibold text-slate-800">
                <input
                  type="checkbox"
                  checked={shipment.gstAndCustoms.rodtepClaimDeclaration}
                  onChange={(e) => updateField('gstAndCustoms.rodtepClaimDeclaration', e.target.checked)}
                  className="rounded text-slate-900"
                />
                <span>Claim RoDTEP Benefits under Customs Scheme Code 60</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer font-semibold text-slate-800">
                <input
                  type="checkbox"
                  checked={shipment.gstAndCustoms.dbkClaimDeclaration}
                  onChange={(e) => updateField('gstAndCustoms.dbkClaimDeclaration', e.target.checked)}
                  className="rounded text-slate-900"
                />
                <span>Duty Drawback (DBK) Claim Declaration</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer font-semibold text-slate-800">
                <input
                  type="checkbox"
                  checked={shipment.gstAndCustoms.fema1999Declaration}
                  onChange={(e) => updateField('gstAndCustoms.fema1999Declaration', e.target.checked)}
                  className="rounded text-slate-900"
                />
                <span>RBI FEMA 1999 Realization Undertaking</span>
              </label>
            </div>
          </div>
        </div>
      )}

      {/* Section 5: Letter of Credit (LC) */}
      {activeSection === 'lc' && (
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Letter of Credit (LC) Documentary Credit Compliance
              </h3>
              <p className="text-xs text-slate-500">
                UCP 600 compliant fields for 47A / 46A documentary instructions
              </p>
            </div>
            <label className="flex items-center gap-2 text-xs font-semibold text-slate-800 cursor-pointer">
              <input
                type="checkbox"
                checked={shipment.lcDetails?.hasLc}
                onChange={(e) => updateField('lcDetails.hasLc', e.target.checked)}
                className="rounded text-slate-900"
              />
              <span>Shipment Covered by Letter of Credit</span>
            </label>
          </div>

          {shipment.lcDetails?.hasLc ? (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Doc. Credit (LC) Number:</label>
                <input
                  type="text"
                  value={shipment.lcDetails.documentaryCreditNumber}
                  onChange={(e) => updateField('lcDetails.documentaryCreditNumber', e.target.value)}
                  placeholder="e.g. LC/2026/CH/998124"
                  className="w-full font-mono-tabular px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Issuing Bank Name:</label>
                <input
                  type="text"
                  value={shipment.lcDetails.issuingBank}
                  onChange={(e) => updateField('lcDetails.issuingBank', e.target.value)}
                  placeholder="e.g. JPMorgan Chase Bank N.A."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Advising Bank Reference:</label>
                <input
                  type="text"
                  value={shipment.lcDetails.advisingBankRef}
                  onChange={(e) => updateField('lcDetails.advisingBankRef', e.target.value)}
                  placeholder="e.g. SBIN/ADV/26/4910"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono-tabular"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">LC Issuing Date:</label>
                <input
                  type="date"
                  value={shipment.lcDetails.issuingDate}
                  onChange={(e) => updateField('lcDetails.issuingDate', e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Latest Shipment Date:</label>
                <input
                  type="date"
                  value={shipment.lcDetails.latestShipmentDate}
                  onChange={(e) => updateField('lcDetails.latestShipmentDate', e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">LC Expiry Date:</label>
                <input
                  type="date"
                  value={shipment.lcDetails.expiryDate}
                  onChange={(e) => updateField('lcDetails.expiryDate', e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div className="sm:col-span-3">
                <label className="block font-semibold text-slate-700 mb-1">
                  Special Clauses 47A / Statutory Certifications:
                </label>
                <textarea
                  rows={2}
                  value={shipment.lcDetails.specialClauses47A}
                  onChange={(e) => updateField('lcDetails.specialClauses47A', e.target.value)}
                  placeholder="e.g. Commercial invoice in 1 original + 3 copies certifying goods are 100% compliant..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>
            </div>
          ) : (
            <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 text-center text-slate-500 text-xs italic">
              Letter of Credit is not enabled for this shipment. Toggle the checkbox above if the importer requires LC compliance under UCP 600.
            </div>
          )}
        </div>
      )}

      {/* Section 6: Dynamic Line Items Grid */}
      {activeSection === 'items' && (
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Invoice Line Items & Commercial Descriptions
              </h3>
              <p className="text-xs text-slate-500">
                Auto-calculates item amounts, foreign currency totals, and weights
              </p>
            </div>
            <button
              onClick={handleAddLineItem}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Product Line
            </button>
          </div>

          <div className="space-y-3">
            {shipment.lineItems.map((item, idx) => (
              <div
                key={item.id || idx}
                className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-2"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800 font-mono-tabular">
                    Item #{idx + 1}
                  </span>
                  <button
                    onClick={() => handleRemoveLineItem(idx)}
                    className="text-rose-600 hover:text-rose-800 p-1 transition-colors cursor-pointer"
                    title="Remove Line Item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
                  <div className="sm:col-span-5">
                    <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">
                      Description of Goods:
                    </label>
                    <input
                      type="text"
                      value={item.description}
                      onChange={(e) => handleUpdateLineItem(idx, 'description', e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-md font-medium text-slate-900"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">
                      HSN Code (8-digit):
                    </label>
                    <input
                      type="text"
                      value={item.hsnCode}
                      onChange={(e) => handleUpdateLineItem(idx, 'hsnCode', e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-md font-mono-tabular text-center"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">
                      Quantity:
                    </label>
                    <input
                      type="number"
                      value={item.quantity}
                      onChange={(e) => handleUpdateLineItem(idx, 'quantity', parseFloat(e.target.value) || 0)}
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-md font-mono-tabular text-right"
                    />
                  </div>

                  <div className="sm:col-span-1">
                    <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">
                      Unit:
                    </label>
                    <input
                      type="text"
                      value={item.unit}
                      onChange={(e) => handleUpdateLineItem(idx, 'unit', e.target.value)}
                      className="w-full px-2 py-1.5 bg-white border border-slate-300 rounded-md text-center uppercase"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">
                      Unit Price ({shipment.currency}):
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={item.unitPrice}
                      onChange={(e) => handleUpdateLineItem(idx, 'unitPrice', parseFloat(e.target.value) || 0)}
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-md font-mono-tabular text-right"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 border-t border-slate-200">
                  <div>
                    <label className="block text-[10px] text-slate-500">Marks & Numbers:</label>
                    <input
                      type="text"
                      value={item.marksAndNos}
                      onChange={(e) => handleUpdateLineItem(idx, 'marksAndNos', e.target.value)}
                      placeholder="e.g. EXP/01-10"
                      className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500">Net Weight (Kg):</label>
                    <input
                      type="number"
                      value={item.netWeightKg}
                      onChange={(e) => handleUpdateLineItem(idx, 'netWeightKg', parseFloat(e.target.value) || 0)}
                      className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs font-mono-tabular text-right"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500">Gross Weight (Kg):</label>
                    <input
                      type="number"
                      value={item.grossWeightKg}
                      onChange={(e) => handleUpdateLineItem(idx, 'grossWeightKg', parseFloat(e.target.value) || 0)}
                      className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs font-mono-tabular text-right"
                    />
                  </div>
                  <div className="text-right">
                    <span className="block text-[10px] text-slate-500">Item Total:</span>
                    <span className="font-bold text-slate-900 font-mono-tabular text-sm">
                      {shipment.currency} {Number(item.quantity * item.unitPrice).toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Section 7: Packing List & CBM */}
      {activeSection === 'packing' && (
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Detailed Packing List & Container CBM Breakup
              </h3>
              <p className="text-xs text-slate-500">
                Tabulates package range, carton/pallet count, dimension in cm, and auto-calculates cubic volume
              </p>
            </div>
            <button
              onClick={handleAddPackage}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Package Group
            </button>
          </div>

          <div className="space-y-3">
            {shipment.packageDetails?.map((pkg, idx) => (
              <div
                key={pkg.id || idx}
                className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-2"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800 font-mono-tabular">
                    Package Slot #{idx + 1}
                  </span>
                  <button
                    onClick={() => handleRemovePackage(idx)}
                    className="text-rose-600 hover:text-rose-800 p-1 transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-6 gap-2">
                  <div>
                    <label className="block text-[10px] font-semibold text-slate-600">Pkg No / Range:</label>
                    <input
                      type="text"
                      value={pkg.packageNoRange}
                      onChange={(e) => handleUpdatePackage(idx, 'packageNoRange', e.target.value)}
                      placeholder="e.g. CASE 01 TO 10"
                      className="w-full px-2 py-1 bg-white border border-slate-300 rounded font-semibold"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-semibold text-slate-600">Package Type:</label>
                    <input
                      type="text"
                      value={pkg.packageType}
                      onChange={(e) => handleUpdatePackage(idx, 'packageType', e.target.value)}
                      placeholder="e.g. Wooden Pallet Box"
                      className="w-full px-2 py-1 bg-white border border-slate-300 rounded"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-semibold text-slate-600">Package Count:</label>
                    <input
                      type="number"
                      value={pkg.packageCount}
                      onChange={(e) => handleUpdatePackage(idx, 'packageCount', parseInt(e.target.value, 10) || 1)}
                      className="w-full px-2 py-1 bg-white border border-slate-300 rounded font-mono-tabular text-right"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-semibold text-slate-600">Length (cm):</label>
                    <input
                      type="number"
                      value={pkg.lengthCm}
                      onChange={(e) => handleUpdatePackage(idx, 'lengthCm', parseFloat(e.target.value) || 0)}
                      className="w-full px-2 py-1 bg-white border border-slate-300 rounded font-mono-tabular text-right"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-semibold text-slate-600">Width (cm):</label>
                    <input
                      type="number"
                      value={pkg.widthCm}
                      onChange={(e) => handleUpdatePackage(idx, 'widthCm', parseFloat(e.target.value) || 0)}
                      className="w-full px-2 py-1 bg-white border border-slate-300 rounded font-mono-tabular text-right"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-semibold text-slate-600">Height (cm):</label>
                    <input
                      type="number"
                      value={pkg.heightCm}
                      onChange={(e) => handleUpdatePackage(idx, 'heightCm', parseFloat(e.target.value) || 0)}
                      className="w-full px-2 py-1 bg-white border border-slate-300 rounded font-mono-tabular text-right"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 pt-1 border-t border-slate-200">
                  <div className="sm:col-span-2">
                    <label className="block text-[10px] text-slate-500">Contents Description:</label>
                    <input
                      type="text"
                      value={pkg.contentsDescription}
                      onChange={(e) => handleUpdatePackage(idx, 'contentsDescription', e.target.value)}
                      placeholder="e.g. 400 PCS Forged Carbon Steel Flanges"
                      className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500">Net Weight (Kg):</label>
                    <input
                      type="number"
                      value={pkg.netWeightKg}
                      onChange={(e) => handleUpdatePackage(idx, 'netWeightKg', parseFloat(e.target.value) || 0)}
                      className="w-full px-2 py-1 bg-white border border-slate-300 rounded font-mono-tabular text-right"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500">Gross Weight (Kg):</label>
                    <input
                      type="number"
                      value={pkg.grossWeightKg}
                      onChange={(e) => handleUpdatePackage(idx, 'grossWeightKg', parseFloat(e.target.value) || 0)}
                      className="w-full px-2 py-1 bg-white border border-slate-300 rounded font-mono-tabular text-right"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="pt-2 border-t border-slate-200">
            <label className="block font-semibold text-slate-700 text-xs mb-1">
              Container Stuffing & Seal Summary:
            </label>
            <input
              type="text"
              value={shipment.containerSummary}
              onChange={(e) => updateField('containerSummary', e.target.value)}
              placeholder="e.g. 1 × 20' Heavy Tested GP Container (Container No: MSCU 847291-0 / Seal: INJN 74819)"
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
            />
          </div>
        </div>
      )}

      {/* Section 8: Financial Charges */}
      {activeSection === 'charges' && (
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">
            Freight, Insurance & Ancillary Trade Additions
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Ocean / Air Freight ({shipment.currency}):
              </label>
              <input
                type="number"
                step="0.01"
                value={shipment.freightCharge}
                onChange={(e) => updateField('freightCharge', parseFloat(e.target.value) || 0)}
                className="w-full font-mono-tabular px-3 py-2 border border-slate-300 rounded-lg text-right"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Marine Cargo Insurance ({shipment.currency}):
              </label>
              <input
                type="number"
                step="0.01"
                value={shipment.insuranceCharge}
                onChange={(e) => updateField('insuranceCharge', parseFloat(e.target.value) || 0)}
                className="w-full font-mono-tabular px-3 py-2 border border-slate-300 rounded-lg text-right"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Handling / Packaging / Misc ({shipment.currency}):
              </label>
              <input
                type="number"
                step="0.01"
                value={shipment.handlingOrMisc}
                onChange={(e) => updateField('handlingOrMisc', parseFloat(e.target.value) || 0)}
                className="w-full font-mono-tabular px-3 py-2 border border-slate-300 rounded-lg text-right"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Less Trade Discount ({shipment.currency}):
              </label>
              <input
                type="number"
                step="0.01"
                value={shipment.discountAmount}
                onChange={(e) => updateField('discountAmount', parseFloat(e.target.value) || 0)}
                className="w-full font-mono-tabular px-3 py-2 border border-slate-300 rounded-lg text-right text-emerald-800"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
