import React, { useState } from 'react';
import { X, Copy, RefreshCw, FilePlus, ArrowRight } from 'lucide-react';
import { CompanyProfile, ShipmentDocument } from '../types/trade';

interface NewDocumentModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeShipment: ShipmentDocument;
  masterProfile: CompanyProfile;
  onCreateShipment: (mode: 'retain-exporter' | 'clone-active' | 'clean-base', customInvoiceNo?: string) => void;
}

export const NewDocumentModal: React.FC<NewDocumentModalProps> = ({
  isOpen,
  onClose,
  activeShipment,
  masterProfile,
  onCreateShipment,
}) => {
  const [selectedMode, setSelectedMode] = useState<'retain-exporter' | 'clone-active' | 'clean-base'>('retain-exporter');
  
  // Calculate next auto-incremented invoice number suggestion
  const generateNextInvoiceNo = (baseNumber: string) => {
    // E.g. EXP/2026-27/004 -> EXP/2026-27/005
    const match = baseNumber.match(/^(.*?)(\d+)$/);
    if (match) {
      const prefix = match[1];
      const digits = match[2];
      const nextNum = (parseInt(digits, 10) + 1).toString().padStart(digits.length, '0');
      return `${prefix}${nextNum}`;
    }
    return `${baseNumber}-NEW`;
  };

  const [customInvoiceNumber, setCustomInvoiceNumber] = useState(
    generateNextInvoiceNo(activeShipment?.documentNumber || 'EXP/2026-27/001')
  );

  if (!isOpen) return null;

  const handleCreate = () => {
    onCreateShipment(selectedMode, customInvoiceNumber);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs no-print">
      <div className="bg-white rounded-xl shadow-xl max-w-xl w-full overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/50">
          <div>
            <h2 className="text-base font-bold text-slate-900">Create New Export Shipment</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Select provisioning mode for your next international trade document pack
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-md transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content & 3 Provisioning Modes */}
        <div className="p-6 space-y-4">
          <div className="space-y-3">
            {/* Mode 1: Retain Exporter Master Profile */}
            <div
              onClick={() => setSelectedMode('retain-exporter')}
              className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                selectedMode === 'retain-exporter'
                  ? 'border-slate-900 bg-slate-50/80 shadow-xs'
                  : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="flex items-start gap-3">
                <div
                  className={`p-2 rounded-md shrink-0 ${
                    selectedMode === 'retain-exporter' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  <RefreshCw className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-semibold text-slate-900">
                      Retain Exporter Master Profile
                    </span>
                    <span className="text-[11px] text-emerald-700 font-medium">Recommended for new buyers</span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">
                    Preserves company legal entity, factory address, GSTIN, IEC, PAN, Bank AD/SWIFT codes, and LUT references from master profile. Starts fresh with empty buyer and line item datasets.
                  </p>
                </div>
              </div>
            </div>

            {/* Mode 2: Clone / Duplicate Document */}
            <div
              onClick={() => setSelectedMode('clone-active')}
              className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                selectedMode === 'clone-active'
                  ? 'border-slate-900 bg-slate-50/80 shadow-xs'
                  : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="flex items-start gap-3">
                <div
                  className={`p-2 rounded-md shrink-0 ${
                    selectedMode === 'clone-active' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  <Copy className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-semibold text-slate-900">
                      Clone Active Shipment (Repeat Order)
                    </span>
                    <span className="text-[11px] text-blue-700 font-medium">Auto-increments invoice #</span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">
                    Duplicates the current active shipment ({activeShipment?.documentNumber || 'Active'}) including buyer details, line items, packaging specs, and carriage routes. Perfect for recurring orders.
                  </p>
                </div>
              </div>
            </div>

            {/* Mode 3: Clean Base Reference */}
            <div
              onClick={() => setSelectedMode('clean-base')}
              className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                selectedMode === 'clean-base'
                  ? 'border-slate-900 bg-slate-50/80 shadow-xs'
                  : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="flex items-start gap-3">
                <div
                  className={`p-2 rounded-md shrink-0 ${
                    selectedMode === 'clean-base' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  <FilePlus className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-semibold text-slate-900">
                      Clean Base Standard Template
                    </span>
                    <span className="text-[11px] text-slate-500 font-medium">Standard baseline</span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">
                    Initializes a standardized blank export invoice adhering to ICC Incoterms 2020 and Indian GST Section 16 statutory standards.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* New Invoice Number Input */}
          <div className="pt-2">
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              New Commercial Invoice Number
            </label>
            <input
              type="text"
              value={customInvoiceNumber}
              onChange={(e) => setCustomInvoiceNumber(e.target.value)}
              className="w-full text-sm font-mono-tabular px-3 py-2 bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-slate-900 focus:border-slate-900"
              placeholder="e.g. EXP/2026-27/007"
            />
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-end gap-3 px-6 py-4 bg-slate-50 border-t border-slate-200">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-700 hover:text-slate-900 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleCreate}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors shadow-xs"
          >
            Generate Shipment Pack
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
