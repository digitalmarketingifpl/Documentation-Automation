import React, { useState } from 'react';
import { CompanyProfile } from '../types/trade';
import { Building2, Landmark, Check, Upload, SlidersHorizontal, ShieldCheck } from 'lucide-react';

interface CompanyProfileSettingsProps {
  profile: CompanyProfile;
  onSaveProfile: (profile: CompanyProfile) => void;
}

export const CompanyProfileSettings: React.FC<CompanyProfileSettingsProps> = ({
  profile,
  onSaveProfile,
}) => {
  const [formData, setFormData] = useState<CompanyProfile>(profile);
  const [savedNotification, setSavedNotification] = useState(false);

  const handleChange = (field: keyof CompanyProfile, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleImageUpload = (
    field: 'signatureImage' | 'stampImage' | 'logoImage' | 'customHeaderImage' | 'customFooterImage',
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        handleChange(field, reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveProfile(formData);
    setSavedNotification(true);
    setTimeout(() => setSavedNotification(false), 3000);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      <div className="flex items-center justify-between border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Master Exporter Profile & Corporate Branding
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Global manufacturing entity credentials, Indian customs registrations (IEC/GSTIN), and banking AD codes
          </p>
        </div>

        {savedNotification && (
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-xs font-semibold">
            <Check className="w-4 h-4" />
            Master Profile Saved & Synced
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Section 1: Legal Entity & Registration */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">
            <Building2 className="w-4 h-4 text-slate-700" />
            Legal Exporter Entity & Regulatory Numbers
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">Company Legal Name:</label>
              <input
                type="text"
                value={formData.companyName}
                onChange={(e) => handleChange('companyName', e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg font-bold"
                required
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">Registered Office Address:</label>
              <textarea
                rows={2}
                value={formData.registeredOffice}
                onChange={(e) => handleChange('registeredOffice', e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                required
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">Factory / Manufacturing Unit Address:</label>
              <textarea
                rows={2}
                value={formData.factoryAddress}
                onChange={(e) => handleChange('factoryAddress', e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                required
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Import Export Code (IEC - 10 chars):</label>
              <input
                type="text"
                value={formData.iecCode}
                onChange={(e) => handleChange('iecCode', e.target.value)}
                className="w-full font-mono-tabular px-3 py-2 border border-slate-300 rounded-lg font-bold"
                required
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">GSTIN (15 chars):</label>
              <input
                type="text"
                value={formData.gstin}
                onChange={(e) => handleChange('gstin', e.target.value)}
                className="w-full font-mono-tabular px-3 py-2 border border-slate-300 rounded-lg font-bold"
                required
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Permanent Account No (PAN - 10 chars):</label>
              <input
                type="text"
                value={formData.panNumber}
                onChange={(e) => handleChange('panNumber', e.target.value)}
                className="w-full font-mono-tabular px-3 py-2 border border-slate-300 rounded-lg font-bold"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">State Name:</label>
                <input
                  type="text"
                  value={formData.stateName}
                  onChange={(e) => handleChange('stateName', e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">State Code:</label>
                <input
                  type="text"
                  value={formData.stateCode}
                  onChange={(e) => handleChange('stateCode', e.target.value)}
                  className="w-full font-mono-tabular px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Export Department Phone:</label>
              <input
                type="text"
                value={formData.phone}
                onChange={(e) => handleChange('phone', e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Official Export Email:</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => handleChange('email', e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Company Website:</label>
              <input
                type="text"
                value={formData.website}
                onChange={(e) => handleChange('website', e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Default Letter of Undertaking (LUT) ARN:</label>
              <input
                type="text"
                value={formData.lutNumber}
                onChange={(e) => handleChange('lutNumber', e.target.value)}
                className="w-full font-mono-tabular px-3 py-2 border border-slate-300 rounded-lg font-bold"
              />
            </div>
          </div>
        </div>

        {/* Section 2: Banking & Authorized Dealer Code */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">
            <Landmark className="w-4 h-4 text-slate-700" />
            International Banking & Authorized Dealer (AD) Codes
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Beneficiary Bank Name:</label>
              <input
                type="text"
                value={formData.bankName}
                onChange={(e) => handleChange('bankName', e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg font-bold"
                required
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Bank Branch Name:</label>
              <input
                type="text"
                value={formData.bankBranch}
                onChange={(e) => handleChange('bankBranch', e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Export Account Number:</label>
              <input
                type="text"
                value={formData.accountNumber}
                onChange={(e) => handleChange('accountNumber', e.target.value)}
                className="w-full font-mono-tabular px-3 py-2 border border-slate-300 rounded-lg font-bold"
                required
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Account Type:</label>
              <input
                type="text"
                value={formData.accountType}
                onChange={(e) => handleChange('accountType', e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">SWIFT / BIC Code:</label>
              <input
                type="text"
                value={formData.swiftCode}
                onChange={(e) => handleChange('swiftCode', e.target.value)}
                className="w-full font-mono-tabular px-3 py-2 border border-slate-300 rounded-lg font-bold"
                required
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">IFSC Code:</label>
              <input
                type="text"
                value={formData.ifscCode}
                onChange={(e) => handleChange('ifscCode', e.target.value)}
                className="w-full font-mono-tabular px-3 py-2 border border-slate-300 rounded-lg font-bold"
                required
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">
                Authorized Dealer (AD) Code (Registered with Indian Customs / ICEGATE):
              </label>
              <input
                type="text"
                value={formData.adCode}
                onChange={(e) => handleChange('adCode', e.target.value)}
                placeholder="e.g. 0510002-4820194"
                className="w-full font-mono-tabular px-3 py-2 border border-slate-300 rounded-lg font-bold"
                required
              />
              <span className="text-[10px] text-slate-500 mt-1 block">
                Required for electronic Shipping Bill generation and EDPMS/IDPMS reconciliation with Reserve Bank of India.
              </span>
            </div>
          </div>
        </div>

        {/* Section 3: Signatory & Digital Branding */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">
            <ShieldCheck className="w-4 h-4 text-slate-700" />
            Authorized Signatory & Digital Seal Customization
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Authorized Signatory Name:</label>
              <input
                type="text"
                value={formData.signatoryName}
                onChange={(e) => handleChange('signatoryName', e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg font-bold"
                required
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Signatory Designation:</label>
              <input
                type="text"
                value={formData.signatoryDesignation}
                onChange={(e) => handleChange('signatoryDesignation', e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                required
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">ISO Certification Badge Text:</label>
              <input
                type="text"
                value={formData.isoCertification}
                onChange={(e) => handleChange('isoCertification', e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">AEO Exporter Tier / Status:</label>
              <input
                type="text"
                value={formData.aeoStatus}
                onChange={(e) => handleChange('aeoStatus', e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>

            {/* Digital Signature Upload */}
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
              <label className="block font-semibold text-slate-700">Digital Signature Image (PNG/JPG):</label>
              <input
                type="file"
                accept="image/*"
                onChange={(e) => handleImageUpload('signatureImage', e)}
                className="text-xs text-slate-500 file:mr-2 file:py-1 file:px-2 file:rounded file:border-0 file:text-xs file:font-semibold file:bg-slate-900 file:text-white hover:file:bg-slate-800"
              />
              {formData.signatureImage && (
                <div className="p-2 bg-white rounded border border-slate-200 w-fit">
                  <img src={formData.signatureImage} alt="Signature Preview" className="h-10 object-contain" />
                </div>
              )}
            </div>

            {/* Corporate Seal Upload */}
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
              <label className="block font-semibold text-slate-700">Company Seal Stamp (PNG):</label>
              <input
                type="file"
                accept="image/*"
                onChange={(e) => handleImageUpload('stampImage', e)}
                className="text-xs text-slate-500 file:mr-2 file:py-1 file:px-2 file:rounded file:border-0 file:text-xs file:font-semibold file:bg-slate-900 file:text-white hover:file:bg-slate-800"
              />
              {formData.stampImage && (
                <div className="p-2 bg-white rounded border border-slate-200 w-fit">
                  <img src={formData.stampImage} alt="Seal Stamp Preview" className="h-10 object-contain" />
                </div>
              )}
            </div>

            {/* Custom Header Graphic Upload */}
            <div className="sm:col-span-2 p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <label className="block font-semibold text-slate-700">
                    Custom Document Header Image (Innovative Flexotech Brand):
                  </label>
                  <span className="text-[10px] text-slate-500">
                    Upload image file (e.g. WhatsApp Image 2026-10-10 at 2.40.57 PM.jpeg) to replace the vector header.
                  </span>
                </div>
                {formData.customHeaderImage && (
                  <button
                    type="button"
                    onClick={() => handleChange('customHeaderImage', undefined)}
                    className="text-xs text-rose-600 hover:text-rose-800 font-medium"
                  >
                    Reset to Default Header
                  </button>
                )}
              </div>
              <input
                type="file"
                accept="image/*"
                onChange={(e) => handleImageUpload('customHeaderImage', e)}
                className="text-xs text-slate-500 file:mr-2 file:py-1 file:px-2 file:rounded file:border-0 file:text-xs file:font-semibold file:bg-[#c81e1e] file:text-white hover:file:bg-[#a51818]"
              />
              {formData.customHeaderImage && (
                <div className="p-2 bg-white rounded border border-slate-200 max-w-xl">
                  <img src={formData.customHeaderImage} alt="Header Preview" className="w-full h-auto max-h-16 object-contain" />
                </div>
              )}
            </div>

            {/* Custom Footer Graphic Upload */}
            <div className="sm:col-span-2 p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <label className="block font-semibold text-slate-700">
                    Custom Document Footer Image (Dual-Plant Addresses):
                  </label>
                  <span className="text-[10px] text-slate-500">
                    Upload image file (e.g. WhatsApp Image 2026-10-10 at 2.40.57 PM (1).jpeg) to replace the vector footer.
                  </span>
                </div>
                {formData.customFooterImage && (
                  <button
                    type="button"
                    onClick={() => handleChange('customFooterImage', undefined)}
                    className="text-xs text-rose-600 hover:text-rose-800 font-medium"
                  >
                    Reset to Default Footer
                  </button>
                )}
              </div>
              <input
                type="file"
                accept="image/*"
                onChange={(e) => handleImageUpload('customFooterImage', e)}
                className="text-xs text-slate-500 file:mr-2 file:py-1 file:px-2 file:rounded file:border-0 file:text-xs file:font-semibold file:bg-[#c81e1e] file:text-white hover:file:bg-[#a51818]"
              />
              {formData.customFooterImage && (
                <div className="p-2 bg-white rounded border border-slate-200 max-w-xl">
                  <img src={formData.customFooterImage} alt="Footer Preview" className="w-full h-auto max-h-16 object-contain" />
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Section 4: Pre-printed Stationery Calibration Offsets */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">
            <SlidersHorizontal className="w-4 h-4 text-slate-700" />
            Pre-printed Letterhead Paper Calibration Offsets (Millimeters)
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <div className="flex justify-between font-semibold text-slate-700 mb-1">
                <span>Top Margin Offset (mm):</span>
                <span className="font-mono-tabular font-bold">{formData.stationeryTopMarginMm || 55} mm</span>
              </div>
              <input
                type="range"
                min="30"
                max="85"
                value={formData.stationeryTopMarginMm || 55}
                onChange={(e) => handleChange('stationeryTopMarginMm', parseInt(e.target.value, 10))}
                className="w-full accent-slate-900"
              />
              <span className="text-[10px] text-slate-500 block mt-1">
                Calibrated space for pre-printed company letterhead header on physical stationery.
              </span>
            </div>

            <div>
              <div className="flex justify-between font-semibold text-slate-700 mb-1">
                <span>Bottom Margin Offset (mm):</span>
                <span className="font-mono-tabular font-bold">{formData.stationeryBottomMarginMm || 25} mm</span>
              </div>
              <input
                type="range"
                min="15"
                max="50"
                value={formData.stationeryBottomMarginMm || 25}
                onChange={(e) => handleChange('stationeryBottomMarginMm', parseInt(e.target.value, 10))}
                className="w-full accent-slate-900"
              />
              <span className="text-[10px] text-slate-500 block mt-1">
                Margin offset above pre-printed company footer address on physical paper.
              </span>
            </div>
          </div>
        </div>

        {/* Save Master Profile Button */}
        <div className="flex justify-end pt-2">
          <button
            type="submit"
            className="px-6 py-2.5 bg-slate-900 text-white rounded-lg text-xs font-bold hover:bg-slate-800 transition-colors shadow-sm cursor-pointer"
          >
            Save Master Exporter Profile
          </button>
        </div>
      </form>
    </div>
  );
};
