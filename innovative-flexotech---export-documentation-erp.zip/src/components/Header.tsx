import React from 'react';
import { Plus, Download, FileText, Settings, Archive, Sparkles } from 'lucide-react';
import { ShipmentDocument } from '../types/trade';

interface HeaderProps {
  activeView: 'active-doc' | 'archive' | 'company-profile';
  setActiveView: (view: 'active-doc' | 'archive' | 'company-profile') => void;
  shipments: ShipmentDocument[];
  activeShipmentId: string;
  onSelectShipment: (id: string) => void;
  onOpenNewDocumentModal: () => void;
  onOpenAiAudit: () => void;
  onOpenPoExtractor: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeView,
  setActiveView,
  shipments,
  activeShipmentId,
  onSelectShipment,
  onOpenNewDocumentModal,
  onOpenAiAudit,
  onOpenPoExtractor,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs no-print">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-8">
          {/* Zone 1: Single text element wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => setActiveView('active-doc')}
              className="text-left group flex items-center gap-2.5 cursor-pointer"
            >
              <div className="w-8 h-8 rounded-sm bg-[#c81e1e] text-white flex items-center justify-center font-serif font-black text-xl italic shadow-xs">
                i
              </div>
              <div>
                <span className="text-base font-extrabold tracking-tight text-slate-900 whitespace-nowrap block">
                  Innovative Flexotech
                </span>
                <span className="text-[10px] text-slate-500 font-medium tracking-wide uppercase block -mt-0.5">
                  Export ERP & Customs Hub
                </span>
              </div>
            </button>
          </div>

          {/* Zone 2: 4 Navigation Links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            <button
              onClick={() => setActiveView('active-doc')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 py-1 ${
                activeView === 'active-doc'
                  ? 'text-slate-900 border-b-2 border-slate-900 font-semibold'
                  : ''
              }`}
            >
              <FileText className="w-4 h-4" />
              Active Document
            </button>

            <button
              onClick={() => setActiveView('archive')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 py-1 ${
                activeView === 'archive'
                  ? 'text-slate-900 border-b-2 border-slate-900 font-semibold'
                  : ''
              }`}
            >
              <Archive className="w-4 h-4" />
              Shipments Archive
              <span className="text-xs text-slate-400">({shipments.length})</span>
            </button>

            <button
              onClick={() => setActiveView('company-profile')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 py-1 ${
                activeView === 'company-profile'
                  ? 'text-slate-900 border-b-2 border-slate-900 font-semibold'
                  : ''
              }`}
            >
              <Settings className="w-4 h-4" />
              Master Profile
            </button>

            <button
              onClick={onOpenAiAudit}
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 text-slate-700"
            >
              <Sparkles className="w-4 h-4 text-amber-600" />
              Compliance Audit
            </button>
          </nav>

          {/* Zone 3: Active document switcher & Primary New Shipment Action */}
          <div className="flex items-center gap-3 shrink-0">
            {/* Quick Document Switcher */}
            {shipments.length > 0 && (
              <div className="hidden lg:flex items-center gap-1.5">
                <span className="text-xs text-slate-500 whitespace-nowrap">Invoice:</span>
                <select
                  value={activeShipmentId}
                  onChange={(e) => {
                    onSelectShipment(e.target.value);
                    if (activeView !== 'active-doc') setActiveView('active-doc');
                  }}
                  className="text-xs font-medium text-slate-800 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-md py-1.5 px-2.5 focus:outline-hidden focus:ring-1 focus:ring-slate-400 cursor-pointer max-w-[170px] truncate"
                >
                  {shipments.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.documentNumber} ({s.buyer.country})
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* AI PO Extractor Quick Button */}
            <button
              onClick={onOpenPoExtractor}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors whitespace-nowrap"
              title="Paste customer PO text to auto-populate line items"
            >
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              Import PO Text
            </button>

            {/* Primary Action Button: New Shipment */}
            <button
              onClick={onOpenNewDocumentModal}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors shadow-xs whitespace-nowrap"
            >
              <Plus className="w-4 h-4" />
              New Shipment
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
