import React, { useState, useRef } from 'react';
import {
  Printer,
  FileSpreadsheet,
  FileDown,
  Sparkles,
  Sliders,
  CheckCircle,
  FileText,
  Boxes,
  Edit3,
  SlidersHorizontal,
  Image as ImageIcon,
  Check,
  FileCheck,
  Award,
  ShieldCheck,
} from 'lucide-react';
import { ShipmentDocument, ShipmentStatus, DocumentTab, ExportDocumentMode } from '../types/trade';
import { exportMultiTabTradeWorkbook } from '../utils/excelExport';
import { exportDocumentVectorPdf, PdfExportDocType } from '../utils/pdfExport';

interface DocumentToolbarProps {
  shipment: ShipmentDocument;
  activeDocTab: DocumentTab;
  setActiveDocTab: (tab: DocumentTab) => void;
  documentMode?: ExportDocumentMode;
  setDocumentMode?: (mode: ExportDocumentMode) => void;
  printMode: 'digital' | 'preprinted';
  setPrintMode: (mode: 'digital' | 'preprinted') => void;
  stationeryTopMarginMm: number;
  setStationeryTopMarginMm: (mm: number) => void;
  stationeryBottomMarginMm: number;
  setStationeryBottomMarginMm: (mm: number) => void;
  onUpdateStatus: (status: ShipmentStatus) => void;
  onOpenAiAudit: () => void;
  onUploadHeaderImage?: (dataUrl: string) => void;
  onUploadFooterImage?: (dataUrl: string) => void;
  onResetHeaderImage?: () => void;
}

export const DocumentToolbar: React.FC<DocumentToolbarProps> = ({
  shipment,
  activeDocTab,
  setActiveDocTab,
  documentMode,
  setDocumentMode,
  printMode,
  setPrintMode,
  stationeryTopMarginMm,
  setStationeryTopMarginMm,
  stationeryBottomMarginMm,
  setStationeryBottomMarginMm,
  onUpdateStatus,
  onOpenAiAudit,
  onUploadHeaderImage,
  onUploadFooterImage,
  onResetHeaderImage,
}) => {
  const [showPdfMenu, setShowPdfMenu] = useState(false);
  const [showMarginSettings, setShowMarginSettings] = useState(false);
  const [showImageMenu, setShowImageMenu] = useState(false);

  const headerFileInputRef = useRef<HTMLInputElement>(null);
  const footerFileInputRef = useRef<HTMLInputElement>(null);

  const handleHeaderFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && onUploadHeaderImage) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onUploadHeaderImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFooterFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && onUploadFooterImage) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onUploadFooterImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const [internalMode, setInternalMode] = useState<ExportDocumentMode>('all');
  const currentMode = documentMode ?? internalMode;

  const updateMode = (m: ExportDocumentMode) => {
    if (setDocumentMode) {
      setDocumentMode(m);
    } else {
      setInternalMode(m);
    }

    if (m === 'normal') {
      if (activeDocTab === 'lc_export_invoice' || activeDocTab === 'commercial') setActiveDocTab('export_invoice');
      else if (activeDocTab === 'lc_packing_list' || activeDocTab === 'packing') setActiveDocTab('packing_list');
      else if (activeDocTab === 'lc_tax_invoice' || activeDocTab === 'tax') setActiveDocTab('tax_invoice');
    } else if (m === 'lc') {
      if (activeDocTab === 'export_invoice' || activeDocTab === 'commercial') setActiveDocTab('lc_export_invoice');
      else if (activeDocTab === 'packing_list' || activeDocTab === 'packing') setActiveDocTab('lc_packing_list');
      else if (activeDocTab === 'tax_invoice' || activeDocTab === 'tax') setActiveDocTab('lc_tax_invoice');
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleExcelExport = () => {
    exportMultiTabTradeWorkbook(shipment);
  };

  const handlePdfExport = (type: PdfExportDocType) => {
    exportDocumentVectorPdf(shipment, type, printMode);
    setShowPdfMenu(false);
  };

  const statusColors: Record<ShipmentStatus, string> = {
    Draft: 'text-slate-600 bg-slate-100 border-slate-200',
    Generated: 'text-blue-700 bg-blue-50 border-blue-200',
    'Customs Cleared': 'text-amber-700 bg-amber-50 border-amber-200',
    Dispatched: 'text-emerald-700 bg-emerald-50 border-emerald-200',
  };

  return (
    <div className="bg-white border-b border-slate-200 sticky top-16 z-30 shadow-xs no-print">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          {/* Left: Tab Switcher & Status */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Mode Selector Option: Normal vs LC vs All 6 */}
            <div className="inline-flex p-0.5 bg-slate-200/90 rounded-lg border border-slate-300 text-xs shadow-2xs">
              <button
                onClick={() => updateMode('all')}
                className={`px-2.5 py-1 rounded-md font-bold transition-all cursor-pointer ${
                  currentMode === 'all'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="Display all 6 documents (Export Invoice, Packing List, Tax Invoice, LC Export Invoice, LC Packing List, LC Tax Invoice)"
              >
                All 6 Docs
              </button>
              <button
                onClick={() => updateMode('normal')}
                className={`px-2.5 py-1 rounded-md font-bold transition-all cursor-pointer flex items-center gap-1 ${
                  currentMode === 'normal'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="Show 3 Normal Export Documents (Export Invoice, Packing List, Tax Invoice)"
              >
                Normal (3)
              </button>
              <button
                onClick={() => updateMode('lc')}
                className={`px-2.5 py-1 rounded-md font-bold transition-all cursor-pointer flex items-center gap-1 ${
                  currentMode === 'lc'
                    ? 'bg-red-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="Show 3 LC Export Documents (LC Export Invoice, LC Packing List, LC Tax Invoice)"
              >
                LC Export (3)
              </button>
            </div>

            {/* Document Selector Tabs */}
            <div className="inline-flex items-center p-1 bg-slate-100 rounded-lg border border-slate-200 overflow-x-auto max-w-full gap-1">
              {/* Normal Documents */}
              {(currentMode === 'all' || currentMode === 'normal') && (
                <>
                  {currentMode === 'all' && (
                    <span className="text-[10px] font-bold uppercase tracking-wider text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-200 ml-1">
                      Normal:
                    </span>
                  )}
                  <button
                    onClick={() => setActiveDocTab('export_invoice')}
                    className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md transition-all whitespace-nowrap cursor-pointer ${
                      activeDocTab === 'export_invoice' || (activeDocTab === 'commercial' && !shipment.lcDetails?.hasLc)
                        ? 'bg-white text-blue-900 shadow-xs font-semibold ring-1 ring-blue-300'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                    title="Export Invoice (Normal / Non-LC format)"
                  >
                    <FileText className="w-3.5 h-3.5 text-blue-600" />
                    Export Invoice
                  </button>

                  <button
                    onClick={() => setActiveDocTab('packing_list')}
                    className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md transition-all whitespace-nowrap cursor-pointer ${
                      activeDocTab === 'packing_list' || (activeDocTab === 'packing' && !shipment.lcDetails?.hasLc)
                        ? 'bg-white text-emerald-900 shadow-xs font-semibold ring-1 ring-emerald-300'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                    title="Packing List (Normal format)"
                  >
                    <Boxes className="w-3.5 h-3.5 text-emerald-600" />
                    Packing List
                  </button>

                  <button
                    onClick={() => setActiveDocTab('tax_invoice')}
                    className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md transition-all whitespace-nowrap cursor-pointer ${
                      activeDocTab === 'tax_invoice' || (activeDocTab === 'tax' && !shipment.lcDetails?.hasLc)
                        ? 'bg-white text-indigo-900 shadow-xs font-semibold ring-1 ring-indigo-300'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                    title="Tax Invoice (Normal GST under LUT format)"
                  >
                    <CheckCircle className="w-3.5 h-3.5 text-indigo-600" />
                    Tax Invoice
                  </button>
                </>
              )}

              {currentMode === 'all' && (
                <div className="h-5 w-px bg-slate-300 mx-1" />
              )}

              {/* LC Documents */}
              {(currentMode === 'all' || currentMode === 'lc') && (
                <>
                  {currentMode === 'all' && (
                    <span className="text-[10px] font-bold uppercase tracking-wider text-red-700 bg-red-50 px-1.5 py-0.5 rounded border border-red-200 ml-1">
                      LC:
                    </span>
                  )}
                  <button
                    onClick={() => setActiveDocTab('lc_export_invoice')}
                    className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md transition-all whitespace-nowrap cursor-pointer ${
                      activeDocTab === 'lc_export_invoice' || (activeDocTab === 'commercial' && shipment.lcDetails?.hasLc)
                        ? 'bg-white text-red-900 shadow-xs font-semibold ring-1 ring-red-300'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                    title="LC Export Invoice (Under Letter of Credit format)"
                  >
                    <FileText className="w-3.5 h-3.5 text-red-600" />
                    LC Export Invoice
                  </button>

                  <button
                    onClick={() => setActiveDocTab('lc_packing_list')}
                    className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md transition-all whitespace-nowrap cursor-pointer ${
                      activeDocTab === 'lc_packing_list' || (activeDocTab === 'packing' && shipment.lcDetails?.hasLc)
                        ? 'bg-white text-red-900 shadow-xs font-semibold ring-1 ring-red-300'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                    title="LC Packing List (Under Letter of Credit format)"
                  >
                    <Boxes className="w-3.5 h-3.5 text-red-600" />
                    LC Packing List
                  </button>

                  <button
                    onClick={() => setActiveDocTab('lc_tax_invoice')}
                    className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md transition-all whitespace-nowrap cursor-pointer ${
                      activeDocTab === 'lc_tax_invoice' || (activeDocTab === 'tax' && shipment.lcDetails?.hasLc)
                        ? 'bg-white text-red-900 shadow-xs font-semibold ring-1 ring-red-300'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                    title="LC Tax Invoice (Under Letter of Credit format)"
                  >
                    <CheckCircle className="w-3.5 h-3.5 text-red-600" />
                    LC Tax Invoice
                  </button>
                </>
              )}

              <div className="h-5 w-px bg-slate-300 mx-1" />

              <button
                onClick={() => setActiveDocTab('editor')}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md transition-all whitespace-nowrap cursor-pointer ${
                  activeDocTab === 'editor'
                    ? 'bg-white text-slate-900 shadow-xs font-semibold ring-1 ring-slate-300'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Edit3 className="w-3.5 h-3.5 text-slate-700" />
                Edit Shipment
              </button>
            </div>

            {/* Shipment Status Pill Selector */}
            <div className="flex items-center gap-1.5 ml-1">
              <span className="text-[11px] text-slate-400 font-medium hidden sm:inline">Status:</span>
              <select
                value={shipment.status}
                onChange={(e) => onUpdateStatus(e.target.value as ShipmentStatus)}
                className={`text-[11px] font-semibold border rounded-md py-1 px-2 cursor-pointer focus:outline-hidden ${statusColors[shipment.status]}`}
              >
                <option value="Draft">Draft</option>
                <option value="Generated">Generated</option>
                <option value="Customs Cleared">Customs Cleared</option>
                <option value="Dispatched">Dispatched</option>
              </select>
            </div>
          </div>

          {/* Right: Dual Print Mode & Export Actions */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Dual Print Mode Toggle */}
            <div className="inline-flex items-center p-0.5 bg-slate-100 rounded-lg border border-slate-200 text-xs">
              <button
                onClick={() => setPrintMode('digital')}
                className={`px-2.5 py-1 rounded-md font-medium transition-colors cursor-pointer ${
                  printMode === 'digital'
                    ? 'bg-white text-slate-900 shadow-xs font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="Full document with company letterhead, ISO badges, bank details & stamps"
              >
                Digital Mode
              </button>
              <button
                onClick={() => setPrintMode('preprinted')}
                className={`px-2.5 py-1 rounded-md font-medium transition-colors cursor-pointer flex items-center gap-1 ${
                  printMode === 'preprinted'
                    ? 'bg-white text-slate-900 shadow-xs font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="Removes letterhead headers & footers for printing directly onto corporate printed stationery paper"
              >
                Pre-printed Letterhead
              </button>
            </div>

            {/* Quick Header & Footer Image Uploader Button */}
            {printMode === 'digital' && (
              <div className="relative">
                <input
                  type="file"
                  ref={headerFileInputRef}
                  onChange={handleHeaderFile}
                  accept="image/*"
                  className="hidden"
                />
                <input
                  type="file"
                  ref={footerFileInputRef}
                  onChange={handleFooterFile}
                  accept="image/*"
                  className="hidden"
                />

                <button
                  onClick={() => setShowImageMenu(!showImageMenu)}
                  className={`inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-lg border transition-colors cursor-pointer ${
                    shipment.exporter.customHeaderImage
                      ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                      : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                  }`}
                  title="Upload WhatsApp Image 2026-10-10 at 2.40.57 PM.jpeg directly as document header"
                >
                  <ImageIcon className="w-3.5 h-3.5 text-[#c81e1e]" />
                  <span>
                    {shipment.exporter.customHeaderImage ? 'Custom Header Active' : 'Header Image'}
                  </span>
                </button>

                {showImageMenu && (
                  <div className="absolute right-0 mt-1 w-64 bg-white rounded-lg shadow-lg border border-slate-200 p-3 z-50 text-xs space-y-2">
                    <div className="font-bold text-slate-900 flex justify-between items-center pb-1 border-b border-slate-100">
                      <span>Document Header & Footer</span>
                      <button
                        onClick={() => setShowImageMenu(false)}
                        className="text-slate-400 hover:text-slate-600"
                      >
                        ✕
                      </button>
                    </div>

                    <button
                      onClick={() => {
                        setShowImageMenu(false);
                        headerFileInputRef.current?.click();
                      }}
                      className="w-full text-left p-2 rounded-md bg-slate-50 hover:bg-slate-100 border border-slate-200 flex items-center justify-between font-medium text-slate-800 cursor-pointer"
                    >
                      <span className="flex items-center gap-1.5">
                        <ImageIcon className="w-3.5 h-3.5 text-[#c81e1e]" />
                        Upload Header Image
                      </span>
                      {shipment.exporter.customHeaderImage && (
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                      )}
                    </button>

                    <button
                      onClick={() => {
                        setShowImageMenu(false);
                        footerFileInputRef.current?.click();
                      }}
                      className="w-full text-left p-2 rounded-md bg-slate-50 hover:bg-slate-100 border border-slate-200 flex items-center justify-between font-medium text-slate-800 cursor-pointer"
                    >
                      <span className="flex items-center gap-1.5">
                        <ImageIcon className="w-3.5 h-3.5 text-slate-600" />
                        Upload Footer Image
                      </span>
                      {shipment.exporter.customFooterImage && (
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                      )}
                    </button>

                    {(shipment.exporter.customHeaderImage || shipment.exporter.customFooterImage) && (
                      <button
                        onClick={() => {
                          if (onResetHeaderImage) onResetHeaderImage();
                          setShowImageMenu(false);
                        }}
                        className="w-full text-center py-1 text-[11px] text-rose-600 hover:text-rose-800 font-semibold cursor-pointer"
                      >
                        Reset to Vector Header / Footer
                      </button>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Stationery Margin Calibration button (shows when preprinted mode is active) */}
            {printMode === 'preprinted' && (
              <div className="relative">
                <button
                  onClick={() => setShowMarginSettings(!showMarginSettings)}
                  className="px-2 py-1 text-xs font-medium text-slate-700 bg-amber-50 border border-amber-300 rounded-md hover:bg-amber-100 flex items-center gap-1"
                  title="Calibrate top/bottom margin offset in millimeters"
                >
                  <SlidersHorizontal className="w-3.5 h-3.5 text-amber-700" />
                  <span>{stationeryTopMarginMm}mm Top</span>
                </button>

                {showMarginSettings && (
                  <div className="absolute right-0 mt-1 w-64 bg-white rounded-lg shadow-lg border border-slate-200 p-4 z-50">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-bold text-slate-900">Stationery Margin Offsets</span>
                      <button
                        onClick={() => setShowMarginSettings(false)}
                        className="text-slate-400 hover:text-slate-600 text-xs"
                      >
                        ✕
                      </button>
                    </div>
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between text-xs text-slate-600 mb-1">
                          <span>Top Letterhead Offset:</span>
                          <span className="font-semibold text-slate-900 font-mono-tabular">{stationeryTopMarginMm} mm</span>
                        </div>
                        <input
                          type="range"
                          min="30"
                          max="80"
                          value={stationeryTopMarginMm}
                          onChange={(e) => setStationeryTopMarginMm(Number(e.target.value))}
                          className="w-full accent-slate-900"
                        />
                        <span className="text-[10px] text-slate-400 block">Leaves blank space for pre-printed corporate header</span>
                      </div>

                      <div>
                        <div className="flex justify-between text-xs text-slate-600 mb-1">
                          <span>Bottom Footer Offset:</span>
                          <span className="font-semibold text-slate-900 font-mono-tabular">{stationeryBottomMarginMm} mm</span>
                        </div>
                        <input
                          type="range"
                          min="15"
                          max="50"
                          value={stationeryBottomMarginMm}
                          onChange={(e) => setStationeryBottomMarginMm(Number(e.target.value))}
                          className="w-full accent-slate-900"
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* AI Audit Action */}
            <button
              onClick={onOpenAiAudit}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-amber-800 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
              title="Run AI Trade Compliance & Math Audit"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              Audit
            </button>

            {/* Excel Exporter (.xlsx) */}
            <button
              onClick={handleExcelExport}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 rounded-lg transition-colors whitespace-nowrap cursor-pointer shadow-2xs"
              title="Download 3-Sheet formatted Excel workbook (CI, Tax Inv, PL)"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700" />
              Excel (.xlsx)
            </button>

            {/* Vector PDF Export Dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowPdfMenu(!showPdfMenu)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-800 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg transition-colors whitespace-nowrap cursor-pointer shadow-2xs"
              >
                <FileDown className="w-3.5 h-3.5 text-slate-700" />
                Vector PDF
              </button>

              {showPdfMenu && (
                <div className="absolute right-0 mt-1 w-64 bg-white rounded-lg shadow-xl border border-slate-200 py-1.5 z-50 text-xs">
                  <div className="px-3 py-1 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    Download Vector PDF
                  </div>
                  
                  {/* Complete 6-Doc Binder */}
                  <button
                    onClick={() => handlePdfExport('all_6')}
                    className="w-full text-left px-3 py-2 text-indigo-700 hover:bg-indigo-50 flex items-center justify-between font-bold border-b border-slate-100"
                  >
                    <span>Complete 6-in-1 Export Binder</span>
                    <span className="text-[10px] bg-indigo-100 text-indigo-700 px-1.5 py-0.5 rounded font-bold">6 Pages</span>
                  </button>

                  {/* Normal Documents */}
                  <div className="px-3 pt-2 pb-1 text-[10px] font-bold text-blue-700 uppercase tracking-wider bg-blue-50/60 flex items-center justify-between">
                    <span>Normal Export (3 Docs)</span>
                    <button
                      onClick={() => handlePdfExport('normal_pack')}
                      className="text-[10px] text-blue-600 hover:underline font-bold"
                    >
                      3-in-1 Pack
                    </button>
                  </div>
                  <button
                    onClick={() => handlePdfExport('export_invoice')}
                    className="w-full text-left px-3 py-1.5 text-slate-700 hover:bg-slate-100 flex items-center justify-between"
                  >
                    <span>Export Invoice</span>
                    <span className="text-[10px] text-slate-400">Normal</span>
                  </button>
                  <button
                    onClick={() => handlePdfExport('packing_list')}
                    className="w-full text-left px-3 py-1.5 text-slate-700 hover:bg-slate-100 flex items-center justify-between"
                  >
                    <span>Packing List</span>
                    <span className="text-[10px] text-slate-400">Normal</span>
                  </button>
                  <button
                    onClick={() => handlePdfExport('tax_invoice')}
                    className="w-full text-left px-3 py-1.5 text-slate-700 hover:bg-slate-100 flex items-center justify-between"
                  >
                    <span>Tax Invoice</span>
                    <span className="text-[10px] text-slate-400">Normal</span>
                  </button>

                  {/* LC Documents */}
                  <div className="px-3 pt-2 pb-1 text-[10px] font-bold text-red-700 uppercase tracking-wider bg-red-50/60 border-t border-slate-100 flex items-center justify-between">
                    <span>LC Export (3 Docs)</span>
                    <button
                      onClick={() => handlePdfExport('lc_pack')}
                      className="text-[10px] text-red-600 hover:underline font-bold"
                    >
                      3-in-1 Pack
                    </button>
                  </div>
                  <button
                    onClick={() => handlePdfExport('lc_export_invoice')}
                    className="w-full text-left px-3 py-1.5 text-slate-700 hover:bg-slate-100 flex items-center justify-between"
                  >
                    <span>LC Export Invoice</span>
                    <span className="text-[10px] text-red-500 font-medium">LC</span>
                  </button>
                  <button
                    onClick={() => handlePdfExport('lc_packing_list')}
                    className="w-full text-left px-3 py-1.5 text-slate-700 hover:bg-slate-100 flex items-center justify-between"
                  >
                    <span>LC Packing List</span>
                    <span className="text-[10px] text-red-500 font-medium">LC</span>
                  </button>
                  <button
                    onClick={() => handlePdfExport('lc_tax_invoice')}
                    className="w-full text-left px-3 py-1.5 text-slate-700 hover:bg-slate-100 flex items-center justify-between"
                  >
                    <span>LC Tax Invoice</span>
                    <span className="text-[10px] text-red-500 font-medium">LC</span>
                  </button>
                </div>
              )}
            </div>

            {/* Native 1-Click Print */}
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap cursor-pointer shadow-xs"
              title="Print active document view (or save via browser PDF printer)"
            >
              <Printer className="w-3.5 h-3.5" />
              Print
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
