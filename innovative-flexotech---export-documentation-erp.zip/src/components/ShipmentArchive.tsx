import React, { useState, useMemo } from 'react';
import {
  ShipmentDocument,
  ShipmentStatus,
} from '../types/trade';
import { calculateShipmentSummary } from '../utils/calculations';
import { exportMultiTabTradeWorkbook } from '../utils/excelExport';
import {
  Search,
  FileSpreadsheet,
  Copy,
  Trash2,
  ExternalLink,
  Plus,
  SlidersHorizontal,
  ArrowUpDown,
} from 'lucide-react';

interface ShipmentArchiveProps {
  shipments: ShipmentDocument[];
  activeShipmentId: string;
  onSelectShipment: (id: string) => void;
  onDuplicateShipment: (id: string) => void;
  onDeleteShipment: (id: string) => void;
  onOpenNewDocumentModal: () => void;
}

export const ShipmentArchive: React.FC<ShipmentArchiveProps> = ({
  shipments,
  activeShipmentId,
  onSelectShipment,
  onDuplicateShipment,
  onDeleteShipment,
  onOpenNewDocumentModal,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  // Filtered shipments
  const filteredShipments = useMemo(() => {
    return shipments.filter((s) => {
      const matchesSearch =
        s.documentNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.buyer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.buyer.country.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.carriage.portOfDischarge.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.customerPoNumber.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesStatus = statusFilter === 'ALL' || s.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [shipments, searchTerm, statusFilter]);

  // Aggregate stats
  const stats = useMemo(() => {
    const totalCount = shipments.length;
    let totalUsd = 0;
    let totalInr = 0;
    let customsClearedCount = 0;

    shipments.forEach((s) => {
      const summary = calculateShipmentSummary(s);
      totalUsd += summary.grandTotalFobOrCif;
      totalInr += summary.grandTotalInr;
      if (s.status === 'Customs Cleared' || s.status === 'Dispatched') {
        customsClearedCount++;
      }
    });

    return {
      totalCount,
      totalUsd,
      totalInr,
      customsClearedCount,
    };
  }, [shipments]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Shipment Master Archive
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Complete persistent repository of all Indian customs & international trade invoices
          </p>
        </div>

        <button
          onClick={onOpenNewDocumentModal}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors shadow-xs cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          Create New Shipment
        </button>
      </div>

      {/* Aggregate KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-xs font-medium text-slate-500">Total Shipments In Archive</span>
          <div className="text-2xl font-bold text-slate-900 font-mono-tabular mt-1">
            {stats.totalCount}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">Active documentation packs</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-xs font-medium text-slate-500">Total Export Turnover (FOB/CIF)</span>
          <div className="text-2xl font-bold text-slate-900 font-mono-tabular mt-1">
            $ {stats.totalUsd.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">Cumulative foreign exchange</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-xs font-medium text-slate-500">Realizable Export Value (INR)</span>
          <div className="text-2xl font-bold text-slate-900 font-mono-tabular mt-1">
            ₹ {stats.totalInr.toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">At CBIC conversion rates</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-xs font-medium text-slate-500">Customs Cleared / Dispatched</span>
          <div className="text-2xl font-bold text-emerald-800 font-mono-tabular mt-1">
            {stats.customsClearedCount} / {stats.totalCount}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">Cleared with Shipping Bills</span>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by Invoice #, Buyer Name, Destination Country, PO #, or Port..."
              className="w-full text-xs pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-slate-900 focus:bg-white"
            />
          </div>

          {/* Status Filter Tabs (interactive filter control) */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg shrink-0">
            {['ALL', 'Draft', 'Generated', 'Customs Cleared', 'Dispatched'].map((status) => (
              <button
                key={status}
                onClick={() => setStatusFilter(status)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                  statusFilter === status
                    ? 'bg-white text-slate-900 shadow-xs font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {status}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Archive Data Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold text-slate-600 uppercase tracking-wider">
                <th className="py-3 px-4">Invoice # & Date</th>
                <th className="py-3 px-4">Buyer & Country</th>
                <th className="py-3 px-4">Incoterm & Port</th>
                <th className="py-3 px-4 text-right">Invoice Value</th>
                <th className="py-3 px-4 text-right">INR Value</th>
                <th className="py-3 px-4">Status & Scheme</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono-tabular">
              {filteredShipments.length > 0 ? (
                filteredShipments.map((s) => {
                  const sSummary = calculateShipmentSummary(s);
                  const isActive = s.id === activeShipmentId;

                  return (
                    <tr
                      key={s.id}
                      className={`hover:bg-slate-50/80 transition-colors ${
                        isActive ? 'bg-slate-50/60 font-medium' : ''
                      }`}
                    >
                      {/* Invoice No */}
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-900">{s.documentNumber}</div>
                        <div className="text-[11px] text-slate-500 font-sans">
                          {s.invoiceDate} · PO: {s.customerPoNumber}
                        </div>
                      </td>

                      {/* Buyer */}
                      <td className="py-3.5 px-4 font-sans">
                        <div className="font-semibold text-slate-900 truncate max-w-[200px]">
                          {s.buyer.name}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {s.buyer.country}
                        </div>
                      </td>

                      {/* Incoterm & Port */}
                      <td className="py-3.5 px-4 font-sans">
                        <div className="font-medium text-slate-900">
                          {s.incoterm} - {s.carriage.portOfDischarge.slice(0, 22)}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          POL: {s.carriage.portOfLoading.slice(0, 18)}
                        </div>
                      </td>

                      {/* Invoice Value */}
                      <td className="py-3.5 px-4 text-right">
                        <div className="font-bold text-slate-900">
                          {s.currency} {sSummary.grandTotalFobOrCif.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </div>
                        <div className="text-[11px] text-slate-500 font-sans">
                          {s.lineItems.length} items · {sSummary.totalNetWeightKg} kg
                        </div>
                      </td>

                      {/* INR Value */}
                      <td className="py-3.5 px-4 text-right">
                        <div className="font-semibold text-slate-800">
                          ₹ {sSummary.grandTotalInr.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                        </div>
                        <div className="text-[11px] text-slate-400 font-sans">
                          @ ₹{sSummary.exchangeRateInr}
                        </div>
                      </td>

                      {/* Status */}
                      <td className="py-3.5 px-4 font-sans">
                        <div className="text-slate-800 font-semibold text-xs">
                          {s.status}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {s.gstAndCustoms.schemeCode}
                        </div>
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-right font-sans">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => onSelectShipment(s.id)}
                            className="p-1.5 text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-md transition-colors"
                            title="Open & Edit Shipment"
                          >
                            <ExternalLink className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => exportMultiTabTradeWorkbook(s)}
                            className="p-1.5 text-emerald-700 hover:text-emerald-900 hover:bg-emerald-50 rounded-md transition-colors"
                            title="Export Multi-Tab Excel (.xlsx)"
                          >
                            <FileSpreadsheet className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => onDuplicateShipment(s.id)}
                            className="p-1.5 text-blue-700 hover:text-blue-900 hover:bg-blue-50 rounded-md transition-colors"
                            title="Duplicate / Re-order"
                          >
                            <Copy className="w-4 h-4" />
                          </button>

                          {shipments.length > 1 && (
                            <button
                              onClick={() => {
                                if (window.confirm(`Delete shipment ${s.documentNumber}?`)) {
                                  onDeleteShipment(s.id);
                                }
                              }}
                              className="p-1.5 text-rose-600 hover:text-rose-800 hover:bg-rose-50 rounded-md transition-colors"
                              title="Delete Shipment"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-500 font-sans">
                    <div className="max-w-sm mx-auto space-y-2">
                      <p className="font-semibold text-slate-700">No matching shipments found</p>
                      <p className="text-xs text-slate-400">
                        Try modifying your search filter or create a new export shipment pack.
                      </p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
