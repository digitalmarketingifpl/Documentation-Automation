import React from 'react';
import { ShipmentDocument } from '../types/trade';
import { calculateShipmentSummary } from '../utils/calculations';
import { convertToInternationalWords } from '../utils/numberToWords';
import { InnovativeLetterheadHeader, InnovativeLetterheadFooter } from './InnovativeBranding';

interface CommercialInvoiceViewProps {
  shipment: ShipmentDocument;
  printMode: 'digital' | 'preprinted';
  stationeryTopMarginMm?: number;
  stationeryBottomMarginMm?: number;
  isLcFormat?: boolean;
}

export const CommercialInvoiceView: React.FC<CommercialInvoiceViewProps> = ({
  shipment,
  printMode,
  stationeryTopMarginMm = 55,
  stationeryBottomMarginMm = 25,
  isLcFormat,
}) => {
  const summary = calculateShipmentSummary(shipment);
  const isPreprinted = printMode === 'preprinted';
  const hasLc = isLcFormat !== undefined ? isLcFormat : (shipment.lcDetails?.hasLc ?? true);

  return (
    <div
      className={`a4-document-sheet p-6 text-black bg-white transition-all ${
        isPreprinted ? 'stationery-mode' : ''
      }`}
      style={{
        paddingTop: isPreprinted ? `${stationeryTopMarginMm}mm` : '20px',
        paddingBottom: isPreprinted ? `${stationeryBottomMarginMm}mm` : '20px',
        fontFamily: "'Times New Roman', Times, serif, 'Plus Jakarta Sans', sans-serif",
      }}
    >
      {/* Pre-printed mode visual notice */}
      {isPreprinted && (
        <div className="no-print mb-3 p-2 bg-amber-50 border border-amber-300 rounded text-[11px] text-amber-800 font-sans">
          <strong>Pre-printed Stationery Mode Active:</strong> Top header logo and bottom plant footer are omitted for direct printing onto physical corporate stationery.
        </div>
      )}

      {/* 1. Top Letterhead Header */}
      {!isPreprinted && (
        <InnovativeLetterheadHeader
          customHeaderImage={shipment.exporter.customHeaderImage}
        />
      )}

      {/* 2. Main Box Grid */}
      <div className="border border-black text-[11px] leading-tight">
        {/* Title Bar */}
        <div className="border-b border-black py-1 text-center font-bold text-xs uppercase tracking-wider bg-white">
          {hasLc ? 'LC EXPORT INVOICE' : 'EXPORT INVOICE'}
        </div>

        {/* Row 1: Exporter | Invoice No & Date | Exporter's Ref */}
        <div className="grid grid-cols-12 border-b border-black divide-x divide-black">
          {/* Col 1: Manufacturer/Producer/Exporter */}
          <div className="col-span-5 p-1.5 space-y-0.5">
            <div className="font-bold text-[10px]">Manufacturer/Producer/Exporter</div>
            <div><strong>GSTIN :</strong> {shipment.exporter.gstin || '24AABCI7261H1ZO'}</div>
            <div className="font-bold">{shipment.exporter.tradingName || 'Innovative Flexotech Pvt Ltd.'}</div>
            <div>FF/4,Rameshwar Residency,</div>
            <div>BS Kalash-3,Ghuma Village,</div>
            <div>Ahmedabad,Gujarat, 380058</div>
            <div>Mo. {shipment.exporter.phone || '98240 96180'}</div>
          </div>

          {/* Col 2: Invoice No. & Date */}
          <div className="col-span-4 p-1.5 space-y-0.5">
            <div className="font-bold text-[10px]">Invoice No. & Date</div>
            <div><strong>Invoice No.</strong>{shipment.documentNumber}</div>
            <div><strong>Date</strong> {shipment.invoiceDate}</div>
            {hasLc && (
              <div className="pt-1 mt-1 border-t border-black/40 space-y-0.5 text-[10px]">
                <div><strong>Issuing Date:</strong> {shipment.lcDetails.issuingDate}</div>
                <div><strong>LC NO.</strong>{shipment.lcDetails.documentaryCreditNumber}</div>
                <div><strong>LC Advising Ref. NO.</strong>{shipment.lcDetails.advisingBankRef}</div>
              </div>
            )}
          </div>

          {/* Col 3: Exporter's Ref */}
          <div className="col-span-3 p-1.5 space-y-0.5">
            <div className="font-bold text-[10px]">Exporter's Ref.</div>
            <div className="flex justify-between">
              <span>IEC No.</span>
              <span className="font-bold font-mono">{shipment.exporter.iecCode || '807016772'}</span>
            </div>
            <div className="flex justify-between">
              <span>BIN No.</span>
              <span></span>
            </div>
          </div>
        </div>

        {/* Row 1B: Beneficiary / Proforma Reference (When LC / Proforma is active) */}
        {hasLc && (
          <div className="grid grid-cols-12 border-b border-black divide-x divide-black bg-slate-50/40">
            <div className="col-span-5 p-1.5 text-[10px]">
              <div className="font-bold">BENEFICIARY:</div>
              <div className="font-semibold">Innovative Flexotech (Pvt) Ltd.</div>
              <div>FF/4,Rameshwar Residency, B-S Kalash-3,Ghuma Village,</div>
              <div>Ahmedabad-380058,Gujarat, India</div>
              <div>Mo. 98240 96180 &nbsp;|&nbsp; Email: info@flexo.co.in</div>
            </div>
            <div className="col-span-7 p-1.5 text-[10px] space-y-0.5">
              <div className="flex justify-between">
                <span><strong>Proforma Invoice No:</strong> {shipment.customerPoNumber || '00323'}</span>
                <span><strong>Date :</strong>{shipment.customerPoDate || shipment.invoiceDate}</span>
              </div>
              <div><strong>Reference:</strong> -{shipment.lcDetails.advisingBankRef || '26ELF08102489095-ADV001'}</div>
              <div><strong>Terms:</strong> {shipment.paymentTerms || 'Terms - FOB-Any Sea Port in India (INCOTERM 2020)'}</div>
            </div>
          </div>
        )}

        {/* Row 2: Consignee & Buyer */}
        <div className="grid grid-cols-12 border-b border-black divide-x divide-black">
          {/* Consignee (or Applicant if LC) */}
          <div className="col-span-6 p-1.5">
            <div className="font-bold text-[10px]">{hasLc ? 'Applicant' : 'Consignee'}</div>
            {hasLc ? (
              <div className="space-y-0.5">
                <div className="font-bold">{shipment.buyer.name}</div>
                <div className="whitespace-pre-line">{shipment.buyer.address}</div>
              </div>
            ) : shipment.consignee.isSameAsBuyer ? (
              <div className="space-y-0.5">
                <div className="font-bold">{shipment.buyer.name}</div>
                <div className="whitespace-pre-line">{shipment.buyer.address}</div>
              </div>
            ) : (
              <div className="space-y-0.5">
                <div className="font-bold">{shipment.consignee.name}</div>
                <div className="whitespace-pre-line">{shipment.consignee.address}</div>
              </div>
            )}
          </div>

          {/* Buyer's Name & Address (or Consignee Bank if LC) */}
          <div className="col-span-6 p-1.5">
            <div className="font-bold text-[10px]">{hasLc ? 'Consignee' : "Buyer's Name & Address"}</div>
            {hasLc ? (
              <div className="space-y-0.5">
                <div className="font-bold">{shipment.consignee.name}</div>
                <div className="whitespace-pre-line">{shipment.consignee.address}</div>
              </div>
            ) : (
              <div className="space-y-0.5">
                <div className="font-bold">{shipment.buyer.name}</div>
                <div className="whitespace-pre-line">{shipment.buyer.address}</div>
              </div>
            )}
          </div>
        </div>

        {/* Row 3: Pre-Carriage by | Place of receipt | Country of Origin | Country of Final Destination */}
        <div className="grid grid-cols-12 border-b border-black divide-x divide-black text-[10px]">
          <div className="col-span-3 p-1">
            <div className="font-bold">Pre-Carriage by</div>
            <div>{shipment.carriage.preCarriageBy || '—'}</div>
          </div>
          <div className="col-span-3 p-1">
            <div className="font-bold">Place of receipt by Pre-carrier</div>
            <div>{shipment.carriage.placeOfReceipt || '—'}</div>
          </div>
          <div className="col-span-3 p-1">
            <div className="font-bold">Country of Origin of Goods</div>
            <div className="font-bold">India</div>
          </div>
          <div className="col-span-3 p-1">
            <div className="font-bold">Country of Final Destination</div>
            <div>{shipment.carriage.countryOfFinalDestination || shipment.buyer.country}</div>
          </div>
        </div>

        {/* Row 4: Vessel, Port of Loading, Port of Discharge, Final Destination & Terms (Unified Carriage Division) */}
        <div className="grid grid-cols-12 border-b border-black divide-x divide-black text-[10px]">
          <div className="col-span-8 divide-y divide-black">
            <div className="grid grid-cols-2 divide-x divide-black">
              <div className="p-1">
                <div className="font-bold">Vessel / Mode</div>
                <div>{shipment.carriage.vesselFlightNo || 'By Sea'}</div>
              </div>
              <div className="p-1">
                <div className="font-bold">Port of Loading</div>
                <div>{shipment.carriage.portOfLoading}</div>
              </div>
            </div>
            <div className="grid grid-cols-2 divide-x divide-black">
              <div className="p-1">
                <div className="font-bold">Port of Discharge</div>
                <div>{shipment.carriage.portOfDischarge}</div>
              </div>
              <div className="p-1">
                <div className="font-bold">Final Destination</div>
                <div>{shipment.carriage.finalDestination}</div>
              </div>
            </div>
          </div>
          <div className="col-span-4 p-1 flex flex-col justify-start">
            <div className="font-bold">Terms:</div>
            <div>-{shipment.incoterm}</div>
          </div>
        </div>

        {/* Row 5: Statutory LUT Declaration Bar */}
        <div className="border-b border-black p-1 text-[10px] text-center font-bold bg-white">
          Export under LUT with / without payment of IGST – Zero Rated Supply under Section 16 of IGST Act, 2017 ARN
          <div className="font-mono text-[11px] mt-0.5">
            {shipment.gstAndCustoms.lutNumber || 'AD240225025683B'}
          </div>
        </div>

        {/* Line Items Table */}
        <table className="w-full text-left border-collapse text-[10px]">
          <thead>
            <tr className="border-b border-black font-bold text-center divide-x divide-black">
              <th className="p-1 w-16">Marks & Nos./Container No.</th>
              <th className="p-1 w-16">No.& Kind of Pkgs.</th>
              {hasLc && <th className="p-1 w-20">Brand</th>}
              <th className="p-1 text-left">Description of Goods</th>
              <th className="p-1 w-20">H S Code</th>
              <th className="p-1 w-16 text-center">Quantity Nos.</th>
              <th className="p-1 w-16 text-right">Rate {shipment.currency}</th>
              <th className="p-1 w-20 text-right">Amount {shipment.currency}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-black/30">
            {/* Category header row if present */}
            {!hasLc && (
              <tr className="bg-slate-50/60 font-semibold italic">
                <td className="p-1 text-center border-r border-black">1</td>
                <td className="p-1 text-center border-r border-black">{summary.totalPackagesCount}</td>
                <td colSpan={6} className="p-1 text-center font-bold">
                  Platmeking Machine & Solevent Recovery Machine Accessories
                </td>
              </tr>
            )}

            {shipment.lineItems.map((item, idx) => (
              <tr key={item.id || idx} className="divide-x divide-black/40">
                <td className="p-1 text-center font-mono">{item.marksAndNos || '1'}</td>
                <td className="p-1 text-center">
                  {idx === 0 ? summary.totalPackagesCount : ''}
                </td>
                {hasLc && (
                  <td className="p-1 text-center text-[9px] leading-tight">
                    Innovative Flexotech Pvt Ltd.
                  </td>
                )}
                <td className="p-1 font-sans">{item.description}</td>
                <td className="p-1 text-center font-mono">{item.hsnCode}</td>
                <td className="p-1 text-center font-mono">{item.quantity}</td>
                <td className="p-1 text-right font-mono">{Number(item.unitPrice).toFixed(2)}</td>
                <td className="p-1 text-right font-mono font-bold">
                  {Number(item.quantity * item.unitPrice).toFixed(2)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Totals Section */}
        <div className="grid grid-cols-12 border-t border-black divide-x divide-black">
          {/* Left: Amount in Words */}
          <div className="col-span-8 p-1.5 flex flex-col justify-between text-[11px]">
            <div>
              <strong>Amount :</strong> {shipment.currency} {convertToInternationalWords(summary.grandTotalFobOrCif, shipment.currency).replace(/^US Dollars /, '').replace(/^Euros /, '')}(in words)
            </div>
            {hasLc && (
              <div className="text-[10px] text-slate-700 font-bold uppercase mt-1">
                Bifurcation
              </div>
            )}
          </div>

          {/* Right: Basic / Sub / Grand Total */}
          <div className="col-span-4 divide-y divide-black font-mono text-[11px]">
            <div className="flex justify-between p-1">
              <span className="font-sans">Basic Amount</span>
              <span className="font-bold">{summary.subtotalAmount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between p-1">
              <span className="font-sans">Sub Total</span>
              <span className="font-bold">{summary.subtotalAmount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between p-1 bg-slate-50 font-bold">
              <span className="font-sans">Grand Total</span>
              <span>{summary.grandTotalFobOrCif.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Declaration & Signatory Box */}
        <div className="grid grid-cols-12 border-t border-black divide-x divide-black text-[10px]">
          {/* Left: Statutory Declaration */}
          <div className="col-span-7 p-1.5 space-y-0.5 leading-tight">
            <div className="font-bold">Declaration</div>
            <div>END USE Code: - GNX200</div>
            <div>-GST REGISTRAION NO: 24AABCI7261H1ZO</div>
            <div>-PAN NUMBER: - AABCI7261H</div>
            <div>-IGST PAYMENT STATUS:{shipment.gstAndCustoms.supplyType === 'WITH_IGST' ? 'Yes' : ''}</div>
            <div>-TAXABLE VALUE: IGST AMOUNT:</div>
            <div>The Goods are shipped under draw back scheme. The Goods are shipped under RoDTEP scheme.</div>
            <div className="font-bold pt-1">Declaration</div>
            <div>
              We declare that this Invoice shows the actual price of the goods described and that all particulars are true and correct.
            </div>
          </div>

          {/* Right: Signatory Block */}
          <div className="col-span-5 p-2 flex flex-col justify-between">
            <div className="font-bold text-center">
              For, Innovative Flexotech Pvt. Ltd.
            </div>

            <div className="h-16 flex items-center justify-center">
              {shipment.exporter.signatureImage ? (
                <img
                  src={shipment.exporter.signatureImage}
                  alt="Authorized Signatory"
                  className="max-h-14 object-contain"
                />
              ) : (
                <div className="text-center text-slate-400 italic text-[10px]">
                  [Authorized Signatory Stamp & Signature]
                </div>
              )}
            </div>

            <div className="border-t border-black pt-1 text-center font-bold">
              Authorized Signatory.
            </div>
          </div>
        </div>
      </div>

      {/* 3. Bottom Pink/Red Plant & Office Footer */}
      {!isPreprinted && (
        <InnovativeLetterheadFooter
          customFooterImage={shipment.exporter.customFooterImage}
        />
      )}
    </div>
  );
};
