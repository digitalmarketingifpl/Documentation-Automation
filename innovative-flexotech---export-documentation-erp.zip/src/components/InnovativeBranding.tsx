import React from 'react';
import { INNOVATIVE_HEADER_IMAGE_BASE64, INNOVATIVE_HEADER_IMAGE_URL } from '../utils/brandingAssets';

interface BrandingProps {
  customHeaderImage?: string;
  customFooterImage?: string;
}

export const DEFAULT_HEADER_IMAGE_PATH = INNOVATIVE_HEADER_IMAGE_BASE64 || INNOVATIVE_HEADER_IMAGE_URL;

export const InnovativeLetterheadHeader: React.FC<BrandingProps> = ({ customHeaderImage }) => {
  const [imageError, setImageError] = React.useState(false);
  const activeHeaderSrc = customHeaderImage || DEFAULT_HEADER_IMAGE_PATH;

  // Use the exact uploaded header image with no changes as header of every document
  if (activeHeaderSrc && !imageError) {
    return (
      <div className="print-letterhead-header pb-1 mb-2 w-full">
        <img
          src={activeHeaderSrc}
          alt="Innovative Flexotech Header"
          className="w-full h-auto object-contain block max-h-32"
          onError={() => setImageError(true)}
        />
      </div>
    );
  }

  // Exact 1:1 Vector Replica matching WhatsApp Image 2026-10-10 at 2.40.57 PM.jpeg
  return (
    <div className="print-letterhead-header pb-1 mb-2 w-full select-none">
      <svg
        viewBox="0 0 1000 120"
        className="w-full h-auto block"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Left Vertical Capsule Icon */}
        <g transform="translate(10, 10)">
          {/* Top Black Cap */}
          <path
            d="M 16 0 L 36 0 C 41 0 42 3 42 8 L 42 26 L 10 26 L 10 8 C 10 3 11 0 16 0 Z"
            fill="#181818"
          />
          {/* White vertical center slit in top cap */}
          <rect x="24" y="5" width="4" height="15" fill="#ffffff" rx="2" />

          {/* Bottom Red Rounded Body */}
          <path
            d="M 10 28 L 42 28 L 42 70 C 42 80 36 86 26 86 C 16 86 10 80 10 70 Z"
            fill="#c8201a"
          />
          {/* White inner curved element in bottom red body */}
          <path
            d="M 18 36 L 18 66 C 18 74 34 74 34 66 L 34 36"
            fill="none"
            stroke="#ffffff"
            strokeWidth="4.5"
            strokeLinecap="round"
          />
        </g>

        {/* Central Company Typography */}
        <g transform="translate(68, 4)">
          {/* Top Line: COMPLETE FLEXO SOLUTION (aligned over the right half of innovative) */}
          <g transform="translate(108, 14)">
            <text
              x="0"
              y="0"
              fontFamily="'Plus Jakarta Sans', Arial, sans-serif"
              fontSize="10.5"
              fontWeight="800"
              letterSpacing="2.2"
              fill="#111111"
            >
              COMPLETE <tspan fill="#c8201a">FLEXO</tspan> SOLUTION
            </text>
          </g>

          {/* Main Logo Word: innovative */}
          {/* Rendered with exact custom geometric glyphs matching the corporate logo */}
          <g transform="translate(0, 22)" fill="#c8201a">
            {/* letter: ı */}
            <rect x="0" y="0" width="11" height="32" rx="2.5" />

            {/* letter: n */}
            <path d="M 19 0 L 29 0 L 29 6 C 31 1.8 36 0 42 0 C 49 0 52 4 52 11 L 52 32 L 42 32 L 42 13 C 42 9.5 40 8 36.5 8 C 32 8 29 10.5 29 15 L 29 32 L 19 32 Z" />

            {/* letter: n */}
            <path d="M 60 0 L 70 0 L 70 6 C 72 1.8 77 0 83 0 C 90 0 93 4 93 11 L 93 32 L 83 32 L 83 13 C 83 9.5 81 8 77.5 8 C 73 8 70 10.5 70 15 L 70 32 L 60 32 Z" />

            {/* letter: o */}
            <path
              d="M 111 0 C 120 0 125 5 125 12 L 125 20 C 125 27 120 32 111 32 C 102 32 97 27 97 20 L 97 12 C 97 5 102 0 111 0 Z M 111 8 C 107.5 8 106 10 106 13.5 L 106 18.5 C 106 22 107.5 24 111 24 C 114.5 24 116 22 116 18.5 L 116 13.5 C 116 10 114.5 8 111 8 Z"
              fillRule="evenodd"
            />

            {/* letter: v */}
            <path d="M 132 0 L 143 0 L 149 22 L 155 0 L 166 0 L 155 32 L 143 32 Z" />

            {/* letter: a */}
            <path
              d="M 183 0 C 192 0 196 4 196 10 L 196 32 L 186.5 32 L 186.5 27.5 C 184 30.5 180 32.5 174.5 32.5 C 167 32.5 163 28 163 21 C 163 14 168 11 177 11 L 186.5 11 L 186.5 9.5 C 186.5 7.5 185 6.5 181 6.5 C 176.5 6.5 173.5 8 170 9.5 L 168 2.5 C 172.5 1 177.5 0 183 0 Z M 186.5 17.5 L 179 17.5 C 174 17.5 172 19 172 22 C 172 25 174 26.5 178 26.5 C 182.5 26.5 186.5 24 186.5 20.5 Z"
            />

            {/* letter: t */}
            <path d="M 203 0 L 222 0 L 222 7.5 L 214 7.5 L 214 24 C 214 26 215 27 217.5 27 L 222 27 L 222 32 L 216 32 C 207 32 204.5 28.5 204.5 22.5 L 204.5 7.5 L 201 7.5 Z" />

            {/* letter: ı */}
            <rect x="228" y="0" width="11" height="32" rx="2.5" />

            {/* letter: v */}
            <path d="M 246 0 L 257 0 L 263 22 L 269 0 L 280 0 L 269 32 L 257 32 Z" />

            {/* letter: e */}
            <path
              d="M 297 0 C 306 0 312 5 312 13 L 312 17 L 292.5 17 C 293 22.5 296 25 301.5 25 C 305 25 308 24 310.5 22.5 L 312 28 C 309 31 305 32.5 299 32.5 C 289 32.5 283 26 283 16 C 283 6.5 289.5 0 297 0 Z M 297.5 6.5 C 293.5 6.5 292.5 9 292.5 12 L 302.5 12 C 302.5 9 301 6.5 297.5 6.5 Z"
              fillRule="evenodd"
            />
          </g>

          {/* Line 2: FLEXOTECH PVT LTD */}
          <text
            x="0"
            y="75"
            textLength="312"
            lengthAdjust="spacingAndGlyphs"
            fontFamily="'Eurostile', 'Bank Gothic', 'Microgramma', 'Arial Black', sans-serif"
            fontSize="16"
            fontWeight="900"
            fill="#111111"
          >
            FLEXOTECH PVT LTD
          </text>

          {/* Line 3: AN ISO 9001:2015 CERTIFIED COMPANY */}
          <text
            x="156"
            y="90"
            textAnchor="middle"
            fontFamily="'Plus Jakarta Sans', Arial, sans-serif"
            fontSize="9.5"
            fontWeight="700"
            letterSpacing="1.8"
            fill="#555555"
          >
            AN ISO 9001:2015 CERTIFIED COMPANY
          </text>

          {/* Line 4: www.flexo.co.in */}
          <text
            x="156"
            y="105"
            textAnchor="middle"
            fontFamily="'Plus Jakarta Sans', Arial, sans-serif"
            fontSize="12"
            fontWeight="700"
            letterSpacing="3.5"
            fill="#111111"
          >
            www.flexo.co.in
          </text>
        </g>

        {/* Right Side: Manufacturer of & Products List */}
        <g transform="translate(640, 22)">
          <text
            x="0"
            y="0"
            fontFamily="'Plus Jakarta Sans', Arial, sans-serif"
            fontSize="13"
            fontWeight="500"
            fill="#222222"
          >
            Manufacturer of
          </text>

          {/* Red Square Bullet 1 */}
          <rect x="0" y="11" width="7" height="7" fill="#c8201a" />
          <text
            x="16"
            y="18"
            fontFamily="'Plus Jakarta Sans', Arial, sans-serif"
            fontSize="12"
            fontWeight="500"
            fill="#222222"
          >
            Photopolymer Plate Making Equipment
          </text>

          {/* Red Square Bullet 2 */}
          <rect x="0" y="29" width="7" height="7" fill="#c8201a" />
          <text
            x="16"
            y="36"
            fontFamily="'Plus Jakarta Sans', Arial, sans-serif"
            fontSize="12"
            fontWeight="500"
            fill="#222222"
          >
            Solvent Recovery
          </text>

          {/* Red Square Bullet 3 */}
          <rect x="0" y="47" width="7" height="7" fill="#c8201a" />
          <text
            x="16"
            y="54"
            fontFamily="'Plus Jakarta Sans', Arial, sans-serif"
            fontSize="12"
            fontWeight="500"
            fill="#222222"
          >
            Flexo Printing Press
          </text>
        </g>

        {/* Bottom Full-Width Solid Red Line */}
        <rect x="0" y="115" width="1000" height="5" fill="#c8201a" />
      </svg>
    </div>
  );
};

export const InnovativeLetterheadFooter: React.FC<BrandingProps> = ({ customFooterImage }) => {
  // If custom footer image is provided, render it directly
  if (customFooterImage) {
    return (
      <div className="print-letterhead-footer pt-1 mt-2 w-full">
        <img
          src={customFooterImage}
          alt="Innovative Flexotech Footer"
          className="w-full h-auto object-contain block max-h-24"
        />
      </div>
    );
  }

  // Exact 1:1 Vector Replica matching WhatsApp Image 2026-10-10 at 2.40.57 PM (1).jpeg
  return (
    <div className="print-letterhead-footer pt-1 mt-2 w-full select-none">
      <svg
        viewBox="0 0 950 84"
        className="w-full h-auto block"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Top Fine Red Rule */}
        <line x1="0" y1="2" x2="950" y2="2" stroke="#b91c1c" strokeWidth="1.5" />

        {/* Office Lines */}
        <text
          x="4"
          y="18"
          fontFamily="'Plus Jakarta Sans', 'Arial', sans-serif"
          fontSize="11.5"
          fill="#333333"
        >
          <tspan fill="#b91c1c" fontWeight="700">Office</tspan> : 436, Patel Avenue, Nr. Gurudwara, Thaltej, Ahmedabad-380059. Gujarat (INDIA)
        </text>

        <text
          x="54"
          y="34"
          fontFamily="'Plus Jakarta Sans', 'Arial', sans-serif"
          fontSize="11.5"
          fill="#333333"
        >
          Tel.:+91- 98240 96180 &nbsp;Email:info@flexo.co.in/sales@flexo.co.in, Website:www.flexo.co.in
        </text>

        {/* Middle Fine Red Rule */}
        <line x1="0" y1="42" x2="950" y2="42" stroke="#b91c1c" strokeWidth="1.5" />

        {/* Plant I */}
        <text
          x="4"
          y="58"
          fontFamily="'Plus Jakarta Sans', 'Arial', sans-serif"
          fontSize="11.5"
          fill="#333333"
        >
          <tspan fill="#b91c1c" fontWeight="700">Plant I &nbsp;</tspan>: Plot No. 33, Hansalpur, GIDC, Viramgam, Dist. Ahmedabad–382150. Gujarat.
        </text>

        {/* Plant II */}
        <text
          x="4"
          y="74"
          fontFamily="'Plus Jakarta Sans', 'Arial', sans-serif"
          fontSize="11.5"
          fill="#333333"
        >
          <tspan fill="#b91c1c" fontWeight="700">Plant II</tspan> : Plot B/8, Shyam Ujjwal Estate, Gate No. 3, Opp. SBI Bank, Bombay Conductor Road, Vatva GIDC Phase-I, Ahmedabad-382445, Gujarat.
        </text>
      </svg>
    </div>
  );
};
