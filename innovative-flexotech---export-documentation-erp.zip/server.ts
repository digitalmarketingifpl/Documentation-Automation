import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '10mb' }));

// Initialize Google GenAI
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// In-memory data store with disk persistence backup
const DATA_FILE = path.join(__dirname, '.trade_storage.json');

interface StorageData {
  shipments: any[];
  companyProfile: any | null;
}

let storage: StorageData = {
  shipments: [],
  companyProfile: null,
};

// Load storage if file exists
try {
  if (fs.existsSync(DATA_FILE)) {
    const raw = fs.readFileSync(DATA_FILE, 'utf-8');
    storage = JSON.parse(raw);
  }
} catch (err) {
  console.warn('Could not read existing storage file, initializing fresh:', err);
}

function saveStorage() {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(storage, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to write storage file:', err);
  }
}

// REST API for Shipments
app.get('/api/shipments', (req, res) => {
  res.json({ shipments: storage.shipments || [] });
});

app.post('/api/shipments', (req, res) => {
  const shipment = req.body;
  if (!shipment || !shipment.id) {
    return res.status(400).json({ error: 'Invalid shipment payload' });
  }

  const existingIdx = storage.shipments.findIndex((s) => s.id === shipment.id);
  if (existingIdx >= 0) {
    storage.shipments[existingIdx] = shipment;
  } else {
    storage.shipments.unshift(shipment);
  }
  saveStorage();
  res.json({ success: true, shipment });
});

app.post('/api/shipments/bulk', (req, res) => {
  const { shipments } = req.body;
  if (Array.isArray(shipments)) {
    storage.shipments = shipments;
    saveStorage();
    return res.json({ success: true, count: shipments.length });
  }
  res.status(400).json({ error: 'shipments must be an array' });
});

app.delete('/api/shipments/:id', (req, res) => {
  const { id } = req.params;
  storage.shipments = storage.shipments.filter((s) => s.id !== id);
  saveStorage();
  res.json({ success: true, id });
});

// REST API for Master Company Profile
app.get('/api/company-profile', (req, res) => {
  res.json({ profile: storage.companyProfile });
});

app.post('/api/company-profile', (req, res) => {
  storage.companyProfile = req.body;
  saveStorage();
  res.json({ success: true, profile: storage.companyProfile });
});

// AI Trade Compliance & Math Audit Endpoint
app.post('/api/gemini/compliance-audit', async (req, res) => {
  try {
    const shipment = req.body;
    if (!shipment) {
      return res.status(400).json({ error: 'Shipment data required' });
    }

    const prompt = `
You are an expert Indian Customs & International Trade Compliance Auditor specialized in CBIC (Central Board of Indirect Taxes and Customs), DGFT (Directorate General of Foreign Trade), RBI (Reserve Bank of India FEMA guidelines), GST Act Section 16 (Zero Rated Supply under LUT), and ICC Incoterms 2020 rules.

Perform a thorough compliance & math audit on the following export shipment data:
${JSON.stringify(shipment, null, 2)}

Audit Checklist to evaluate:
1. Mathematical accuracy:
   - Line items: Qty * Unit Price == Amount?
   - Grand totals: Sum of line items + Freight + Insurance - Discount == Total Invoice Value?
   - Weights: Is Total Gross Weight >= Total Net Weight? (Warn if Gross Wt < Net Wt).
   - Packaging CBM calculation: (Length * Width * Height / 1,000,000) * count.
2. Indian GST & Customs compliance:
   - GSTIN format (15 characters: 2 state digits + 10 PAN chars + entity code + Z + check digit).
   - IEC format (10-digit alphanumeric Import Export Code).
   - PAN format (10 characters: 5 letters + 4 digits + 1 letter).
   - LUT (Letter of Undertaking) declaration: If supplyType is 'LUT_WITHOUT_TAX', is the LUT number present and valid format (e.g., AD070326001234F)?
   - AD Code (Authorized Dealer Code): 7 or 14-digit bank code registered with ICEGATE.
   - Scheme Codes (e.g. 19 for Duty Drawback, 60 for RoDTEP, 00 for Free Shipping Bill).
   - HSN Codes: Must be 6 or 8 digits. Check each line item's HSN code.
3. Carriage & Port validations:
   - Are Port of Loading and Port of Discharge clearly specified?
   - Are UN/LOCODE port codes included (e.g. INNSA1 for Nhava Sheva, INTKD6 for ICD Tughlakabad, DEHAM for Hamburg)?
   - Incoterms 2020 check: Is named place/port specified along with term (e.g. FOB Nhava Sheva or CIF Hamburg)?
4. LC & Regulatory Statements:
   - If LC is used, are LC number, issuing bank, latest shipment date present?
   - RBI Caution list declaration & FEMA 1999 export proceeds realization undertaking.

Return your audit response STRICTLY as a valid JSON object matching this schema:
{
  "overallScore": number (0 to 100, where 100 is fully compliant),
  "status": "PASS" | "NEEDS_ATTENTION" | "CRITICAL_ISSUES",
  "summary": "Concise 2-3 sentence executive audit verdict",
  "mathAudit": {
    "isMathAccurate": boolean,
    "calculatedTotal": number,
    "statedTotal": number,
    "calculatedNetWeight": number,
    "statedNetWeight": number,
    "calculatedGrossWeight": number,
    "statedGrossWeight": number,
    "weightDiscrepancyNotes": string
  },
  "issues": [
    {
      "id": "string",
      "category": "Math" | "GST_Customs" | "Carriage_Ports" | "LC_Regulatory" | "HSN",
      "severity": "critical" | "warning" | "info",
      "field": "string",
      "title": "string",
      "description": "string",
      "recommendation": "string",
      "autoFixable": boolean,
      "suggestedFixValue": any (optional)
    }
  ],
  "customsAdvice": [
    "Specific bullet advice for customs clearance officer and CHA (Customs Broker)"
  ]
}
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text || '{}';
    const parsed = JSON.parse(text);
    return res.json(parsed);
  } catch (error: any) {
    console.error('Compliance Audit Error:', error);
    res.status(500).json({
      error: 'Failed to run compliance audit',
      details: error?.message || String(error),
    });
  }
});

// Purchase Order (PO) Text Extractor Endpoint
app.post('/api/gemini/po-extract', async (req, res) => {
  try {
    const { rawText } = req.body;
    if (!rawText || typeof rawText !== 'string') {
      return res.status(400).json({ error: 'rawText string is required' });
    }

    const prompt = `
You are an expert International Trade Operations assistant.
Extract structured trade details and line items from this raw customer purchase order text, email brief, or RFQ snippet:

"""
${rawText}
"""

Extract the following information as a valid JSON object:
{
  "buyerName": string,
  "buyerAddress": string,
  "buyerCountry": string,
  "buyerEmail": string,
  "buyerPhone": string,
  "buyerTaxId": string,
  "poNumber": string,
  "poDate": string (YYYY-MM-DD or empty),
  "currency": string (e.g. "USD", "EUR", "GBP", "AED"),
  "incoterm": string (e.g. "FOB", "CIF", "CFR", "EXW", "DDP"),
  "namedPortOrPlace": string,
  "paymentTerms": string,
  "portOfDischarge": string,
  "finalDestination": string,
  "lineItems": [
    {
      "description": string,
      "hsnCode": string,
      "quantity": number,
      "unit": string (e.g. "PCS", "SETS", "KGS", "MTR", "BOX"),
      "unitPrice": number,
      "amount": number,
      "netWeightKg": number (estimated if not given),
      "grossWeightKg": number (estimated if not given)
    }
  ],
  "specialInstructions": string
}
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text || '{}';
    const parsed = JSON.parse(text);
    return res.json(parsed);
  } catch (error: any) {
    console.error('PO Extractor Error:', error);
    res.status(500).json({
      error: 'Failed to extract purchase order details',
      details: error?.message || String(error),
    });
  }
});

// Setup Vite middleware in dev or static files in production
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ExImDocs Pro server listening on port ${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
